<?php

$routes->group('api', function ($routes) {

	$routes->get('pppoe-expiry-check', 'ApiController::pppoeExpiryCheck');

	// Captive Portal — expired PPPoE users land here
	// $routes->get('captive-portal', 'CaptivePortal::index');
	$routes->get('captive-portal', 'CaptivePortal::index');

	// Android / iOS / Windows captive portal detection URLs
	// When the phone checks these URLs and gets a redirect → browser popup appears automatically
	$routes->get('generate_204', 'CaptivePortal::index');
	$routes->get('hotspot-detect.html', 'CaptivePortal::index');
	$routes->get('connecttest.txt', 'CaptivePortal::index');
	$routes->get('ncsi.txt', 'CaptivePortal::index');

	/**
	 * Authentication routes
	 */
	$routes->post('login', 'api\ApiController::login', [
		// 'as' => 'route.auth.login.validate'
	]);
	$routes->post('validate', 'AuthController::validateLogin', [
		// 'as' => 'route.auth.login.validate'
	]);
	$routes->get('users/(:num)', 'api\ApiController::index/$1');

	$routes->get('users_load-traffic/(:num)', 'Routers::UsersloadTraffic_api/$1', [
		// 'as' => 'route.routers.Usersload_Traffic',
	]);
	$routes->get('payment_fetch', 'api\ApiController::fetch', [
		// 'as' => 'route.payment.fetch',
		// 'filter' => 'permissioncheck:payment,read',
	]);
	$routes->get('packages', 'api\ApiController::packages', [
		// 'as' => 'Admin.packages',
		// 'filter' => 'permissioncheck:customer,read',
	]);
	$routes->get('pingUserApi', 'api\ApiController::pingUserApi', [
		// 'as' => 'route.customer.pingUserApi'
	]);

	$routes->get('subscription_index', 'api\ApiController::Subscription_index', [
		// 'as' => 'route.customer.pingUserApi'
	]);

	$routes->get('subscription_renew', 'api\ApiController::Subscription_renew', [
		// 'as' => 'route.customer.pingUserApi'
	]);

	$routes->get('support_ticket_fetch', 'api\ApiController::Support_ticket_fetch', [
		// 'as' => 'route.customer.pingUserApi'
	]);
	$routes->get('ticket_details', 'api\ApiController::ticket_details', [
		// 'as' => 'route.customer.pingUserApi'
	]);
	$routes->post('profile_update', 'api\ApiController::profile_update', [
		// 'as' => 'route.customer.pingUserApi'
	]);
	$routes->post('send_message', 'api\ApiController::sendMessage', [
		// 'as' => 'route.ticket.sendmsg',
		// 'filter' => 'permissioncheck:support_ticket,send_msg',
	]);

	$routes->post('activatePackage', 'api\ApiController::activatePackage', [
		// 'as' => 'Admin.activatePackage'
	]);
	$routes->post('user_subscription_update', 'api\ApiController::userSubscriptionUpdate', [
	]);
	$routes->get('permission', 'api\ApiController::check_permission', [
		// 'as' => 'Admin.activatePackage'
	]);
	$routes->post('create_ticket', 'api\ApiController::create_ticket', [
		// 'as' => 'Admin.activatePackage'
	]);

	$routes->get('make-payment/(:num)', 'api\ApiController::makePayment/$1', [
		// 'as' => 'route.payment.pay',
		// 'filter' => 'permissioncheck:payment,payment',
	]);
	$routes->get('make-reseller-payment/(:num)', 'api\ApiController::makePaymentReselar/$1', [
		// 'as' => 'route.payment.pay',
		// 'filter' => 'permissioncheck:payment,payment',
	]);
	$routes->get('exhome', 'AuthController::exhome', [
		// 'as' => 'route.exhome',
	]);

	$routes->group('reseller', function ($routes) {
		$routes->get('dashboard/(:num)', 'api\reseller\ApiResellerDashboard::dashboard/$1');
		$routes->get('areas/(:num)/sub/(:num)', 'api\reseller\ApiResellerServiceArea::subindex/$1/$2');
		$routes->get('areas/(:num?)', 'api\reseller\ApiResellerServiceArea::index/$1');
		$routes->post('areas/(:num)', 'api\reseller\ApiResellerServiceArea::create/$1');
		$routes->post('areas', 'api\reseller\ApiResellerServiceArea::create');
		$routes->post('subareas', 'api\reseller\ApiResellerServiceArea::subcreate');
		$routes->get('areas/edit/(:num)', 'api\reseller\ApiResellerServiceArea::edit/$1');
		$routes->get('subareas/edit/(:num)', 'api\reseller\ApiResellerServiceArea::editsub/$1');
		$routes->put('areas/update/(:num)', 'api\reseller\ApiResellerServiceArea::update/$1');
		$routes->put('subareas/update/(:num)', 'api\reseller\ApiResellerServiceArea::updatesub/$1');
		$routes->delete('areas/(:num)/delete', 'api\reseller\ApiResellerServiceArea::delete/$1');
		$routes->delete('areas/delete', 'api\reseller\ApiResellerServiceArea::delete');
		$routes->delete('subareas/delete', 'api\reseller\ApiResellerServiceArea::deletesub');
		$routes->get('packages/(:num?)', 'api\reseller\ApiResellerPackage::fetch/$1');
		$routes->delete('packages/(:num)/(:num)', 'api\reseller\ApiResellerPackage::delete/$1/$2');
		$routes->post('customers/create/(:num?)', 'api\reseller\ApiResellerCustomer::create/$1');
		$routes->post('customers/(:num)/sync-pppoe', 'api\reseller\ApiResellerCustomer::syncPppoeIds/$1');
		$routes->post('customers/(:num)/import-excel', 'api\reseller\ApiResellerCustomer::importExcel/$1');
		$routes->post('customers/(:num)/bulk-recharge', 'api\reseller\ApiResellerCustomer::bulkRecharge/$1');
		$routes->post('customers/(:num)/transfer', 'api\reseller\ApiResellerCustomer::transfer/$1');
		$routes->post('customers/(:num)/bulk-delete', 'api\reseller\ApiResellerCustomer::bulkDelete/$1');
		$routes->delete('customers/(:num)/bulk-delete', 'api\reseller\ApiResellerCustomer::bulkDelete/$1');
		$routes->get('customers/(:num)/export-excel', 'api\reseller\ApiResellerCustomer::exportExcel/$1');
		$routes->get('customers/(:num)/(:num)/audit-logs', 'api\reseller\ApiResellerCustomer::auditLogs/$1/$2');
		$routes->get('customers/(:num)/(:num)/mac-status', 'api\reseller\ApiResellerCustomer::macStatus/$1/$2');
		$routes->post('customers/(:num)/(:num)/mac-bind', 'api\reseller\ApiResellerCustomer::macBind/$1/$2');
		$routes->post('customers/(:num)/(:num)/mac-unbind', 'api\reseller\ApiResellerCustomer::macUnbind/$1/$2');
		$routes->get('customers/(:num?)', 'api\reseller\ApiResellerCustomer::fetch/$1');
		$routes->get('customers/(:num?)/(:num?)', 'api\reseller\ApiResellerCustomer::details/$1/$2');
		$routes->post('customers/(:num?)/(:num?)', 'api\reseller\ApiResellerCustomer::update/$1/$2');
		$routes->delete('customers/(:num?)/(:num?)', 'api\reseller\ApiResellerCustomer::delete/$1/$2');
		$routes->get('customer-payments/(:num)', 'api\reseller\ApiResellerCustomerPayment::fetch/$1');
		$routes->get('customer-payments/(:num)/user/(:num)', 'api\reseller\ApiResellerCustomerPayment::userPayments/$1/$2');
		$routes->post('customer-payments/(:num)', 'api\reseller\ApiResellerCustomerPayment::create/$1');
		$routes->put('customer-payments/(:num)/(:num)', 'api\reseller\ApiResellerCustomerPayment::update/$1/$2');
		$routes->delete('customer-payments/(:num)', 'api\reseller\ApiResellerCustomerPayment::delete/$1');
		$routes->get('employees/(:num)', 'api\reseller\ApiResellerEmployee::fetch/$1');
		$routes->get('employees/(:num)/(:num)', 'api\reseller\ApiResellerEmployee::details/$1/$2');
		$routes->post('employees/(:num)', 'api\reseller\ApiResellerEmployee::create/$1');
		$routes->put('employees/(:num)/(:num)', 'api\reseller\ApiResellerEmployee::update/$1/$2');
		$routes->delete('employees/(:num)', 'api\reseller\ApiResellerEmployee::delete/$1');
		$routes->get('employee-payments/(:num)', 'api\reseller\ApiResellerEmployeePayment::fetch/$1');
		$routes->post('employee-payments/(:num)', 'api\reseller\ApiResellerEmployeePayment::create/$1');
		$routes->put('employee-payments/(:num)/(:num)', 'api\reseller\ApiResellerEmployeePayment::update/$1/$2');
		$routes->delete('employee-payments/(:num)', 'api\reseller\ApiResellerEmployeePayment::delete/$1');
		$routes->get('support-tickets/(:num)', 'api\reseller\ApiResellerSupportTicket::fetch/$1');
		$routes->get('support-tickets/(:num)/(:num)', 'api\reseller\ApiResellerSupportTicket::details/$1/$2');
		$routes->post('support-tickets/(:num)', 'api\reseller\ApiResellerSupportTicket::create/$1');
		$routes->post('support-tickets/(:num)/(:num)/message', 'api\reseller\ApiResellerSupportTicket::sendMessage/$1/$2');
		$routes->put('support-tickets/(:num)/(:num)', 'api\reseller\ApiResellerSupportTicket::update/$1/$2');
		$routes->delete('support-tickets/(:num)', 'api\reseller\ApiResellerSupportTicket::delete/$1');
		$routes->get('transactions/(:num)', 'api\reseller\ApiResellerTransaction::fetch/$1');
		$routes->delete('transactions/(:num)', 'api\reseller\ApiResellerTransaction::delete/$1');
		$routes->get('funding/(:num)', 'api\reseller\ApiResellerFunding::fetch/$1');
		$routes->post('funding/(:num)', 'api\reseller\ApiResellerFunding::create/$1');
		$routes->delete('funding/(:num)', 'api\reseller\ApiResellerFunding::delete/$1');
		$routes->get('subscription/(:num)/(:num)', 'api\reseller\ApiResellerSubscription::info/$1/$2');
		$routes->post('subscription/(:num)/renew', 'api\reseller\ApiResellerSubscription::renew/$1');
		$routes->post('subscription/(:num)/bulk-renew', 'api\reseller\ApiResellerSubscription::bulkRenew/$1');
		$routes->get('sms/(:num)/recipients', 'api\reseller\ApiResellerSms::recipients/$1');
		$routes->post('sms/(:num)/send', 'api\reseller\ApiResellerSms::send/$1');
		$routes->get('sms/(:num)', 'api\reseller\ApiResellerSms::fetch/$1');
		$routes->delete('sms/(:num)', 'api\reseller\ApiResellerSms::delete/$1');
		$routes->get('voice-sms/(:num)/recipients', 'api\reseller\ApiResellerVoiceSms::recipients/$1');
		$routes->post('voice-sms/(:num)/send', 'api\reseller\ApiResellerVoiceSms::send/$1');
		$routes->get('payments/(:num)', 'api\reseller\ApiResellerPayment::fetch/$1');
		$routes->get('profile/(:num)', 'api\reseller\ApiResellerProfile::fetch/$1');
		$routes->put('profile/(:num)', 'api\reseller\ApiResellerProfile::update/$1');
		$routes->put('profile/(:num)/organization', 'api\reseller\ApiResellerProfile::updateOrganization/$1');
		$routes->post('profile/(:num)/change-password', 'api\reseller\ApiResellerProfile::changePassword/$1');
		$routes->get('routers/(:num)', 'api\reseller\ApiResellerRouter::list/$1');
		$routes->get('router-users/(:num)/(:num)', 'api\reseller\ApiResellerRouter::fetch/$1/$2');
	});

	$routes->group('movieservers', function ($routes) {
		$routes->get('/', 'api\ApiController::movie_index');
		$routes->get('view/(:num)', 'api\ApiController::view/$1');
		$routes->post('add', 'api\ApiController::add');
		$routes->post('update/(:num)', 'api\ApiController::update/$1');
		$routes->get('delete/(:num)', 'api\ApiController::delete/$1');
	});

	$routes->group('news', function ($routes) {
		$routes->get('/', 'api\ApiController::news_index');
		$routes->get('view/(:num)', 'api\ApiController::news_view/$1');
		$routes->post('add', 'api\ApiController::news_add');
		$routes->post('update/(:num)', 'api\ApiController::news_update/$1');
		$routes->post('news_view_update/(:num)', 'api\ApiController::news_view_update/$1');
		$routes->get('delete/(:num)', 'api\ApiController::news_delete/$1');
	});

	$routes->get('invoice_print', 'api\ApiController::invoicePrint');
	$routes->get('get_user_data_usage', 'api\ApiController::get_user_data_usage');
	$routes->get('routers/load-traffic/(:num)', 'Routers::loadTraffic/$1');

	$routes->post('bkash/webhook', 'Bkash_webhook::Test');
	$routes->post('bkash/get_bkash_sendmoney', 'Bkash_webhook::get_bkash_sendmoney');
});
