<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerPayment extends BaseController
{
    protected $payment_model;

    public function __construct()
    {
        $this->payment_model = model('App\Models\Payment');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/payments/{resellerId}
     * Reseller's own payments (POP payments where user_type = 'reseller' or paidby = reseller)
     */
    public function fetch($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $fromDate = $this->request->getGet('fromDate');
        $toDate = $this->request->getGet('toDate');
        $status = $this->request->getGet('status');

        $builder = $this->payment_model->builder()->select('*');

        $builder->groupStart()
            ->where('admin_id', $resellerId)
            ->orWhere('paidby', $resellerId)
            ->groupEnd();

        if (!empty($status)) {
            $builder->where('status', $status);
        }

        if (!empty($fromDate) && !empty($toDate)) {
            $builder->where('DATE(created_at) >=', $fromDate)
                ->where('DATE(created_at) <=', $toDate);
        }

        $builder->orderBy('id', 'desc');
        $payments = $builder->get()->getResultArray();

        $result = [];
        foreach ($payments as $row) {
            $row['customer_name'] = getUserById($row['user_id'])->name ?? '--';
            $row['paid_to_name'] = !empty($row['paid_to']) ? (getUserById($row['paid_to'])->name ?? '--') : '--';
            $result[] = $row;
        }

        return $this->response->setJSON(['status' => 'success', 'data' => $result]);
    }
}
