<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerPackage extends BaseController
{
    protected $package_model;

    public function __construct()
    {
        $this->package_model = model('App\Models\Package');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/packages/(:num?)
     * Returns packages list scoped to the route id or session user
     */
    public function fetch($adminId = null)
    {


        if (empty($adminId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $userModel = model('App\\Models\\User');
        $details = $userModel->where(['id' => $adminId])->first();
        $admin_id = $details->admin_id ?? $adminId;
        $packageModel = model('App\\Models\\ResellerPackages');

        $result = $packageModel->where('status', 'active')->where('user_id', $admin_id)->orderBy('id', 'desc')->findAll();

        return $this->response->setJSON(['status' => 'success', 'data' => $result]);
    }

    /**
     * DELETE /api/reseller/packages
     * body: { ids: [1,2,3] }
     * Deletes packages according to current role scope
     */

    public function delete($adminId = null, $packageId = null, $role = null)
    {
        // Require role and reseller id as params
        if ($role !== 'resellerAdmin') {
            return $this->response->setStatusCode(403)->setJSON(['status' => 'error', 'message' => 'Forbidden: reseller access only']);
        }

        if (empty($adminId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        if (!empty($packageId)) {
            $ids = [(int)$packageId];
        }
        else {
            $input = $this->request->getJSON(true) ?: $this->request->getPost();
            $ids = $input['ids'] ?? null;

            if (empty($ids)) {
                return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
            }

            if (is_string($ids)) {
                $decoded = json_decode($ids, true);
                if (is_array($decoded)) {
                    $ids = $decoded;
                }
                else {
                    $ids = array_filter(array_map('trim', explode(',', $ids)), 'strlen');
                }
            }

            if (!is_array($ids)) {
                return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Invalid ids format']);
            }
        }

        $packageModel = model('App\\Models\\ResellerPackages');

        // ensure only packages for this reseller are affected
        $existing = $packageModel->where('user_id', $adminId)->whereIn('id', $ids)->findAll();
        $toDelete = array_map(function ($r) {
            return (int)$r['id']; }, $existing);

        if (empty($toDelete)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'No matching packages found']);
        }

        $deleted = $packageModel->whereIn('id', $toDelete)->delete();

        if ($deleted) {
            return $this->response->setJSON(['status' => 'success', 'deleted' => $toDelete]);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error']);
    }

    /**
     * GET /api/reseller/packages/details/(:adminId)/(:packageId)/(:role)
     * Return single package details owned by reseller (no session)
     */
    public function details($adminId = null, $packageId = null, $role = null)
    {
        if ($role !== 'resellerAdmin') {
            return $this->response->setStatusCode(403)->setJSON(['status' => 'error', 'message' => 'Forbidden: reseller access only']);
        }

        if (empty($adminId) || empty($packageId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or package id']);
        }

        $packageModel = model('App\\Models\\ResellerPackages');
        $pkg = $packageModel->where(['id' => (int)$packageId, 'user_id' => $adminId])->first();

        if (empty($pkg)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Package not found']);
        }

        return $this->response->setJSON(['status' => 'success', 'data' => $pkg]);
    }
}