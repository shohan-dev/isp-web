<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerCustomerPayment extends BaseController
{
    protected $payment_model;
    protected $user_model;

    public function __construct()
    {
        $this->payment_model = model('App\Models\Payment');
        $this->user_model = model('App\Models\User');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/customer-payments/{resellerId}
     */
    public function fetch($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $fromDate = $this->request->getGet('fromDate');
        $toDate = $this->request->getGet('toDate');

        $builder = $this->payment_model->where(['user_type' => 'user', 'admin_id' => $resellerId]);

        if (!empty($fromDate) && !empty($toDate)) {
            $builder->where('created_at >=', $fromDate)->where('created_at <=', $toDate);
        } elseif (!empty($fromDate)) {
            $builder->where('created_at >=', $fromDate);
        }

        $payments = $builder->orderBy('id', 'desc')->findAll();

        $result = [];
        foreach ($payments as $p) {
            $row = is_object($p) ? (array) $p : $p;
            $row['customer_name'] = getUserById($row['user_id'])->name ?? '--';
            $row['paid_to_name'] = !empty($row['paid_to']) ? (getUserById($row['paid_to'])->name ?? '--') : '--';
            $result[] = $row;
        }

        return $this->response->setJSON(['status' => 'success', 'data' => $result]);
    }

    /**
     * GET /api/reseller/customer-payments/{resellerId}/user/{userId}
     */
    public function userPayments($resellerId = null, $userId = null)
    {
        if (empty($resellerId) || empty($userId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or user id']);
        }

        $payments = $this->payment_model
            ->where('user_type', 'user')
            ->where('admin_id', $resellerId)
            ->groupStart()
            ->where('user_id', $userId)
            ->orWhere('paidby', $userId)
            ->groupEnd()
            ->orderBy('id', 'desc')
            ->findAll();

        $successfulAmount = 0;
        $pendingAmount = 0;
        $result = [];

        foreach ($payments as $p) {
            $row = is_object($p) ? (array) $p : $p;
            $row['customer_name'] = getUserById($row['user_id'])->name ?? '--';
            if (($row['status'] ?? '') === 'successful') {
                $successfulAmount += (float) ($row['amount'] ?? 0);
            } elseif (($row['status'] ?? '') === 'pending') {
                $pendingAmount += (float) ($row['amount'] ?? 0);
            }
            $result[] = $row;
        }

        return $this->response->setJSON([
            'status' => 'success',
            'successfulAmount' => round($successfulAmount, 2),
            'pendingAmount' => round($pendingAmount, 2),
            'data' => $result,
        ]);
    }

    /**
     * POST /api/reseller/customer-payments/{resellerId}
     */
    public function create($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'customer' => 'required|numeric',
            'amount' => 'required|numeric',
            'month' => 'required',
            'status' => 'required|in_list[successful,pending,failed]',
        ];

        if (($input['status'] ?? '') === 'successful') {
            $rules['paid_via'] = 'required';
            $rules['method_trx'] = 'required';
        }

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $customerId = $input['customer'];
        $customer = $this->user_model->where(['id' => $customerId, 'admin_id' => $resellerId, 'role' => 'user'])->first();
        if (empty($customer)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Customer not found for this reseller']);
        }

        $data = [
            'user_id' => $customerId,
            'user_type' => 'user',
            'admin_id' => $resellerId,
            'paidby' => $resellerId,
            'invoice' => 'INV-' . random_int(100000, 999999),
            'amount' => $input['amount'],
            'month' => $input['month'],
            'paid_via' => $input['paid_via'] ?? null,
            'paid_to' => $resellerId,
            'method_trx' => $input['method_trx'] ?? null,
            'status' => $input['status'],
            'created_at' => date('Y-m-d H:i:s'),
        ];

        if ($input['status'] === 'successful') {
            $data['paid_at'] = date('Y-m-d H:i:s');
        }

        $existing = $this->payment_model->where(['user_id' => $customerId, 'month' => $input['month']])->first();

        if ($existing && ($existing->status ?? ($existing['status'] ?? '')) !== 'successful') {
            $existingId = is_object($existing) ? $existing->id : $existing['id'];
            $result = $this->payment_model->update($existingId, $data);
        } else {
            $result = $this->payment_model->insert($data, false);
        }

        if (!$result) {
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Payment creation failed']);
        }

        $willExpire = $input['will_expire'] ?? null;
        $renew = $input['renew'] ?? 'no';

        if ($renew === 'yes' && !empty($willExpire)) {
            $now = date('Y-m-d H:i:s');
            $resellerDetails = $this->user_model->find($resellerId);
            $fund = $resellerDetails->fund ?? 0;

            $tprice = function_exists('ResellerPackagePrice') ? ResellerPackagePrice($customer->package_id) : 0;
            $customerExpire = $customer->will_expire ?? $now;

            if ($customer->subscription_status === 'active') {
                $base = strtotime($customerExpire);
            } else {
                $base = time();
            }
            $target = strtotime($willExpire);
            $difference = max(0, floor(($target - $base) / 86400));

            $pricePerDay = $tprice / 30;
            $price = $pricePerDay * $difference;

            if ($fund < $price) {
                return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Insufficient fund. Required: ' . round($price, 2) . ', Available: ' . round($fund, 2)]);
            }

            $this->user_model->update($resellerId, ['fund' => $fund - $price]);
            $this->user_model->update($customerId, [
                'last_renewed' => date('Y-m-d H:i:s'),
                'will_expire' => $willExpire,
                'subscription_status' => (strtotime($willExpire) > time()) ? 'active' : 'inactive',
            ]);

            $transModel = model('App\Models\ResellerTransactions');
            $transModel->insert([
                'customer' => $customerId,
                'admin_id' => $resellerId,
                'amount' => $price,
                'package_price' => $tprice,
                'active_for' => $difference,
                'comments' => 'API Payment + Renewal',
            ]);
        }

        return $this->response->setJSON(['status' => 'success', 'message' => 'Payment recorded successfully']);
    }

    /**
     * PUT /api/reseller/customer-payments/{resellerId}/{paymentId}
     */
    public function update($resellerId = null, $paymentId = null)
    {
        if (empty($resellerId) || empty($paymentId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or payment id']);
        }

        $payment = $this->payment_model->where(['id' => $paymentId, 'user_type' => 'user', 'admin_id' => $resellerId])->first();
        if (empty($payment)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Payment not found']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'amount' => 'required|numeric',
            'month' => 'required',
            'status' => 'required|in_list[successful,pending,failed]',
        ];

        if (($input['status'] ?? '') === 'successful') {
            $rules['paid_via'] = 'required';
            $rules['method_trx'] = 'required';
        }

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $data = [
            'amount' => $input['amount'],
            'month' => $input['month'],
            'paid_via' => $input['paid_via'] ?? null,
            'method_trx' => $input['method_trx'] ?? null,
            'status' => $input['status'],
        ];

        if ($input['status'] === 'successful') {
            $data['paid_at'] = date('Y-m-d H:i:s');
        }

        $result = $this->payment_model->update($paymentId, $data);

        if (!$result) {
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Update failed']);
        }

        $willExpire = $input['will_expire'] ?? null;
        $renew = $input['renew'] ?? 'no';
        if ($renew === 'yes' && !empty($willExpire)) {
            $paymentUserId = is_object($payment) ? $payment->user_id : $payment['user_id'];
            $now = date('Y-m-d H:i:s');
            $this->user_model->update($paymentUserId, [
                'last_renewed' => $now,
                'will_expire' => $willExpire,
                'subscription_status' => (strtotime($willExpire) > time()) ? 'active' : 'inactive',
            ]);
        }

        return $this->response->setJSON(['status' => 'success', 'message' => 'Payment updated successfully']);
    }

    /**
     * DELETE /api/reseller/customer-payments/{resellerId}
     */
    public function delete($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $ids = $input['ids'] ?? null;

        if (empty($ids) || !is_array($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
        }

        $result = $this->payment_model->where('user_type', 'user')->where('admin_id', $resellerId)->whereIn('id', $ids)->delete();

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Deleted successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Delete failed']);
    }
}
