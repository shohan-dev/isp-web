<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerVoiceSms extends BaseController
{
    protected $user_model;
    protected $voice_model;

    public function __construct()
    {
        $this->user_model = model('App\\Models\\User');
        $this->voice_model = model('App\\Models\\VoiceSmsModel');
        helper(['user']);
    }

    private function getInput(): array
    {
        $input = $this->request->getJSON(true);
        if (is_array($input) && !empty($input)) {
            return $input;
        }

        $input = $this->request->getPost();
        if (is_array($input) && !empty($input)) {
            return $input;
        }

        $body = $this->request->getBody();
        if (!empty($body)) {
            $decoded = json_decode($body, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }

        return [];
    }

    /**
     * GET /api/reseller/voice-sms/{resellerId}/recipients
     * Get customers available for voice SMS, grouped by area, and voice templates.
     */
    public function recipients($resellerId = null)
    {
        $resellerId = (int) $resellerId;
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Missing reseller id',
            ]);
        }

        $customers = $this->user_model
            ->select('id, name, mobile, area_id, subscription_status')
            ->where(['admin_id' => $resellerId, 'role' => 'user'])
            ->orderBy('name', 'asc')
            ->findAll();

        $areaModel = model('App\\Models\\Area');
        $areas = $areaModel->where('user_id', $resellerId)->findAll();

        $areaMap = [];
        foreach ($areas as $area) {
            $a = is_array($area) ? $area : (array) $area;
            $areaMap[(string) ($a['id'] ?? '')] = $a['area_name'] ?? $a['name'] ?? '';
        }

        $templates = $this->voice_model
            ->select('id, name, message_id')
            ->where('admin_id', $resellerId)
            ->orderBy('id', 'desc')
            ->findAll();

        $templateArr = [];
        foreach ($templates as $template) {
            $template = is_array($template) ? $template : (array) $template;
            $templateArr[] = [
                'id' => (string) ($template['id'] ?? ''),
                'title' => $template['name'] ?? '',
                'message_id' => (string) ($template['message_id'] ?? ''),
            ];
        }

        $customerArr = [];
        foreach ($customers as $customer) {
            $customer = is_array($customer) ? $customer : (array) $customer;
            $customerArr[] = [
                'id' => (string) ($customer['id'] ?? ''),
                'name' => $customer['name'] ?? '',
                'mobile' => $customer['mobile'] ?? '',
                'area_id' => (string) ($customer['area_id'] ?? ''),
                'area_name' => $areaMap[(string) ($customer['area_id'] ?? '')] ?? '',
                'status' => $customer['subscription_status'] ?? 'inactive',
            ];
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => [
                'customers' => $customerArr,
                'areas' => array_map(function ($id, $name) {
                    return ['id' => (string) $id, 'name' => $name];
                }, array_keys($areaMap), array_values($areaMap)),
                'templates' => $templateArr,
            ],
        ]);
    }

    /**
     * POST /api/reseller/voice-sms/{resellerId}/send
     * Send voice SMS to selected customers.
     * Body: { template_id, send_to: ['all'] or [id,...], area?: id }
     */
    public function send($resellerId = null)
    {
        $resellerId = (int) $resellerId;
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Missing reseller id',
            ]);
        }

        $input = $this->getInput();

        $templateId = (int) ($input['template_id'] ?? 0);
        if (empty($templateId)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'validation-error',
                'message' => 'Select a voice template',
            ]);
        }

        $template = $this->voice_model
            ->where('admin_id', $resellerId)
            ->where('id', $templateId)
            ->first();

        if (empty($template)) {
            return $this->response->setStatusCode(404)->setJSON([
                'status' => 'error',
                'message' => 'Voice template not found',
            ]);
        }

        $template = is_array($template) ? $template : (array) $template;
        $messageId = trim((string) ($template['message_id'] ?? ''));
        if ($messageId === '') {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Selected template is missing message_id',
            ]);
        }

        $sendTo = $input['send_to'] ?? [];
        if (!is_array($sendTo)) {
            $sendTo = [$sendTo];
        }
        if (empty($sendTo)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Select at least one recipient',
            ]);
        }

        $areaId = $input['area'] ?? null;
        $condition = [
            'role' => 'user',
            'admin_id' => $resellerId,
            'status' => 'active',
        ];

        if (in_array('all', $sendTo, true)) {
            if (!empty($areaId)) {
                $condition['area_id'] = (int) $areaId;
            }
            $users = $this->user_model->where($condition)->asArray()->findAll();
        } else {
            $ids = array_filter($sendTo, fn($value) => is_numeric($value));
            if (empty($ids)) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => 'error',
                    'message' => 'No valid customers selected',
                ]);
            }

            $users = $this->user_model
                ->where(['admin_id' => $resellerId, 'role' => 'user'])
                ->whereIn('id', $ids)
                ->asArray()
                ->findAll();
        }

        if (empty($users)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'No matching customers found',
            ]);
        }

        $successCount = 0;
        $failCount = 0;
        foreach ($users as $user) {
            $mobile = trim((string) ($user['mobile'] ?? ''));
            if ($mobile === '') {
                $failCount++;
                continue;
            }

            $result = sendVoiceSms($mobile, $messageId, $resellerId);
            if (($result['status'] ?? '') === 'success') {
                $successCount++;
            } else {
                $failCount++;
            }
        }

        $total = count($users);
        if ($successCount === $total) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => "Voice SMS sent to all {$total} customer(s) successfully",
                'sent' => $successCount,
                'failed' => $failCount,
            ]);
        }

        if ($successCount > 0) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => "Voice SMS sent to {$successCount}/{$total} customer(s). {$failCount} failed.",
                'sent' => $successCount,
                'failed' => $failCount,
            ]);
        }

        return $this->response->setStatusCode(500)->setJSON([
            'status' => 'error',
            'message' => 'Voice SMS could not be sent. Check gateway settings and logs.',
            'sent' => 0,
            'failed' => $total,
        ]);
    }
}