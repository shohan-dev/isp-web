<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerFunding extends BaseController
{
    protected $funding_model;
    protected $user_model;
    protected $payment_model;

    public function __construct()
    {
        $this->funding_model = model('App\Models\ResellerFundingModel');
        $this->user_model = model('App\Models\User');
        $this->payment_model = model('App\Models\Payment');
        helper(['url', 'user']);
    }

    private function toArray($row)
    {
        if (is_array($row)) {
            return $row;
        }

        return is_object($row) ? (array) $row : [];
    }

    private function asFloat($value)
    {
        return (float) (is_numeric($value) ? $value : 0);
    }

    private function asInt($value)
    {
        return (int) (is_numeric($value) ? $value : 0);
    }

    private function normalizeType($type)
    {
        $value = strtolower(trim((string) $type));

        if (in_array($value, ['all', 'both'], true)) {
            return 'all';
        }

        if (in_array($value, ['invoice', 'customer_invoice', 'customer-payment', 'customer_payment'], true)) {
            return 'customer_invoice';
        }

        return 'self_recharge';
    }

    private function normalizeIds($ids)
    {
        if (is_string($ids)) {
            $decoded = json_decode($ids, true);
            if (is_array($decoded)) {
                $ids = $decoded;
            } else {
                $ids = array_filter(array_map('trim', explode(',', $ids)), 'strlen');
            }
        }

        if (!is_array($ids)) {
            return [];
        }

        $result = [];
        foreach ($ids as $id) {
            if (is_numeric($id) && (int) $id > 0) {
                $result[] = (int) $id;
            }
        }

        return array_values(array_unique($result));
    }

    private function normalizeDateForFilter($date, $isEnd = false)
    {
        $raw = trim((string) $date);
        if ($raw === '') {
            return null;
        }

        $raw = str_replace('T', ' ', $raw);
        $parsed = strtotime($raw);
        if ($parsed === false) {
            return null;
        }

        return $isEnd ? date('Y-m-d 23:59:59', $parsed) : date('Y-m-d 00:00:00', $parsed);
    }

    private function getUserName($id)
    {
        $uid = $this->asInt($id);
        if ($uid <= 0) {
            return '--';
        }

        $user = getUserById($uid);
        if (is_object($user)) {
            return $user->name ?? '--';
        }
        if (is_array($user)) {
            return $user['name'] ?? '--';
        }

        return '--';
    }

    private function getResellerFund($reseller)
    {
        $row = $this->toArray($reseller);
        if (array_key_exists('fund', $row)) {
            return $this->asFloat($row['fund']);
        }

        return is_object($reseller) ? $this->asFloat($reseller->fund ?? 0) : 0.0;
    }

    private function getResellerAdminId($reseller, $resellerId)
    {
        $row = $this->toArray($reseller);
        if (array_key_exists('admin_id', $row)) {
            return $this->asInt($row['admin_id']);
        }

        if (is_object($reseller) && isset($reseller->admin_id)) {
            return $this->asInt($reseller->admin_id);
        }

        return $this->asInt($resellerId);
    }

    private function mapSelfRechargeRow(array $row)
    {
        return [
            'id' => $this->asInt($row['id'] ?? 0),
            'recharge_type' => 'self_recharge',
            'customer' => $this->asInt($row['customer'] ?? 0),
            'customer_name' => $this->getUserName($row['customer'] ?? 0),
            'admin_id' => $this->asInt($row['admin_id'] ?? 0),
            'invoice_number' => (string) ($row['invoice_number'] ?? ''),
            'amount' => $this->asFloat($row['amount'] ?? 0),
            'received_amount' => $this->asFloat($row['received_amount'] ?? 0),
            'paid_via' => (string) ($row['paid_via'] ?? ''),
            'received_date' => (string) ($row['received_date'] ?? ''),
            'comments' => (string) ($row['comments'] ?? ''),
            'status' => strtolower((string) ($row['status'] ?? 'pending')),
            'created_at' => $row['created_at'] ?? null,
            'updated_at' => $row['updated_at'] ?? null,
        ];
    }

    private function mapCustomerInvoiceRow(array $row)
    {
        return [
            'id' => $this->asInt($row['id'] ?? 0),
            'recharge_type' => 'customer_invoice',
            'customer' => $this->asInt($row['user_id'] ?? 0),
            'customer_name' => $this->getUserName($row['user_id'] ?? 0),
            'admin_id' => $this->asInt($row['admin_id'] ?? 0),
            'invoice_number' => (string) ($row['invoice'] ?? ''),
            'amount' => $this->asFloat($row['amount'] ?? 0),
            'received_amount' => $this->asFloat($row['pay_amount'] ?? $row['amount'] ?? 0),
            'paid_via' => (string) ($row['paid_via'] ?? ''),
            'method_trx' => (string) ($row['method_trx'] ?? ''),
            'month' => (string) ($row['month'] ?? ''),
            'paid_to' => $this->asInt($row['paid_to'] ?? 0),
            'paid_to_name' => $this->getUserName($row['paid_to'] ?? 0),
            'paidby' => $this->asInt($row['paidby'] ?? 0),
            'status' => strtolower((string) ($row['status'] ?? 'pending')),
            'received_date' => $row['paid_at'] ?? null,
            'comments' => '',
            'created_at' => $row['created_at'] ?? null,
            'updated_at' => $row['paid_at'] ?? null,
        ];
    }

    private function sortByCreatedAtDesc(array $records)
    {
        usort($records, static function ($a, $b) {
            $aTime = strtotime((string) ($a['created_at'] ?? '1970-01-01 00:00:00'));
            $bTime = strtotime((string) ($b['created_at'] ?? '1970-01-01 00:00:00'));
            return $bTime <=> $aTime;
        });

        return $records;
    }

    private function summarize(array $records)
    {
        $summary = [
            'count' => count($records),
            'total_amount' => 0.0,
            'total_received_amount' => 0.0,
            'successful_count' => 0,
            'pending_count' => 0,
            'failed_count' => 0,
        ];

        foreach ($records as $row) {
            $summary['total_amount'] += $this->asFloat($row['amount'] ?? 0);
            $summary['total_received_amount'] += $this->asFloat($row['received_amount'] ?? 0);

            $status = strtolower((string) ($row['status'] ?? 'pending'));
            if ($status === 'successful') {
                $summary['successful_count']++;
            } elseif ($status === 'pending') {
                $summary['pending_count']++;
            } else {
                $summary['failed_count']++;
            }
        }

        $summary['total_amount'] = round($summary['total_amount'], 2);
        $summary['total_received_amount'] = round($summary['total_received_amount'], 2);

        return $summary;
    }

    /**
     * GET /api/reseller/funding/{resellerId}
     */
    public function fetch($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $reseller = $this->user_model->find($resellerId);
        if (empty($reseller)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Reseller not found']);
        }

        $fromDate = $this->request->getGet('fromDate');
        $toDate = $this->request->getGet('toDate');
        $status = strtolower(trim((string) $this->request->getGet('status')));
        $customerId = $this->asInt($this->request->getGet('customer_id'));
        $rechargeType = $this->normalizeType($this->request->getGet('recharge_type') ?? 'all');

        $fromFilter = $this->normalizeDateForFilter($fromDate, false);
        $toFilter = $this->normalizeDateForFilter($toDate, true);

        $selfRecords = [];
        if ($rechargeType === 'all' || $rechargeType === 'self_recharge') {
            $builder = $this->funding_model->where('customer', (int) $resellerId);

            if ($status !== '') {
                $builder->where('status', $status);
            }
            if (!empty($fromFilter)) {
                $builder->where('created_at >=', $fromFilter);
            }
            if (!empty($toFilter)) {
                $builder->where('created_at <=', $toFilter);
            }

            $rows = $builder->orderBy('id', 'desc')->findAll();
            foreach ($rows as $row) {
                $selfRecords[] = $this->mapSelfRechargeRow($this->toArray($row));
            }
        }

        $invoiceRecords = [];
        if ($rechargeType === 'all' || $rechargeType === 'customer_invoice') {
            $builder = $this->payment_model
                ->where('user_type', 'user')
                ->where('admin_id', (int) $resellerId);

            if ($status !== '') {
                $builder->where('status', $status);
            }
            if ($customerId > 0) {
                $builder->where('user_id', $customerId);
            }
            if (!empty($fromFilter)) {
                $builder->where('created_at >=', $fromFilter);
            }
            if (!empty($toFilter)) {
                $builder->where('created_at <=', $toFilter);
            }

            $rows = $builder->orderBy('id', 'desc')->findAll();
            foreach ($rows as $row) {
                $invoiceRecords[] = $this->mapCustomerInvoiceRow($this->toArray($row));
            }
        }

        $allRecords = $this->sortByCreatedAtDesc(array_merge($selfRecords, $invoiceRecords));

        $data = $allRecords;
        if ($rechargeType === 'self_recharge') {
            $data = $selfRecords;
        } elseif ($rechargeType === 'customer_invoice') {
            $data = $invoiceRecords;
        }

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Funding history fetched successfully',
            'recharge_type' => $rechargeType,
            'current_fund' => round($this->getResellerFund($reseller), 2),
            'summary' => [
                'total_records' => count($data),
                'self_recharge' => $this->summarize($selfRecords),
                'customer_invoice' => $this->summarize($invoiceRecords),
            ],
            'count' => count($data),
            'data' => $data,
            'self_recharge_records' => $selfRecords,
            'customer_invoice_records' => $invoiceRecords,
            'all_records' => $allRecords,
        ]);
    }

    /**
     * POST /api/reseller/funding/{resellerId}
     */
    public function create($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $reseller = $this->user_model->find($resellerId);
        if (empty($reseller)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Reseller not found']);
        }

        $input = $this->request->getJSON(true);
        if (!is_array($input)) {
            $input = $this->request->getPost();
        }
        if (!is_array($input)) {
            $input = [];
        }

        $rechargeType = $this->normalizeType($input['recharge_type'] ?? 'self_recharge');
        if ($rechargeType === 'customer_invoice') {
            return $this->createCustomerInvoice($resellerId, $reseller, $input);
        }

        return $this->createSelfRecharge($resellerId, $reseller, $input);
    }

    private function createSelfRecharge($resellerId, $reseller, array $input)
    {
        $rules = [
            'amount' => 'required|numeric',
            'paid_via' => 'required',
            'status' => 'required|in_list[successful,pending]',
        ];

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'validation-error',
                'errors' => $this->validator->getErrors(),
            ]);
        }

        $insertData = [
            'customer' => (int) $resellerId,
            'admin_id' => $this->getResellerAdminId($reseller, $resellerId),
            'amount' => $this->asFloat($input['amount']),
            'received_amount' => $this->asFloat($input['received_amount'] ?? $input['amount']),
            'invoice_number' => $input['invoice_number'] ?? ('FND-' . random_int(100000, 999999)),
            'paid_via' => $input['paid_via'],
            'received_date' => $input['received_date'] ?? date('Y-m-d'),
            'comments' => $input['comments'] ?? null,
            'status' => $input['status'],
        ];

        $insertId = $this->funding_model->insert($insertData, true);
        if (!$insertId) {
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Insert failed']);
        }

        // Create a payment invoice so this recharge appears in My Payments
        // and can be completed through /api/make-reseller-payment/{paymentId}.
        $paymentData = [
            'user_id' => (int) $resellerId,
            'user_type' => 'resellerAdmin',
            'admin_id' => $this->getResellerAdminId($reseller, $resellerId),
            'paidby' => (int) $resellerId,
            'invoice' => $insertData['invoice_number'],
            'amount' => $insertData['amount'],
            'pay_amount' => $insertData['received_amount'],
            'month' => $input['month'] ?? date('F'),
            'created_at' => date('Y-m-d H:i:s'),
            'status' => $insertData['status'],
            'paid_via' => $insertData['paid_via'] ?? null,
            'paid_to' => (int) $resellerId,
            'method_trx' => $input['method_trx'] ?? null,
        ];

        if (($insertData['status'] ?? '') === 'successful') {
            $paymentData['paid_at'] = date('Y-m-d H:i:s');
        }

        $paymentId = $this->payment_model->insert($paymentData, true);
        if (!$paymentId) {
            // Keep funding + payment creation consistent for app consumers.
            $this->funding_model->delete($insertId);
            return $this->response->setStatusCode(500)->setJSON([
                'status' => 'error',
                'message' => 'Failed to generate payment invoice',
            ]);
        }

        $newFund = $this->getResellerFund($reseller);
        if (($input['status'] ?? '') === 'successful') {
            $newFund += $this->asFloat($input['amount']);
            $this->user_model->update($resellerId, ['fund' => $newFund]);
        }

        $created = $this->funding_model->find($insertId);

        $isPending = (($insertData['status'] ?? '') === 'pending');

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Self recharge funding record created successfully',
            'recharge_type' => 'self_recharge',
            'id' => $insertId,
            'payment_id' => (int) $paymentId,
            'payment_url' => $isPending ? base_url('api/make-reseller-payment/' . (int) $paymentId) : null,
            'current_fund' => round($newFund, 2),
            'data' => $this->mapSelfRechargeRow($this->toArray($created)),
        ]);
    }

    private function createCustomerInvoice($resellerId, $reseller, array $input)
    {
        if (empty($input['customer_id']) && !empty($input['customer'])) {
            $input['customer_id'] = $input['customer'];
        }

        $rules = [
            'customer_id' => 'required|numeric',
            'amount' => 'required|numeric',
            'month' => 'required',
            'status' => 'required|in_list[successful,pending,failed]',
        ];

        if (($input['status'] ?? '') === 'successful') {
            $rules['paid_via'] = 'required';
            $rules['method_trx'] = 'required';
        }

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'validation-error',
                'errors' => $this->validator->getErrors(),
            ]);
        }

        $customerId = $this->asInt($input['customer_id']);
        $customer = $this->user_model
            ->where('id', $customerId)
            ->where('admin_id', (int) $resellerId)
            ->where('role', 'user')
            ->first();

        if (empty($customer)) {
            return $this->response->setStatusCode(404)->setJSON([
                'status' => 'error',
                'message' => 'Customer not found for this reseller',
            ]);
        }

        $invoiceData = [
            'user_id' => $customerId,
            'user_type' => 'user',
            'admin_id' => (int) $resellerId,
            'paidby' => (int) $resellerId,
            'invoice' => $input['invoice_number'] ?? ('INV-' . random_int(100000, 999999)),
            'amount' => $this->asFloat($input['amount']),
            'pay_amount' => $this->asFloat($input['pay_amount'] ?? $input['amount']),
            'month' => $input['month'],
            'paid_via' => $input['paid_via'] ?? null,
            'paid_to' => (int) $resellerId,
            'method_trx' => $input['method_trx'] ?? null,
            'status' => $input['status'],
            'created_at' => date('Y-m-d H:i:s'),
        ];

        if (($input['status'] ?? '') === 'successful') {
            $invoiceData['paid_at'] = $input['paid_at'] ?? date('Y-m-d H:i:s');
        }

        $saved = null;
        $existing = $this->payment_model
            ->where('user_id', $customerId)
            ->where('month', $input['month'])
            ->first();

        if (!empty($existing)) {
            $existingRow = $this->toArray($existing);
            $existingStatus = strtolower((string) ($existingRow['status'] ?? ''));

            if ($existingStatus !== 'successful') {
                $existingId = $this->asInt($existingRow['id'] ?? 0);
                $updated = $this->payment_model->update($existingId, $invoiceData);
                if (!$updated) {
                    return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Invoice update failed']);
                }
                $saved = $this->payment_model->find($existingId);
            } else {
                $saved = $existing;
            }
        } else {
            $insertId = $this->payment_model->insert($invoiceData, true);
            if (!$insertId) {
                return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Invoice creation failed']);
            }
            $saved = $this->payment_model->find($insertId);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Customer invoice recorded successfully',
            'recharge_type' => 'customer_invoice',
            'current_fund' => round($this->getResellerFund($reseller), 2),
            'data' => $this->mapCustomerInvoiceRow($this->toArray($saved)),
        ]);
    }

    /**
     * DELETE /api/reseller/funding/{resellerId}
     */
    public function delete($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $reseller = $this->user_model->find($resellerId);
        if (empty($reseller)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Reseller not found']);
        }

        $input = $this->request->getJSON(true);
        if (!is_array($input)) {
            $input = $this->request->getPost();
        }
        if (!is_array($input)) {
            $input = [];
        }

        $rechargeType = $this->normalizeType($input['recharge_type'] ?? 'self_recharge');
        $ids = $this->normalizeIds($input['ids'] ?? []);
        $selfIds = $this->normalizeIds($input['self_recharge_ids'] ?? []);
        $invoiceIds = $this->normalizeIds($input['invoice_ids'] ?? []);

        if ($rechargeType === 'self_recharge') {
            if (empty($selfIds)) {
                $selfIds = $ids;
            }
            return $this->deleteSelfRecharge($resellerId, $selfIds);
        }

        if ($rechargeType === 'customer_invoice') {
            if (empty($invoiceIds)) {
                $invoiceIds = $ids;
            }
            return $this->deleteCustomerInvoice($resellerId, $invoiceIds);
        }

        if (empty($selfIds)) {
            $selfIds = $ids;
        }
        if (empty($invoiceIds)) {
            $invoiceIds = $ids;
        }

        $deletedSelf = $this->deleteSelfRecharge($resellerId, $selfIds, true);
        $deletedInvoice = $this->deleteCustomerInvoice($resellerId, $invoiceIds, true);

        $newReseller = $this->user_model->find($resellerId);
        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Selected records deleted successfully',
            'recharge_type' => 'all',
            'deleted' => [
                'self_recharge' => $deletedSelf,
                'customer_invoice' => $deletedInvoice,
            ],
            'current_fund' => round($this->getResellerFund($newReseller), 2),
        ]);
    }

    private function deleteSelfRecharge($resellerId, array $ids, $internal = false)
    {
        if (empty($ids)) {
            if ($internal) {
                return ['requested_ids' => [], 'deleted_ids' => [], 'deleted_count' => 0, 'deducted_fund' => 0.0];
            }
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
        }

        $rows = $this->funding_model
            ->where('customer', (int) $resellerId)
            ->whereIn('id', $ids)
            ->findAll();

        $matched = [];
        $totalDeduct = 0.0;

        foreach ($rows as $row) {
            $item = $this->toArray($row);
            $id = $this->asInt($item['id'] ?? 0);
            if ($id > 0) {
                $matched[] = $id;
            }

            if (strtolower((string) ($item['status'] ?? '')) === 'successful') {
                $totalDeduct += $this->asFloat($item['amount'] ?? 0);
            }
        }

        if (empty($matched)) {
            if ($internal) {
                return ['requested_ids' => $ids, 'deleted_ids' => [], 'deleted_count' => 0, 'deducted_fund' => 0.0];
            }
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'No self recharge records found']);
        }

        $result = $this->funding_model
            ->where('customer', (int) $resellerId)
            ->whereIn('id', $matched)
            ->delete();

        if (!$result) {
            if ($internal) {
                return ['requested_ids' => $ids, 'deleted_ids' => [], 'deleted_count' => 0, 'deducted_fund' => 0.0];
            }
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Delete failed']);
        }

        if ($totalDeduct > 0) {
            $reseller = $this->user_model->find($resellerId);
            $currentFund = $this->getResellerFund($reseller);
            $this->user_model->update($resellerId, ['fund' => max(0, $currentFund - $totalDeduct)]);
        }

        $payload = [
            'requested_ids' => $ids,
            'deleted_ids' => $matched,
            'deleted_count' => count($matched),
            'deducted_fund' => round($totalDeduct, 2),
        ];

        if ($internal) {
            return $payload;
        }

        $reseller = $this->user_model->find($resellerId);
        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Self recharge records deleted successfully',
            'recharge_type' => 'self_recharge',
            'current_fund' => round($this->getResellerFund($reseller), 2),
            'deleted' => $payload,
        ]);
    }

    private function deleteCustomerInvoice($resellerId, array $ids, $internal = false)
    {
        if (empty($ids)) {
            if ($internal) {
                return ['requested_ids' => [], 'deleted_ids' => [], 'deleted_count' => 0];
            }
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
        }

        $rows = $this->payment_model
            ->where('user_type', 'user')
            ->where('admin_id', (int) $resellerId)
            ->whereIn('id', $ids)
            ->findAll();

        $matched = [];
        foreach ($rows as $row) {
            $item = $this->toArray($row);
            $id = $this->asInt($item['id'] ?? 0);
            if ($id > 0) {
                $matched[] = $id;
            }
        }

        if (empty($matched)) {
            if ($internal) {
                return ['requested_ids' => $ids, 'deleted_ids' => [], 'deleted_count' => 0];
            }
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'No customer invoice records found']);
        }

        $result = $this->payment_model
            ->where('user_type', 'user')
            ->where('admin_id', (int) $resellerId)
            ->whereIn('id', $matched)
            ->delete();

        if (!$result) {
            if ($internal) {
                return ['requested_ids' => $ids, 'deleted_ids' => [], 'deleted_count' => 0];
            }
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Delete failed']);
        }

        $payload = [
            'requested_ids' => $ids,
            'deleted_ids' => $matched,
            'deleted_count' => count($matched),
        ];

        if ($internal) {
            return $payload;
        }

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Customer invoice records deleted successfully',
            'recharge_type' => 'customer_invoice',
            'deleted' => $payload,
        ]);
    }
}
