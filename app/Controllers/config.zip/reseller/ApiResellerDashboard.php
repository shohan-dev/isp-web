<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;
use App\Models\allResellerPackage;
use App\Models\Package;

class ApiResellerDashboard extends BaseController
{
    protected $user_model;
    protected $payment_model;
    protected $package_model;
    protected $area_model;
    protected $router_model;

    public function __construct()
    {
        $this->user_model = model('App\Models\User');
        $this->payment_model = model('App\Models\Payment');
        $this->package_model = model('App\Models\Package');
        $this->area_model = model('App\Models\Area');
        $this->router_model = model('App\Models\Router');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/dashboard
     * Returns reseller dashboard metrics as JSON
     */
    public function dashboard($id = null)
    {
        // Prefer ID from route. Validate presence.
        $userId = $id;
        if (empty($userId)) {
            return $this->response->setStatusCode(400)->setJSON(['error' => 'Missing route parameter: id']);
        }
        
        
        $details = $this->user_model->where(['id' => $userId])->first();
        $router_id = $details->router_id ?? null;
        $currentTime = date('Y-m-d H:i:s');
        $currentM = date('m');
        $currentYear = date('Y');
        $currentMonth = date('F');

        $sum = $this->payment_model
            ->selectSum('amount')
            ->where('admin_id', $userId)
            ->where('month', $currentMonth)
            ->where(['user_type' => 'user', 'status' => 'successful'])
            ->first();

        $customers_payment_received = (int) ($sum->amount ?? 0);

        $customers_payment_received_count = (int) $this->payment_model
            ->where('admin_id', $userId)
            ->where('month', $currentMonth)
            ->where(['user_type' => 'user', 'status' => 'successful'])
            ->countAllResults();

        $userIds = (int) $this->user_model->select('id')->where('admin_id', $userId)->where('role', 'user')->countAllResults();

        log_message('debug', 'userId customers_payment_received_count: ' . $customers_payment_received_count);
        log_message('debug', 'userIds insertId: ' . $userIds);

        $packagePrice = $this->getPackagePrice($userId, $details->role);


        $customers_payment_pending_res = $this->payment_model
            ->selectSum('amount')
            ->where('admin_id', $userId)
            ->where('month', $currentMonth)
            ->where(['user_type' => 'user', 'status' => 'pending'])
            ->first();

        $employee_payment_received_res = $this->payment_model
            ->selectSum('amount')
            ->where('admin_id', $userId)
            ->where(['user_type' => 'employee', 'status' => 'successful'])
            ->first();

        $employees_payment_pending_res = $this->payment_model
            ->selectSum('amount')
            ->where('admin_id', $userId)
            ->where(['user_type' => 'employee', 'status' => 'pending'])
            ->first();

        $data = [
            'customers_payment_received' => $customers_payment_received,
            'customers_payment_total' => $packagePrice,
            'customers_Expayment_total' => ($packagePrice > 0) ? $packagePrice - $customers_payment_received : 0,
            'customers_Expayment_count' => ($userIds > 0) ? $userIds - $customers_payment_received_count : 0,
            'customers_payment_received_count' => $customers_payment_received_count,
            'customers_payment_pending' => (int) ($customers_payment_pending_res->amount ?? 0),
            'employee_payment_received' => (int) ($employee_payment_received_res->amount ?? 0),
            'employees_payment_pending' => (int) ($employees_payment_pending_res->amount ?? 0),

            'users_active' => (int) $this->user_model
                ->where(['role' => 'user', 'admin_id' => $userId, 'subscription_status' => 'active'])
                ->where('will_expire >', $currentTime)
                ->countAllResults(),
            'users_new' => (int) $this->user_model
                ->where(['role' => 'user', 'admin_id' => $userId])
                ->where("MONTH(created_at) = $currentM", null, false)
                ->where("YEAR(created_at) = $currentYear", null, false)
                ->countAllResults(),
            'users_inactive' => (int) $this->user_model
                ->where('role', 'user')
                ->where('admin_id', $userId)
                ->groupStart()
                ->where('conn_status', 'disconn')
                ->where('will_expire >', $currentTime)
                ->groupEnd()
                ->countAllResults(),
            'expired_inactive' => (int) $this->user_model
                ->where('role', 'user')
                ->where('admin_id', $userId)
                ->groupStart()
                ->where('will_expire <', $currentTime)
                ->groupEnd()
                ->countAllResults(),
            'employee_active' => (int) $this->user_model->where(['role' => 'employee', 'admin_id' => $userId, 'status' => 'active'])->countAllResults(),
            'employee_inactive' => (int) $this->user_model->where(['role' => 'employee', 'admin_id' => $userId, 'status' => 'inactive'])->countAllResults(),

            'total_packages' => (int) $this->package_model->where(['status' => 'active'])->where('user_id', $userId)->countAllResults(),
            'total_area' => (int) $this->area_model->where(['status' => 'active'])->where('user_id', $userId)->countAllResults(),

            'router_active' => (int) $this->router_model->where(['status' => 'active'])->where('user_id', $userId)->countAllResults(),
            'router_inactive' => (int) $this->router_model->where(['status' => 'inactive'])->where('user_id', $userId)->countAllResults(),

            'customer_payment_statistics' => $this->statistics('user', null, $userId),
            'employee_payment_statistics' => $this->statistics('employee', null, $userId),

            'routers' => $this->router_model->where('status', 'active')->where('id', $router_id)->findAll(),
        ];

        return $this->response->setJSON(['status' => 'success', 'data' => $data]);
    }

    function getPackagePrice($userId, $userRole)
    {
        $totalPrice = 0;
        $ConnectionDetails = model('App\Models\ConnectionData');

        if ($userRole === 'sAdmin') {


            $totalPrice = 0;
            $userModel = model('App\Models\User');
            // $details = $userModel->where(['admin_id' => $userId])->first();
            // $userIds = $userModel->select('id')->where('admin_id', $userId)->where('role', 'user')->where('subscription_status', 'active')->findAll();
            $userIds = $userModel->select('id')->where('admin_id', $userId)->where('role', 'user')->findAll();




            // $userRegister = $this->reseller_model->select('discount')->where('userid', $userId)->first();
            // log_message('info', 'Payment $userRegister: ' . json_encode($userRegister));
            // $discount = $userRegister['discount'] ?? 0;

            $packageIds = [];
            foreach ($userIds as $user) {
                $existingRecord = $ConnectionDetails->where('user_id', $user->id)->first();
                if (!empty($existingRecord)) {
                    // log_message('info', 'Existing Record: ' . print_r($existingRecord, true));
                    $billing_status = $existingRecord->billing_status ?? $existingRecord['billing_status'];
                    if ($billing_status === 'free' || $billing_status === 'Free') {
                        continue; // Skip this user and move to the next iteration
                    }
                }


                $packageId = $userModel->select('package_id')->where('id', $user->id)->first();
                if ($packageId) {
                    $packageIds[] = $packageId;
                }
            }
            $resellerPackageSimpleModel = new Package();
            // $packagePrices = [];

            foreach ($packageIds as $packageId) {
                // log_message('info', 'Package IDs $packageId->package_id: ' . json_encode($packageId->package_id));

                $packagePrice = $resellerPackageSimpleModel->where('id', $packageId->package_id)->first();
                // log_message('info', 'Package IDs: packagePrice' . json_encode($packagePrice));

                if ($packagePrice) {
                    // $packagePrices[] = $packagePrice;
                    if (is_array($packagePrice)) {
                        $totalPrice += $packagePrice['price'];
                    }
                    elseif (is_object($packagePrice)) {
                        $totalPrice += $packagePrice->price;
                    }
                }

            // foreach ($packagePrices as $packagePrice) {
            //     $packageDetails = json_decode($packagePrice['package_details'], true);
            //     foreach ($packageDetails as $detail) {
            //         if ($detail['id'] == $packageId->package_id) {
            //             // log_message('info', 'Package Price: ' . $detail['price']);

            //         $totalPrice += $detail['price'];
            //         // log_message('info', 'Total Price: ' . $totalPrice);
            //         }
            //     }
            // }
            }
        }
        if ($userRole === 'resellerAdmin') {
            $userModel = model('App\Models\User');
            // $details = $userModel->where(['admin_id' => $userId])->first();
            // $userIds = $userModel->select('id')->where('admin_id', $userId)->where('role', 'user')->where('subscription_status', 'active')->findAll();
            $userIds = $userModel->select('id')->where('admin_id', $userId)->where('role', 'user')->findAll();
            // $reseller_model = new Registration();
            // $userRegister = $reseller_model->select('discount')->where('userid', $userId)->first();
            log_message('info', 'Payment $userIds: ' . json_encode($userIds));
            // $discount = $userRegister['discount'] ?? 0;

            $packageIds = [];
            foreach ($userIds as $user) {
                $existingRecord = $ConnectionDetails->where('user_id', $user->id)->first();
                if (!empty($existingRecord)) {
                    // log_message('info', 'Existing Record: ' . print_r($existingRecord, true));
                    $billing_status = $existingRecord->billing_status ?? $existingRecord['billing_status'];
                    if ($billing_status === 'free' || $billing_status === 'Free') {
                        continue; // Skip this user and move to the next iteration
                    }
                }
                $packageId = $userModel->select('package_id')->where('id', $user->id)->first();
                if ($packageId) {
                    $packageIds[] = $packageId;
                }
            }
            $resellerPackageSimpleModel = new allResellerPackage();
            $packagePrices = [];


            // log_message('info', 'Package IDs $packageId->package_id: ' . json_encode($packageId->package_id));

            $packagePrice = $resellerPackageSimpleModel->where('user_id', $userId)->first();
            // log_message('info', 'Package IDs: packagePrice' . json_encode($packagePrice));

            if ($packagePrice) {
                $packagePrices[] = $packagePrice;
            }

            $i = 0;
            foreach ($packageIds as $packageId) {
                foreach ($packagePrices as $packagePrice) {
                    // log_message('info', 'Total Price: ' . $totalPrice);
                    $packageDetails = json_decode($packagePrice['package_details'], true);
                    foreach ($packageDetails as $detail) {
                        if ($detail['id'] == $packageId->package_id) {

                            log_message('info', 'Package Price: ' . print_r($detail, true));
                            $detailprice = (is_numeric($detail['selling_price']) && $detail['selling_price'] > 0)
                                ? $detail['selling_price']
                                : (is_numeric($detail['price']) ? $detail['price'] : 0);

                            $totalPrice += (int)$detailprice;




                            log_message('info', 'Package Price: ' . $i++ . ':' . $detailprice . ' => Total: ' . $totalPrice);
                        }
                    }
                }
            }

        // if ($discount > 0) {
        //     $totalPrice = $totalPrice - ($totalPrice * ($discount / 100));
        //     log_message('info', 'Total Price after discount: ' . $totalPrice);
        // }


        }
        log_message('info', 'Package IDs: totalPrice' . json_encode($totalPrice));

        return $totalPrice ?? null;
    }

    /**
     * Payment statistics by month for a role (API version).
     * @param string|null $role
     * @param int|null $user_id
     * @param int|null $admin_id
     * @return array
     */
    protected function statistics($role = null, $user_id = null, $admin_id = null)
    {
        $months = [];
        $success_payment = [];
        $pending_payment = [];
        $failed_payment = [];

        $currentMonthNumber = (int) date('m');

        for ($i = 1; $i <= $currentMonthNumber; $i++) {
            $monthName = date('F', mktime(0, 0, 0, $i, 1, (int) date('Y')));

            $successful = $this->__transactionStatistics('successful', $monthName, $role, $user_id, $admin_id);
            $pending = $this->__transactionStatistics('pending', $monthName, $role, $user_id, $admin_id);
            $failed = $this->__transactionStatistics('failed', $monthName, $role, $user_id, $admin_id);

            array_push($months, date('M', mktime(0, 0, 0, $i, 1, (int) date('Y'))));
            array_push($success_payment, $successful);
            array_push($pending_payment, $pending);
            array_push($failed_payment, $failed);
        }

        return [
            'months' => $months,
            'successful' => $success_payment,
            'pending' => $pending_payment,
            'failed' => $failed_payment,
        ];
    }

    /**
     * Transaction statistics helper for API.
     */
    protected function __transactionStatistics($status, $month, $role = null, $user_id = null, $admin_id = null)
    {
        $conditions = [
            'month' => $month,
            'status' => $status,
        ];

        if (!empty($role)) {
            $conditions['user_type'] = $role;
        }

        if (!empty($user_id)) {
            $conditions['user_id'] = $user_id;
        }

        if (!empty($admin_id)) {
            $conditions['admin_id'] = $admin_id;
        }

        $row = $this->payment_model->selectSum('amount')->where($conditions)->first();

        return (int) ($row->amount ?? 0);
    }
}