<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerRouter extends BaseController
{
    protected $user_model;
    protected $router_model;

    public function __construct()
    {
        $this->user_model = model('App\Models\User');
        $this->router_model = model('App\Models\Router');
        helper(['url', 'user', 'router']);
    }

    /**
     * GET /api/reseller/router-users/{resellerId}/{routerId}
     */
    public function fetch($resellerId = null, $routerId = null)
    {
        if (empty($resellerId) || empty($routerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or router id']);
        }

        $customers = $this->user_model
            ->select('pppoe_id')
            ->where('admin_id', $resellerId)
            ->findAll();

        $pppoeIds = array_filter(array_map(function ($item) {
            return trim((string) (is_object($item) ? ($item->pppoe_id ?? '') : ($item['pppoe_id'] ?? '')));
        }, $customers));

        if (!function_exists('routerClient') || !function_exists('getSystemResources')) {
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Router helper functions not available']);
        }

        $routerClient = routerClient($routerId);

        if (is_array($routerClient)) {
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Cannot connect to router']);
        }

        $data = getSystemResources($routerClient);

        $allUsers = $data['data']['allusers'] ?? [];
        $activeUsers = $data['data']['activeusers'] ?? [];

        $filteredAll = [];
        $validNames = [];

        foreach ($allUsers as $user) {
            $userId = trim((string) ($user['.id'] ?? ''));
            if (in_array($userId, $pppoeIds, true)) {
                $filteredAll[] = $user;
                $name = trim((string) ($user['name'] ?? ''));
                if ($name !== '') {
                    $validNames[] = $name;
                }
            }
        }

        $filteredActive = [];
        foreach ($activeUsers as $activeUser) {
            $activeName = trim((string) ($activeUser['name'] ?? ''));
            if (in_array($activeName, $validNames, true)) {
                $filteredActive[] = $activeUser;
            }
        }

        $totalUsers = count($filteredAll);
        $onlineUsers = count($filteredActive);
        $offlineUsers = $totalUsers - $onlineUsers;

        return $this->response->setJSON([
            'status' => 'success',
            'data' => [
                'total_users' => $totalUsers,
                'users_online' => $onlineUsers,
                'users_offline' => $offlineUsers,
                'all_users' => $filteredAll,
                'active_users' => $filteredActive,
            ],
        ]);
    }

    /**
     * GET /api/reseller/routers/{resellerId}
     */
    public function list($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $reseller = $this->user_model->find($resellerId);
        $routerId = $reseller->router_id ?? null;

        if (empty($routerId)) {
            return $this->response->setJSON(['status' => 'success', 'data' => []]);
        }

        $routers = $this->router_model->where('id', $routerId)->where('status', 'active')->findAll();

        return $this->response->setJSON(['status' => 'success', 'data' => $routers]);
    }
}
