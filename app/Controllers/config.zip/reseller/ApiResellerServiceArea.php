<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;
use App\Models\Area as AreaModel;
use App\Models\AreaSub as AreaSubModel;

/**
 * Reseller service areas — mirrors web {@see \App\Controllers\Area} (fetch/create/sub/update/delete).
 */
class ApiResellerServiceArea extends BaseController
{
    protected $area_model;
    protected $subarea_model;

    public function __construct()
    {
        $this->area_model = model(AreaModel::class);
        $this->subarea_model = model(AreaSubModel::class);
        helper(['url', 'user']);
    }

    /**
     * @return array<string, mixed>
     */
    protected function getJsonInput(): array
    {
        $json = $this->request->getJSON(true);
        if (is_array($json) && !empty($json)) {
            return $json;
        }
        $post = $this->request->getPost();
        if (is_array($post) && !empty($post)) {
            return $post;
        }
        $raw = $this->request->getRawInput();
        if (is_array($raw) && !empty($raw)) {
            return $raw;
        }
        if (is_array($json)) {
            return $json;
        }

        return [];
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, string>|null
     */
    protected function validationErrors(array $input, array $rules): ?array
    {
        $validation = \Config\Services::validation();
        $validation->setRules($rules);
        if ($validation->run($input)) {
            return null;
        }

        return $validation->getErrors();
    }

    /**
     * @param array<string, mixed> $input
     * @return int[]
     */
    protected function normalizeIds(array $input): array
    {
        if (isset($input['ids']) && is_array($input['ids'])) {
            return array_map('intval', $input['ids']);
        }

        return [];
    }

    /**
     * GET /api/reseller/areas/{resellerId}
     */
    public function index($resellerId = null)
    {
        $resellerId = (int) $resellerId;
        if ($resellerId <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $areas = $this->area_model->where('user_id', $resellerId)->orderBy('id', 'desc')->findAll();

        return $this->response->setJSON(['status' => 'success', 'data' => $areas]);
    }

    /**
     * GET /api/reseller/areas/{resellerId}/sub/{parentAreaId}
     * Sub-rows use user_id = parent area id (same as Area::fetchsub / subcreate).
     */
    public function subindex($resellerId = null, $parentAreaId = null)
    {
        $resellerId = (int) $resellerId;
        $parentAreaId = (int) $parentAreaId;
        if ($resellerId <= 0 || $parentAreaId <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or parent area id']);
        }

        $parent = $this->area_model->find($parentAreaId);
        if (empty($parent) || (string) $parent->user_id !== (string) $resellerId) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Area not found']);
        }

        $subareas = $this->subarea_model->where('user_id', $parentAreaId)->orderBy('id', 'desc')->findAll();

        return $this->response->setJSON(['status' => 'success', 'data' => $subareas]);
    }

    /**
     * POST /api/reseller/areas/{resellerId?}
     * Body: area_name, area_code, status (active|inactive)
     */
    public function create($resellerId = null)
    {
        $input = $this->getJsonInput();
        $rid = $resellerId !== null && $resellerId !== ''
            ? (int) $resellerId
            : (int) ($input['user_id'] ?? $input['reseller_id'] ?? 0);

        if ($rid <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $rules = [
            'area_name' => 'required',
            'area_code' => 'required',
            'status' => 'required|in_list[active,inactive]',
        ];

        $vErr = $this->validationErrors($input, $rules);
        if ($vErr !== null) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $vErr]);
        }

        $data = [
            'user_id' => $rid,
            'area_name' => $input['area_name'],
            'area_code' => $input['area_code'],
            'status' => $input['status'],
        ];

        $id = $this->area_model->insert($data, false);

        if ($id) {
            return $this->response->setStatusCode(201)->setJSON([
                'status' => 'success',
                'message' => 'Service area added successfully',
                'id' => $id,
                'data' => $this->area_model->find($id),
            ]);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Something went wrong! Please try again']);
    }

    /**
     * POST /api/reseller/subareas
     * Body: reseller_id, user_id (parent area id), area_name, area_code, status
     */
    public function subcreate()
    {
        $input = $this->getJsonInput();
        $parentAreaId = (int) ($input['user_id'] ?? $input['parent_area_id'] ?? $input['id'] ?? 0);
        $resellerId = (int) ($input['reseller_id'] ?? 0);

        if ($parentAreaId <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing parent area id']);
        }

        $parent = $this->area_model->find($parentAreaId);
        if (empty($parent)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Parent area not found']);
        }

        if ($resellerId > 0 && (string) $parent->user_id !== (string) $resellerId) {
            return $this->response->setStatusCode(403)->setJSON(['status' => 'error', 'message' => 'Parent area does not belong to this reseller']);
        }

        $rules = [
            'area_name' => 'required|is_unique[sub_areas.area_name]',
            'area_code' => 'required',
            'status' => 'required|in_list[active,inactive]',
        ];

        $vErr = $this->validationErrors($input, $rules);
        if ($vErr !== null) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $vErr]);
        }

        $data = [
            'user_id' => $parentAreaId,
            'area_name' => $input['area_name'],
            'area_code' => $input['area_code'],
            'status' => $input['status'],
        ];

        $id = $this->subarea_model->insert($data, false);

        if ($id) {
            return $this->response->setStatusCode(201)->setJSON([
                'status' => 'success',
                'message' => 'Service area added successfully',
                'id' => $id,
                'data' => $this->subarea_model->find($id),
            ]);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Something went wrong! Please try again']);
    }

    /**
     * GET /api/reseller/areas/edit/{id}
     */
    public function edit($id = null)
    {
        $id = (int) $id;
        if ($id <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing id']);
        }

        $details = $this->area_model->find($id);
        if (empty($details)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Not found']);
        }

        return $this->response->setJSON(['status' => 'success', 'data' => $details]);
    }

    /**
     * GET /api/reseller/subareas/edit/{id}
     */
    public function editsub($id = null)
    {
        $id = (int) $id;
        if ($id <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing id']);
        }

        $details = $this->subarea_model->find($id);
        if (empty($details)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Not found']);
        }

        return $this->response->setJSON(['status' => 'success', 'data' => $details]);
    }

    /**
     * PUT /api/reseller/areas/update/{id}
     * Body: reseller_id (recommended), area_name, area_code, status
     */
    public function update($id = null)
    {
        $id = (int) $id;
        if ($id <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing id']);
        }

        $input = $this->getJsonInput();
        $rid = (int) ($input['reseller_id'] ?? 0);
        if ($rid <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $area = $this->area_model->find($id);
        if (empty($area)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Not found']);
        }

        if ((string) $area->user_id !== (string) $rid) {
            return $this->response->setStatusCode(403)->setJSON(['status' => 'error', 'message' => 'Area does not belong to this reseller']);
        }

        $rules = [
            'area_name' => 'required',
            'area_code' => 'required',
            'status' => 'required|in_list[active,inactive]',
        ];

        $vErr = $this->validationErrors($input, $rules);
        if ($vErr !== null) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $vErr]);
        }

        $data = [
            'area_name' => $input['area_name'],
            'area_code' => $input['area_code'],
            'status' => $input['status'],
        ];

        $res = $this->area_model->update($id, $data);

        if ($res !== false) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Service area updated successfully',
                'data' => $this->area_model->find($id),
            ]);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Something went wrong! Please try again']);
    }

    /**
     * PUT /api/reseller/subareas/update/{id}
     * Body: reseller_id (recommended), area_name, area_code, status
     */
    public function updatesub($id = null)
    {
        $id = (int) $id;
        if ($id <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing id']);
        }

        $input = $this->getJsonInput();
        $rid = (int) ($input['reseller_id'] ?? 0);
        if ($rid <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $sub = $this->subarea_model->find($id);
        if (empty($sub)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Not found']);
        }

        $parent = $this->area_model->find($sub->user_id);
        if (empty($parent) || (string) $parent->user_id !== (string) $rid) {
            return $this->response->setStatusCode(403)->setJSON(['status' => 'error', 'message' => 'Sub area does not belong to this reseller']);
        }

        $rules = [
            'area_name' => 'required',
            'area_code' => 'required',
            'status' => 'required|in_list[active,inactive]',
        ];

        $vErr = $this->validationErrors($input, $rules);
        if ($vErr !== null) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $vErr]);
        }

        $data = [
            'area_name' => $input['area_name'],
            'area_code' => $input['area_code'],
            'status' => $input['status'],
        ];

        $res = $this->subarea_model->update($id, $data);

        if ($res !== false) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Service area updated successfully',
                'data' => $this->subarea_model->find($id),
            ]);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Something went wrong! Please try again']);
    }

    /**
     * DELETE /api/reseller/areas/{resellerId}/delete
     * DELETE /api/reseller/areas/delete  (body: reseller_id + ids)
     * Body: { "ids": [1,2,3] }
     */
    public function delete($resellerId = null)
    {
        $input = $this->getJsonInput();
        $ids = $this->normalizeIds($input);

        if (empty($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing is selected']);
        }

        $rid = (int) ($resellerId ?? $input['reseller_id'] ?? 0);
        if ($rid <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        foreach ($ids as $aid) {
            $a = $this->area_model->find($aid);
            if (empty($a)) {
                return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Area not found']);
            }
            if ((string) $a->user_id !== (string) $rid) {
                return $this->response->setStatusCode(403)->setJSON(['status' => 'error', 'message' => 'Invalid area selection']);
            }
        }

        $res = $this->area_model->whereIn('id', $ids)->delete();

        if ($res) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Selected records deleted successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Something went wrong! Please try again']);
    }

    /**
     * DELETE /api/reseller/subareas/delete
     * Body: { "reseller_id": N, "ids": [1,2,3] }
     */
    public function deletesub()
    {
        $input = $this->getJsonInput();
        $ids = $this->normalizeIds($input);

        if (empty($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing is selected']);
        }

        $rid = (int) ($input['reseller_id'] ?? 0);
        if ($rid <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        foreach ($ids as $sid) {
            $sub = $this->subarea_model->find($sid);
            if (empty($sub)) {
                return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Sub area not found']);
            }
            $parent = $this->area_model->find($sub->user_id);
            if (empty($parent) || (string) $parent->user_id !== (string) $rid) {
                return $this->response->setStatusCode(403)->setJSON(['status' => 'error', 'message' => 'Invalid sub area selection']);
            }
        }

        $res = $this->subarea_model->whereIn('id', $ids)->delete();

        if ($res) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Selected records deleted successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Something went wrong! Please try again']);
    }
}
