<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;
use App\Models\AuditLogModel;
use Config\Database;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ApiResellerCustomer extends BaseController
{
    protected $user_model;
    protected $userRouterDataModel;
    protected $db;

    public function __construct()
    {
        $this->user_model = model('App\Models\User');
        $this->userRouterDataModel = model('App\Models\UserRouterDataModel');
        $this->db = Database::connect();
        helper(['url', 'user', 'router']);
    }

    private function toArray($row)
    {
        if (is_array($row)) {
            return $row;
        }

        return is_object($row) ? (array) $row : [];
    }

    private function normalizeIds($ids)
    {
        if (is_string($ids)) {
            $decoded = json_decode($ids, true);
            if (is_array($decoded)) {
                $ids = $decoded;
            } else {
                $ids = array_filter(array_map('trim', explode(',', $ids)), 'strlen');
            }
        }

        if (!is_array($ids)) {
            return null;
        }

        $normalized = [];
        foreach ($ids as $id) {
            if (is_numeric($id) && (int) $id > 0) {
                $normalized[] = (int) $id;
            }
        }

        return array_values(array_unique($normalized));
    }

    /**
     * Robustly read the request body as an associative array.
     * Works for POST, DELETE, PUT, PATCH regardless of Content-Type.
     */
    private function getInput(): array
    {
        $input = $this->request->getJSON(true);
        if (is_array($input) && !empty($input)) {
            return $input;
        }

        $input = $this->request->getPost();
        if (is_array($input) && !empty($input)) {
            return $input;
        }

        $raw = $this->request->getRawInput();
        if (is_array($raw) && !empty($raw)) {
            return $raw;
        }

        $body = $this->request->getBody();
        if (!empty($body)) {
            $decoded = json_decode($body, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }

        return [];
    }

    private function asInt($value)
    {
        return (int) (is_numeric($value) ? $value : 0);
    }

    private function asFloat($value)
    {
        return (float) (is_numeric($value) ? $value : 0);
    }

    private function asString($value, $fallback = '--')
    {
        if ($value === null) {
            return $fallback;
        }

        $text = trim((string) $value);
        if ($text === '' || strtolower($text) === 'null') {
            return $fallback;
        }

        return $text;
    }

    private function getConnectionDetails($userId)
    {
        $row = $this->db->table('connection_details')->where('user_id', (int) $userId)->get()->getRowArray();
        return !empty($row) ? $row : null;
    }

    private function saveConnectionDetails($userId, array $payload)
    {
        $allowed = [
            'sub_area_id',
            'connection_type',
            'cable_requirement',
            'fiber_code',
            'number_of_core',
            'core_color',
            'client_type',
            'billing_status',
            'otc',
            'otc_status',
        ];

        $data = [];
        foreach ($allowed as $field) {
            if (array_key_exists($field, $payload)) {
                $data[$field] = $payload[$field];
            }
        }

        if (empty($data)) {
            return;
        }

        $existing = $this->db->table('connection_details')->where('user_id', (int) $userId)->get()->getRowArray();

        if (!empty($existing) && !empty($existing['id'])) {
            $this->db->table('connection_details')->where('id', (int) $existing['id'])->update($data);
            return;
        }

        $data['user_id'] = (int) $userId;
        $this->db->table('connection_details')->insert($data);
    }

    private function getPppoeDetails(array $customer, $allowRouterLookup = false)
    {
        $pppoe = [
            'pppoe_name' => '--',
            'pppoe_password' => '--',
            'pppoe_service' => '--',
            'pppoe_profile' => '--',
            'pppoe_uptime' => '--',
            'pppoe_address' => '--',
            'pppoe_caller_id' => '--',
            'pppoe_last_logged_out' => '--',
            'pppoe_last_caller_id' => '--',
            'pppoe_last_disconnect_reason' => '--',
            'pppoe_disabled' => '--',
            'pppoe_comment' => '--',
        ];

        if (function_exists('getRouterPassById')) {
            $credentials = getRouterPassById((int) ($customer['id'] ?? 0));
            if (is_array($credentials)) {
                $pppoe['pppoe_name'] = $credentials['pppoe_secret'] ?? '--';
                $pppoe['pppoe_password'] = $credentials['router_password'] ?? '--';
            }
        }

        if ($allowRouterLookup && function_exists('routerClient') && function_exists('getPPPoEUser')) {
            $routerId = $customer['router_id'] ?? null;
            $pppoeId = $customer['pppoe_id'] ?? null;

            if (!empty($routerId) && !empty($pppoeId)) {
                $routerClient = routerClient($routerId);
                if ($routerClient instanceof \RouterOS\Client) {
                    $userPpp = getPPPoEUser($routerClient, $pppoeId);
                    $pppRow = $userPpp[0] ?? [];
                    if (!empty($pppRow)) {
                        $pppoe['pppoe_name'] = $pppRow['name'] ?? $pppoe['pppoe_name'];
                        $pppoe['pppoe_password'] = $pppRow['password'] ?? $pppoe['pppoe_password'];
                        $pppoe['pppoe_service'] = $pppRow['service'] ?? '--';
                        $pppoe['pppoe_profile'] = $pppRow['profile'] ?? '--';
                        $pppoe['pppoe_uptime'] = $pppRow['uptime'] ?? '--';
                        $pppoe['pppoe_address'] = $pppRow['address'] ?? '--';
                        $pppoe['pppoe_caller_id'] = $pppRow['caller-id'] ?? '--';
                        $pppoe['pppoe_last_logged_out'] = $pppRow['last-logged-out'] ?? '--';
                        $pppoe['pppoe_last_caller_id'] = $pppRow['last-caller-id'] ?? '--';
                        $pppoe['pppoe_last_disconnect_reason'] = $pppRow['last-disconnect-reason'] ?? '--';
                        $pppoe['pppoe_disabled'] = $pppRow['disabled'] ?? '--';
                        $pppoe['pppoe_comment'] = $pppRow['comment'] ?? '--';
                    }
                }
            }
        }

        return $pppoe;
    }

    private function enrichCustomer($customer, $allowRouterLookup = false)
    {
        $row = $this->toArray($customer);
        if (empty($row)) {
            return [];
        }

        $row['area_name'] = function_exists('getAreaNameById') ? (getAreaNameById($row) ?? '--') : '--';
        $row['router_name'] = function_exists('getRouterById') ? (getRouterById($row['router_id'] ?? null)->name ?? '--') : '--';

        $package = function_exists('getUserPackage') ? getUserPackage((int) $row['id']) : null;
        $packageArr = $this->toArray($package);
        $row['package'] = $packageArr;
        $row['package_name'] = $packageArr['package_name'] ?? $packageArr['name'] ?? '--';
        $row['package_price'] = $packageArr['selling_price'] ?? $packageArr['price'] ?? '--';

        $pppoe = $this->getPppoeDetails($row, $allowRouterLookup);
        $row['pppoe_name'] = $pppoe['pppoe_name'];
        $row['pppoe_password'] = $pppoe['pppoe_password'];
        $row['pppoe_service'] = $pppoe['pppoe_service'];
        $row['pppoe_profile'] = $pppoe['pppoe_profile'];
        $row['pppoe_uptime'] = $pppoe['pppoe_uptime'];
        $row['pppoe_address'] = $pppoe['pppoe_address'];
        $row['pppoe_caller_id'] = $pppoe['pppoe_caller_id'];
        $row['pppoe_last_logged_out'] = $pppoe['pppoe_last_logged_out'];
        $row['pppoe_last_caller_id'] = $pppoe['pppoe_last_caller_id'];
        $row['pppoe_last_disconnect_reason'] = $pppoe['pppoe_last_disconnect_reason'];
        $row['pppoe_disabled'] = $pppoe['pppoe_disabled'];
        $row['pppoe_comment'] = $pppoe['pppoe_comment'];
        $row['secret'] = $pppoe['pppoe_name'];
        $row['router_password'] = $pppoe['pppoe_password'];

        $connectionDetails = $this->getConnectionDetails((int) $row['id']);
        $row['connection_details'] = $connectionDetails;

        if (!empty($connectionDetails)) {
            foreach ($connectionDetails as $key => $value) {
                if (!array_key_exists($key, $row)) {
                    $row[$key] = $value;
                }
            }
        }

        return $row;
    }

    private function getMacBinding($customerId)
    {
        if (!function_exists('isMacBound')) {
            return [
                'is_bound' => false,
                'mac' => '--',
                'label' => 'Not Bound',
            ];
        }

        $result = isMacBound((int) $customerId);
        $isBound = is_array($result) ? ((bool) ($result['status'] ?? false)) : false;
        $mac = is_array($result) ? ($result['mac'] ?? '--') : '--';

        return [
            'is_bound' => $isBound,
            'mac' => $this->asString($mac),
            'label' => $isBound ? 'Bound' : 'Not Bound',
        ];
    }

    private function getOltOnuDetails(array $customer)
    {
        $defaultOnu = [
            'onu_id' => '--',
            'mac' => '--',
            'status' => '--',
            'rx' => '--',
            'reason' => '--',
            'last_seen' => '--',
            'description' => '--',
            'olt_name' => '--',
            'available' => false,
        ];

        // Try to use pppoe_caller_id (MAC address) to fetch ONU details
        $callerid = trim((string) ($customer['pppoe_caller_id'] ?? $customer['pppoe_last_caller_id'] ?? ''));

        if (empty($callerid) || $callerid === '--') {
            return $defaultOnu;
        }

        try {
            // Use OltController to fetch ONU details
            if (!class_exists('App\Controllers\OltController')) {
                return $defaultOnu;
            }

            $oltController = new \App\Controllers\OltController();
            $onu = $oltController->getOnuByMac($callerid);

            if (empty($onu) || !is_array($onu)) {
                return $defaultOnu;
            }

            // Map ONU data and mark as available if we have valid data
            $result = [
                'onu_id' => $this->asString($onu['onu_id'] ?? '--'),
                'mac' => $this->asString($onu['mac'] ?? '--'),
                'status' => $this->asString($onu['status'] ?? '--'),
                'rx' => $this->asString($onu['rx'] ?? '--'),
                'reason' => $this->asString($onu['reason'] ?? '--'),
                'last_seen' => $this->asString($onu['last_seen'] ?? '--'),
                'description' => $this->asString($onu['description'] ?? '--'),
                'olt_name' => $this->asString($onu['olt_name'] ?? '--'),
                'available' => !($this->asString($onu['onu_id'] ?? '--') === 'Not Found'),
            ];

            return $result;
        } catch (\Throwable $e) {
            return $defaultOnu;
        }
    }

    private function getTrafficSnapshot(array $customer)
    {
        $routerId = $this->asInt($customer['router_id'] ?? 0);
        $pppoeName = trim((string) ($customer['pppoe_name'] ?? $customer['secret'] ?? $customer['pppoe_id'] ?? ''));

        $payload = [
            'rxbyte' => 0.0,
            'txbyte' => 0.0,
            'unit' => 'Mbps',
            'caller_id' => $this->asString($customer['pppoe_caller_id'] ?? null),
            'updated_at' => date('Y-m-d H:i:s'),
            'available' => false,
        ];

        if ($routerId <= 0 || $pppoeName === '') {
            return $payload;
        }

        if (!function_exists('routerClient') || !function_exists('getusersSystemResources')) {
            return $payload;
        }

        $routerClient = routerClient($routerId);
        if (!($routerClient instanceof \RouterOS\Client)) {
            return $payload;
        }

        try {
            $resource = getusersSystemResources($routerClient, $pppoeName, '');
            $traffic = $resource['data']['traffic'] ?? [];

            if (is_array($traffic) && isset($traffic[0]) && is_array($traffic[0])) {
                $traffic = $traffic[0];
            }

            if (is_array($traffic)) {
                $payload['rxbyte'] = $this->asFloat($traffic['rxbyte'] ?? $traffic['rx'] ?? 0);
                $payload['txbyte'] = $this->asFloat($traffic['txbyte'] ?? $traffic['tx'] ?? 0);
                $payload['available'] = true;
            }

            $activeUsers = $resource['data']['activeusers'] ?? [];
            if (is_array($activeUsers)) {
                foreach ($activeUsers as $activeUser) {
                    if (!is_array($activeUser)) {
                        continue;
                    }

                    $activeName = trim((string) ($activeUser['name'] ?? ''));
                    if ($activeName === $pppoeName) {
                        $payload['caller_id'] = $this->asString($activeUser['caller-id'] ?? $payload['caller_id']);
                        break;
                    }
                }
            }
        } catch (\Throwable $e) {
            log_message('error', 'ApiResellerCustomer traffic snapshot error: ' . $e->getMessage());
        }

        return $payload;
    }

    private function getUsagePayload(array $customer)
    {
        $userId = $this->asInt($customer['id'] ?? 0);
        $pppoeName = trim((string) ($customer['pppoe_name'] ?? $customer['secret'] ?? ''));

        $usageModel = model('App\Models\UserDataUsageModel');
        $rows = $usageModel
            ->where('admin_id', $userId)
            ->orderBy('date', 'ASC')
            ->findAll();

        if (empty($rows) && $pppoeName !== '') {
            $rows = $usageModel
                ->where('user_name', $pppoeName)
                ->orderBy('date', 'ASC')
                ->findAll();
        }

        $today = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $selectedDate = null;

        foreach ($rows as $row) {
            if (($row['date'] ?? null) === $today) {
                $selectedDate = $today;
                break;
            }
        }

        if ($selectedDate === null) {
            foreach ($rows as $row) {
                if (($row['date'] ?? null) === $yesterday) {
                    $selectedDate = $yesterday;
                    break;
                }
            }
        }

        $downloadToday = 0.0;
        $uploadToday = 0.0;
        $totalUsage = 0.0;
        $peakUsage = 0.0;

        if ($selectedDate !== null) {
            foreach ($rows as $row) {
                if (($row['date'] ?? null) !== $selectedDate) {
                    continue;
                }

                $rxToday = $this->asFloat($row['rx_today'] ?? 0);
                $txToday = $this->asFloat($row['tx_today'] ?? 0);
                $dayTotal = $rxToday + $txToday;

                $downloadToday += $rxToday;
                $uploadToday += $txToday;
                $totalUsage += $dayTotal;

                if ($dayTotal > $peakUsage) {
                    $peakUsage = $dayTotal;
                }
            }
        }

        $latest = !empty($rows) ? $rows[count($rows) - 1] : [];

        return [
            'history' => $rows,
            'summary' => [
                'selected_date' => $selectedDate,
                'download_today_mb' => round($downloadToday, 2),
                'upload_today_mb' => round($uploadToday, 2),
                'total_usage_mb' => round($totalUsage, 2),
                'peak_usage_mb' => round($peakUsage, 2),
                'rx_total_mb' => round($this->asFloat($latest['rx_mb'] ?? 0), 2),
                'tx_total_mb' => round($this->asFloat($latest['tx_mb'] ?? 0), 2),
                'record_count' => count($rows),
            ],
        ];
    }

    private function buildDetailSections(array $customer, array $usagePayload, array $trafficSnapshot)
    {
        return [
            'account_info' => [
                'customer_id' => $this->asString($customer['c_id'] ?? $customer['code'] ?? null),
                'name' => $this->asString($customer['name'] ?? null),
                'mobile' => $this->asString($customer['mobile'] ?? null),
                'email' => $this->asString($customer['email'] ?? null),
                'address' => $this->asString($customer['address'] ?? null),
                'status' => $this->asString($customer['status'] ?? null),
                'subscription_status' => $this->asString($customer['subscription_status'] ?? null),
                'mac_bound' => (bool) ($customer['mac_bound'] ?? false),
            ],
            'package_info' => [
                'package_id' => $this->asString($customer['package_id'] ?? null),
                'package_name' => $this->asString($customer['package_name'] ?? null),
                'package_price' => $this->asFloat($customer['package_price'] ?? 0),
                'will_expire' => $customer['will_expire'] ?? null,
                'area_name' => $this->asString($customer['area_name'] ?? null),
                'router_name' => $this->asString($customer['router_name'] ?? null),
            ],
            'connection_details' => $customer['connection_details'] ?? [],
            'pppoe_info' => [
                'pppoe_id' => $this->asString($customer['pppoe_id'] ?? null),
                'pppoe_name' => $this->asString($customer['pppoe_name'] ?? null),
                'pppoe_password' => $this->asString($customer['pppoe_password'] ?? null),
                'pppoe_service' => $this->asString($customer['pppoe_service'] ?? null),
                'pppoe_profile' => $this->asString($customer['pppoe_profile'] ?? null),
                'uptime' => $this->asString($customer['pppoe_uptime'] ?? null),
                'address' => $this->asString($customer['pppoe_address'] ?? null),
                'caller_id' => $this->asString($customer['pppoe_caller_id'] ?? null),
            ],
            'traffic' => $trafficSnapshot,
            'usage' => $usagePayload,
            'mac_binding' => $customer['mac_binding'] ?? [],
            'olt_onu' => $customer['olt_onu'] ?? [],
        ];
    }

    /**
     * GET /api/reseller/customers/(:num?)
     */
    public function fetch($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $status = $this->request->getGet('status');
        $subscriptionStatus = $this->request->getGet('subscription_status');

        $builder = $this->user_model
            ->where('role', 'user')
            ->where('admin_id', (int) $resellerId);

        if (!empty($status)) {
            $builder->where('status', $status);
        }

        if (!empty($subscriptionStatus)) {
            $builder->where('subscription_status', $subscriptionStatus);
        }

        $customers = $builder->orderBy('id', 'desc')->findAll();

        $result = [];
        foreach ($customers as $customer) {
            $result[] = $this->enrichCustomer($customer, false);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'count' => count($result),
            'data' => $result,
        ]);
    }

    /**
     * GET /api/reseller/customers/(:resellerId)/(:customerId)
     * Returns complete customer details including PPPoE, OLT/ONU, usage, and traffic data
     */
    public function details($resellerId = null, $customerId = null)
    {
        if (empty($resellerId) || empty($customerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or customer id']);
        }

        $customer = $this->user_model
            ->where('id', (int) $customerId)
            ->where('admin_id', (int) $resellerId)
            ->where('role', 'user')
            ->first();

        if (empty($customer)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Customer not found']);
        }

        $customerArr = $this->toArray($customer);

        // Enrich customer with full PPPoE and connection details
        $enriched = $this->enrichCustomer($customerArr, true);
        
        // Fetch all additional data
        $enriched['mac_binding'] = $this->getMacBinding((int) $customerId);
        $enriched['olt_onu'] = $this->getOltOnuDetails($enriched); // Add OLT/ONU info

        $usagePayload = $this->getUsagePayload($enriched);
        $trafficSnapshot = $this->getTrafficSnapshot($enriched);

        $enriched['usage'] = $usagePayload;
        $enriched['traffic'] = $trafficSnapshot;
        $enriched['detail_sections'] = $this->buildDetailSections($enriched, $usagePayload, $trafficSnapshot);

        // Get connection details if available
        $connectionDetails = $this->getConnectionDetails((int) $customerId);

        // Build complete response with all fields for Flutter model
        $responseData = [
            // Basic customer info
            'id' => $this->asString($customerArr['id'] ?? null),
            'c_id' => $this->asString($customerArr['c_id'] ?? $customerArr['id'] ?? null),
            'customer_id' => $this->asString($customerArr['id'] ?? null),
            'name' => $this->asString($customerArr['name'] ?? null),
            'email' => $this->asString($customerArr['email'] ?? null),
            'phone' => $this->asString($customerArr['phone'] ?? $customerArr['mobile'] ?? null),
            'mobile' => $this->asString($customerArr['mobile'] ?? null),
            'address' => $this->asString($customerArr['address'] ?? null),
            
            // Status fields
            'status' => $this->asString($customerArr['status'] ?? $customerArr['subscription_status'] ?? 'inactive'),
            'subscription_status' => $this->asString($customerArr['subscription_status'] ?? 'inactive'),
            'conn_status' => $this->asString($customerArr['conn_status'] ?? 'disconn'),
            'connection_status' => $this->asString($customerArr['conn_status'] ?? 'disconn'),
            'activity' => $this->asString($customerArr['activity'] ?? '--'),
            
            // Financial info
            'balance' => $this->asFloat($customerArr['fund'] ?? $customerArr['balance'] ?? 0),
            'fund' => $this->asFloat($customerArr['fund'] ?? $customerArr['balance'] ?? 0),
            'due_amount' => $this->asFloat($customerArr['due_amount'] ?? 0),
            'due' => $this->asFloat($customerArr['due_amount'] ?? 0),
            'total_due' => $this->asFloat($customerArr['due_amount'] ?? 0),
            'payment_status' => $this->asString($customerArr['payment_status'] ?? 'inactive'),
            'last_payment_date' => $customerArr['last_payment_date'] ?? null,
            
            // Package info
            'package_id' => $this->asString($customerArr['package_id'] ?? null),
            'package_name' => $this->asString($enriched['package_name'] ?? null),
            'bandwidth' => $this->asString($enriched['bandwidth'] ?? '--'),
            'package_price' => $this->asFloat($enriched['package_price'] ?? 0),
            'selling_price' => $this->asFloat($enriched['package_price'] ?? 0),
            'price' => $this->asFloat($enriched['package_price'] ?? 0),
            'pricing' => $this->asString($enriched['package_name'] ?? null),
            'will_expire' => $customerArr['will_expire'] ?? null,
            'expiry_date' => $customerArr['will_expire'] ?? null,
            
            // Router & Area
            'router_id' => $this->asString($customerArr['router_id'] ?? null),
            'router' => $this->asString($enriched['router_name'] ?? '--'),
            'router_name' => $this->asString($enriched['router_name'] ?? '--'),
            'area_id' => $this->asString($customerArr['area_id'] ?? null),
            'service_area' => $this->asString($enriched['area_name'] ?? '--'),
            'area_name' => $this->asString($enriched['area_name'] ?? '--'),
            
            // PPPoE fields
            'pppoe_id' => $this->asString($customerArr['pppoe_id'] ?? null),
            'pppoe_name' => $this->asString($enriched['pppoe_name'] ?? '--'),
            'pppoe_secret' => $this->asString($enriched['pppoe_name'] ?? '--'),
            'secret' => $this->asString($enriched['pppoe_name'] ?? '--'),
            'pppoe_password' => $this->asString($enriched['pppoe_password'] ?? '--'),
            'router_password' => $this->asString($enriched['pppoe_password'] ?? '--'),
            'pppoe_service' => $this->asString($enriched['pppoe_service'] ?? 'pppoe'),
            'pppoe_profile' => $this->asString($enriched['pppoe_profile'] ?? '--'),
            'pppoe_caller_id' => $this->asString($enriched['pppoe_caller_id'] ?? '--'),
            'pppoe_last_caller_id' => $this->asString($enriched['pppoe_last_caller_id'] ?? '--'),
            'pppoe_uptime' => $this->asString($enriched['pppoe_uptime'] ?? '--'),
            'pppoe_address' => $this->asString($enriched['pppoe_address'] ?? '--'),
            'pppoe_status' => $this->asString($enriched['pppoe_disabled'] ?? 'no'),
            
            // Connection details
            'connection_type' => $this->asString($connectionDetails['connection_type'] ?? 'utp'),
            'client_type' => $this->asString($connectionDetails['client_type'] ?? 'home'),
            'billing_status' => $this->asString($connectionDetails['billing_status'] ?? 'active'),
            'cable_requirement' => $this->asString($connectionDetails['cable_requirement'] ?? '--'),
            'fiber_code' => $this->asString($connectionDetails['fiber_code'] ?? '--'),
            'number_of_core' => $this->asString($connectionDetails['number_of_core'] ?? '--'),
            'core_color' => $this->asString($connectionDetails['core_color'] ?? '--'),
            'otc' => $this->asString($connectionDetails['otc'] ?? '--'),
            'otc_status' => $this->asString($connectionDetails['otc_status'] ?? '--'),
            
            // Technical info
            'ip_address' => $this->asString($customerArr['ip_address'] ?? null),
            'mac_address' => $this->asString($customerArr['mac_address'] ?? null),
            'mac_bound' => (bool) ($enriched['mac_binding']['is_bound'] ?? false),
            'nid_number' => $this->asInt($customerArr['nid_number'] ?? 0),
            
            // User role & creation
            'role' => $this->asString($customerArr['role'] ?? 'user'),
            'admin_id' => $this->asString($customerArr['admin_id'] ?? null),
            'created_by' => $this->asString($customerArr['created_by'] ?? '--'),
            'designation' => $this->asString($customerArr['designation'] ?? '--'),
            
            // Dates
            'created_at' => $customerArr['created_at'] ?? null,
            'updated_at' => $customerArr['updated_at'] ?? null,
            
            // Nested connection details
            'connection_details' => $connectionDetails,
            
            // Full enriched object
            'full_data' => $enriched,

            // Frequently used nested payloads for mobile
            'pppoe' => [
                'name' => $enriched['pppoe_name'] ?? '--',
                'password' => $enriched['pppoe_password'] ?? '--',
                'service' => $enriched['pppoe_service'] ?? '--',
                'profile' => $enriched['pppoe_profile'] ?? '--',
                'uptime' => $enriched['pppoe_uptime'] ?? '--',
                'address' => $enriched['pppoe_address'] ?? '--',
                'caller_id' => $enriched['pppoe_caller_id'] ?? '--',
                'last_logged_out' => $enriched['pppoe_last_logged_out'] ?? '--',
                'last_caller_id' => $enriched['pppoe_last_caller_id'] ?? '--',
                'last_disconnect_reason' => $enriched['pppoe_last_disconnect_reason'] ?? '--',
                'disabled' => $enriched['pppoe_disabled'] ?? '--',
                'comment' => $enriched['pppoe_comment'] ?? '--',
            ],
            'olt_onu' => $enriched['olt_onu'] ?? [],
            'mac_binding' => $enriched['mac_binding'] ?? [],
            'usage' => $usagePayload,
            'traffic' => $trafficSnapshot,
            'detail_sections' => $enriched['detail_sections'] ?? [],
        ];

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Customer details fetched successfully',
            // Flat response for easy parsing
            'data' => $responseData,
            
            // Organized sections for different UI areas
            'sections' => [
                'account_info' => [
                    'id' => $responseData['id'],
                    'name' => $responseData['name'],
                    'email' => $responseData['email'],
                    'phone' => $responseData['phone'],
                    'mobile' => $responseData['mobile'],
                    'address' => $responseData['address'],
                    'nid_number' => $responseData['nid_number'],
                    'designation' => $responseData['designation'],
                    'created_by' => $responseData['created_by'],
                    'role' => $responseData['role'],
                    'admin_id' => $responseData['admin_id'],
                ],
                'package_info' => [
                    'package_id' => $responseData['package_id'],
                    'package_name' => $responseData['package_name'],
                    'bandwidth' => $responseData['bandwidth'],
                    'package_price' => $responseData['package_price'],
                    'will_expire' => $responseData['will_expire'],
                    'service_area' => $responseData['service_area'],
                    'router_name' => $responseData['router_name'],
                ],
                'pppoe_info' => [
                    'pppoe_id' => $responseData['pppoe_id'],
                    'pppoe_name' => $responseData['pppoe_name'],
                    'pppoe_password' => $responseData['pppoe_password'],
                    'pppoe_service' => $responseData['pppoe_service'],
                    'pppoe_profile' => $responseData['pppoe_profile'],
                    'pppoe_uptime' => $enriched['pppoe_uptime'] ?? '--',
                    'pppoe_address' => $enriched['pppoe_address'] ?? '--',
                    'pppoe_caller_id' => $responseData['pppoe_caller_id'],
                    'pppoe_last_caller_id' => $responseData['pppoe_last_caller_id'],
                ],
                'connection_info' => [
                    'connection_type' => $responseData['connection_type'],
                    'client_type' => $responseData['client_type'],
                    'billing_status' => $responseData['billing_status'],
                    'cable_requirement' => $responseData['cable_requirement'],
                    'fiber_code' => $responseData['fiber_code'],
                    'number_of_core' => $responseData['number_of_core'],
                    'core_color' => $responseData['core_color'],
                    'otc' => $responseData['otc'],
                    'otc_status' => $responseData['otc_status'],
                    'ip_address' => $responseData['ip_address'],
                    'mac_address' => $responseData['mac_address'],
                ],
                'financial_info' => [
                    'balance' => $responseData['balance'],
                    'due_amount' => $responseData['due_amount'],
                    'payment_status' => $responseData['payment_status'],
                    'last_payment_date' => $responseData['last_payment_date'],
                ],
            ],

            // Status sections
            'customer_status' => $responseData['status'],
            'subscription_status' => $responseData['subscription_status'],
            'conn_status' => $responseData['conn_status'],

            // Device binding
            'mac_binding' => $enriched['mac_binding'],

            // OLT/ONU info
            'olt_onu' => $enriched['olt_onu'] ?? [],

            // PPPoE block for direct use
            'pppoe' => $responseData['pppoe'],

            // Usage & Traffic
            'usage' => $usagePayload,
            'traffic' => $trafficSnapshot,
        ]);
    }

    /**
     * POST /api/reseller/customers/create/(:resellerId)/(:num?)
     */
    public function create($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->getInput();

        $required = [
            'name',
            'package_id',
            'area_id',
            'router_id',
            'mobile',
            'address',
            'status',
            'pppoe_name',
            'pppoe_password',
            'pppoe_service',
        ];

        $errors = [];
        foreach ($required as $field) {
            $value = $input[$field] ?? null;
            if ($value === null || trim((string) $value) === '') {
                $errors[$field] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
            }
        }

        $status = strtolower(trim((string) ($input['status'] ?? '')));
        if ($status !== '' && !in_array($status, ['active', 'inactive'], true)) {
            $errors['status'] = 'Status must be active or inactive';
        }

        if (!empty($errors)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $errors]);
        }

        $resellerObj = $this->user_model
            ->where('id', (int) $resellerId)
            ->where('role', 'resellerAdmin')
            ->first();

        if (empty($resellerObj)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Reseller not found']);
        }

        $reseller = $this->toArray($resellerObj);

        $mobileExists = $this->user_model
            ->where('mobile', trim((string) $input['mobile']))
            ->first();
        if (!empty($mobileExists)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Mobile already in use']);
        }

        $email = trim((string) ($input['email'] ?? ''));
        if ($email === '') {
            $email = trim((string) $input['pppoe_name']) . '@gmail.com';
        }

        $emailExists = $this->user_model
            ->where('email', $email)
            ->first();
        if (!empty($emailExists)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Email already in use']);
        }

        if (!function_exists('routerClient') || !function_exists('createPPPoEUser')) {
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Router helper functions are not available']);
        }

        $routerId = (int) ($input['router_id'] ?? 0);
        if ($routerId <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Invalid router id']);
        }

        $routerClient = routerClient($routerId);
        if (!($routerClient instanceof \RouterOS\Client)) {
            $error = is_array($routerClient) ? ($routerClient['error'] ?? 'Router connection failed') : 'Router connection failed';
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => $error]);
        }

        $packageId = (int) ($input['package_id'] ?? 0);
        if ($packageId <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Invalid package id']);
        }

        $pppoeProfile = trim((string) ($input['pppoe_profile'] ?? ''));
        if ($pppoeProfile === '') {
            $resellerPackageModel = model('App\Models\ResellerPackages');
            $resellerPackage = $resellerPackageModel
                ->where('id', $packageId)
                ->where('status', 'active')
                ->first();
            $resellerPackageRow = $this->toArray($resellerPackage);
            $pppoeProfile = trim((string) ($resellerPackageRow['bandwidth'] ?? ''));
        }

        if ($pppoeProfile === '') {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'PPPoE profile is required',
            ]);
        }

        $routerPayload = [
            'pppoe_name' => trim((string) $input['pppoe_name']),
            'pppoe_password' => (string) $input['pppoe_password'],
            'pppoe_service' => trim((string) $input['pppoe_service']),
            'pppoe_profile' => $pppoeProfile,
        ];

        $routerAction = createPPPoEUser($routerClient, $routerPayload);
        if (!is_array($routerAction) || ($routerAction['status'] ?? 'error') !== 'success') {
            $error = is_array($routerAction) ? ($routerAction['error'] ?? 'Failed to create PPPoE user') : 'Failed to create PPPoE user';
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => $error]);
        }

        $pppoeId = $routerAction['pppoe_id'] ?? null;
        if (empty($pppoeId)) {
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Failed to receive PPPoE id from router']);
        }

        $billingStatus = trim((string) ($input['billing_status'] ?? ''));
        $explicitExpire = trim((string) ($input['will_expire'] ?? ''));
        if ($explicitExpire !== '') {
            $normalized = str_replace('T', ' ', $explicitExpire);
            $timestamp = strtotime($normalized);
            if ($timestamp === false) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => 'error',
                    'message' => 'Invalid datetime format for will_expire',
                ]);
            }
            $willExpire = date('Y-m-d H:i:s', $timestamp);
        } elseif (strtolower($billingStatus) === 'free') {
            $willExpire = date('Y-m-d H:i:s', strtotime('+365 days'));
        } elseif ((int) ($reseller['area_id'] ?? 0) > 0) {
            $cutDay = (int) $reseller['area_id'];
            $todayDay = (int) date('d');
            $month = (int) date('m');
            $year = (int) date('Y');
            $time = date('H:i:s');

            if ($todayDay > $cutDay) {
                $month++;
                if ($month > 12) {
                    $month = 1;
                    $year++;
                }
            }

            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
            if ($cutDay > $daysInMonth) {
                $cutDay = $daysInMonth;
            }

            $willExpire = sprintf('%04d-%02d-%02d %s', $year, $month, $cutDay, $time);
        } elseif (function_exists('calPackageExpireDate')) {
            $willExpire = calPackageExpireDate($packageId, date('Y-m-d H:i:s'));
        } else {
            $willExpire = date('Y-m-d H:i:s', strtotime('+30 days'));
        }

        $fund = (float) ($reseller['fund'] ?? 0);
        $packagePrice = 0.0;
        $activeForDays = max(0, (int) floor((strtotime($willExpire) - time()) / 86400));
        $newPrice = 0.0;

        if (function_exists('ResellerPackagePrice')) {
            $packagePrice = (float) ResellerPackagePrice($packageId, null, (int) $resellerId, 'resellerAdmin');
            if ($packagePrice < 0) {
                $packagePrice = 0.0;
            }
            $newPrice = ($packagePrice / 30) * $activeForDays;
        }

        if ($fund < $newPrice) {
            if (function_exists('removePPPoEUser')) {
                try {
                    removePPPoEUser($routerClient, $pppoeId);
                } catch (\Throwable $e) {
                    log_message('error', 'Failed to rollback PPPoE after fund check failure: ' . $e->getMessage());
                }
            }

            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Insufficient fund. Required: ' . round($newPrice, 2) . ', Available: ' . round($fund, 2),
            ]);
        }

        $customerData = [
            'package_id' => $packageId,
            'pre_package' => $input['pre_package'] ?? null,
            'area_id' => (int) ($input['area_id'] ?? 0),
            'router_id' => $routerId,
            'name' => trim((string) $input['name']),
            'designation' => $input['designation'] ?? null,
            'mobile' => trim((string) $input['mobile']),
            'nid_number' => $input['nid_number'] ?? null,
            'email' => $email,
            'code' => (string) $input['pppoe_password'],
            'password' => password_hash((string) $input['pppoe_password'], PASSWORD_DEFAULT),
            'address' => trim((string) $input['address']),
            'pppoe_id' => $pppoeId,
            'conn_status' => $input['conn_status'] ?? null,
            'last_renewed' => date('Y-m-d H:i:s'),
            'will_expire' => $willExpire,
            'subscription_status' => $input['subscription_status'] ?? 'active',
            'auto_disconnect' => $input['auto_disconnect'] ?? 'no',
            'status' => $status,
            'created_by' => $reseller['role'] ?? 'resellerAdmin',
            'activity' => $input['activity'] ?? null,
            'posPrinter' => $input['posPrinter'] ?? null,
            'admin_id' => (int) $resellerId,
            'role' => 'user',
        ];

        $connectionFields = [
            'sub_area_id',
            'connection_type',
            'cable_requirement',
            'fiber_code',
            'number_of_core',
            'core_color',
            'client_type',
            'billing_status',
            'otc',
            'otc_status',
        ];
        $connectionData = [];
        foreach ($connectionFields as $field) {
            if (array_key_exists($field, $input)) {
                $connectionData[$field] = $input[$field];
            }
        }

        $insertId = null;

        $this->db->transBegin();

        try {
            $insertResult = $this->user_model->insert($customerData, false);
            if (!$insertResult) {
                throw new \RuntimeException('Failed to create customer record');
            }

            $insertId = (int) $this->user_model->getInsertID();

            if ($insertId <= 0) {
                throw new \RuntimeException('Insert ID was not generated');
            }

            if (!empty($connectionData)) {
                $this->saveConnectionDetails($insertId, $connectionData);
            }

            $cacheData = [
                'user_id' => $insertId,
                'router_id' => $routerId,
                'router_password' => $routerPayload['pppoe_password'],
                'pppoe_secret' => $routerPayload['pppoe_name'],
                'last_updated' => date('Y-m-d H:i:s'),
            ];

            $existingCache = $this->userRouterDataModel->where('user_id', $insertId)->first();
            if (!empty($existingCache)) {
                $cacheId = is_array($existingCache) ? ($existingCache['id'] ?? null) : ($existingCache->id ?? null);
                if (!empty($cacheId)) {
                    $this->userRouterDataModel->update((int) $cacheId, $cacheData);
                } else {
                    $this->userRouterDataModel->where('user_id', $insertId)->set($cacheData)->update();
                }
            } else {
                $this->userRouterDataModel->insert($cacheData);
            }

            if ($newPrice > 0) {
                $this->user_model->update((int) $resellerId, ['fund' => $fund - $newPrice]);

                $transactionModel = model('App\Models\ResellerTransactions');
                $transactionModel->insert([
                    'customer' => $insertId,
                    'admin_id' => (int) $resellerId,
                    'amount' => $newPrice,
                    'package_price' => $packagePrice,
                    'active_for' => $activeForDays,
                    'comments' => 'API Customer Created',
                ]);
            }

            if ($this->db->transStatus() === false) {
                throw new \RuntimeException('Database transaction failed');
            }

            $this->db->transCommit();
        } catch (\Throwable $e) {
            $this->db->transRollback();

            if (!empty($pppoeId) && function_exists('removePPPoEUser')) {
                try {
                    removePPPoEUser($routerClient, $pppoeId);
                } catch (\Throwable $rollbackError) {
                    log_message('error', 'Failed to rollback PPPoE user after create failure: ' . $rollbackError->getMessage());
                }
            }

            log_message('error', 'Failed to create customer via reseller API: ' . $e->getMessage());

            return $this->response->setStatusCode(500)->setJSON([
                'status' => 'error',
                'message' => 'Customer create failed',
            ]);
        }

        $created = $this->user_model
            ->where('id', (int) $insertId)
            ->where('admin_id', (int) $resellerId)
            ->where('role', 'user')
            ->first();

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'New customer record added successfully',
            'id' => $insertId,
            'data' => $this->enrichCustomer($created, true),
        ]);
    }

    /**
     * POST /api/reseller/customers/(:resellerId)/(:customerId)
     */
    public function update($resellerId = null, $customerId = null)
    {
        $input = $this->getInput();

        if (empty($resellerId) || empty($customerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or customer id']);
        }

        $customerObj = $this->user_model
            ->where('id', (int) $customerId)
            ->where('role', 'user')
            ->first();

        if (empty($customerObj)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Customer not found']);
        }

        if ((int) $customerObj->admin_id !== (int) $resellerId) {
            return $this->response->setStatusCode(403)->setJSON(['status' => 'error', 'message' => 'Customer does not belong to reseller']);
        }

        $customer = $this->toArray($customerObj);

        $userFields = [
            'package_id',
            'pre_package',
            'area_id',
            'router_id',
            'name',
            'designation',
            'mobile',
            'nid_number',
            'email',
            'password',
            'code',
            'address',
            'pppoe_id',
            'conn_status',
            'last_renewed',
            'will_expire',
            'subscription_status',
            'auto_disconnect',
            'status',
            'created_by',
            'activity',
            'posPrinter',
        ];

        $data = [];
        foreach ($userFields as $field) {
            if (array_key_exists($field, $input)) {
                $data[$field] = $input[$field];
            }
        }

        $connectionFields = [
            'sub_area_id',
            'connection_type',
            'cable_requirement',
            'fiber_code',
            'number_of_core',
            'core_color',
            'client_type',
            'billing_status',
            'otc',
            'otc_status',
        ];

        $connectionData = [];
        foreach ($connectionFields as $field) {
            if (array_key_exists($field, $input)) {
                $connectionData[$field] = $input[$field];
            }
        }

        $pppoeFields = ['pppoe_name', 'pppoe_password', 'pppoe_service', 'pppoe_profile'];
        $hasPppoeInput = false;
        foreach ($pppoeFields as $field) {
            if (array_key_exists($field, $input)) {
                $hasPppoeInput = true;
                break;
            }
        }

        $macBindRan = false;
        if (array_key_exists('mac_bind', $input) || array_key_exists('mac_bound', $input)) {
            if (!function_exists('bindMacForUser')) {
                helper('router');
            }

            $wantBind = true;
            if (array_key_exists('mac_bind', $input)) {
                $v = $input['mac_bind'];
                $parsed = filter_var($v, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                $wantBind = $parsed !== null ? $parsed : (bool) $v;
            } else {
                $v = $input['mac_bound'];
                $parsed = filter_var($v, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                $wantBind = $parsed !== null ? $parsed : (bool) $v;
            }

            if ($wantBind) {
                $result = bindMacForUser((int) $customerId);
                $ok = is_array($result) ? (($result['status'] ?? false) === true) : false;
                if (!$ok) {
                    $msg = is_array($result) ? ($result['message'] ?? 'MAC bind failed') : 'MAC bind failed';

                    return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => $msg]);
                }
            } elseif (!removeMacBind((int) $customerId)) {
                return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Failed to remove MAC binding']);
            }

            $macBindRan = true;
        }

        if (empty($data) && empty($connectionData) && !$hasPppoeInput && !$macBindRan) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'No updatable fields provided']);
        }

        // Keep customer ownership fixed to this reseller
        $data['admin_id'] = (int) $resellerId;
        $data['role'] = 'user';

        if (!empty($data['email'])) {
            $exists = $this->user_model
                ->where('email', $data['email'])
                ->where('id !=', (int) $customerId)
                ->first();
            if ($exists) {
                return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Email already in use']);
            }
        }

        if (!empty($data['mobile'])) {
            $exists = $this->user_model
                ->where('mobile', $data['mobile'])
                ->where('id !=', (int) $customerId)
                ->first();
            if ($exists) {
                return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Mobile already in use']);
            }
        }

        foreach (['will_expire', 'last_renewed'] as $dateField) {
            if (!empty($data[$dateField])) {
                $normalized = str_replace('T', ' ', (string) $data[$dateField]);
                $timestamp = strtotime($normalized);
                if ($timestamp === false) {
                    return $this->response->setStatusCode(400)->setJSON([
                        'status' => 'error',
                        'message' => 'Invalid datetime format for ' . $dateField,
                    ]);
                }
                $data[$dateField] = date('Y-m-d H:i:s', $timestamp);
            }
        }

        if (array_key_exists('password', $data)) {
            if ($data['password'] === '' || $data['password'] === null) {
                unset($data['password']);
            } else {
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
        }

        // Update PPPoE connection status on router when conn_status is supplied.
        if (array_key_exists('conn_status', $data)) {
            $requested = strtolower(trim((string) $data['conn_status']));
            $requestedConn = in_array($requested, ['active', 'conn', 'connected', 'online'], true) ? 'conn' : 'disconn';

            if (!function_exists('routerClient') || !function_exists('enablePPPoEUser') || !function_exists('disablePPPoEUser')) {
                return $this->response->setStatusCode(500)->setJSON([
                    'status' => 'error',
                    'message' => 'Router helper functions are not available for connection status update',
                ]);
            }

            $routerId = (int) ($data['router_id'] ?? $customer['router_id'] ?? 0);
            $pppoeId = $data['pppoe_id'] ?? $customer['pppoe_id'] ?? null;

            if ($routerId <= 0 || empty($pppoeId)) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => 'error',
                    'message' => 'Missing router_id or pppoe_id for connection status update',
                ]);
            }

            $routerClient = routerClient($routerId);
            if (!($routerClient instanceof \RouterOS\Client)) {
                $error = is_array($routerClient) ? ($routerClient['error'] ?? 'Router connection failed') : 'Router connection failed';
                return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => $error]);
            }

            if ($requestedConn === 'conn') {
                $enabled = enablePPPoEUser($routerClient, $pppoeId);

                if (!$enabled && function_exists('enablePPPoEUser_by_pppoe_secret')) {
                    $routerCache = $this->userRouterDataModel->where('user_id', (int) $customerId)->first();
                    $cacheArr = $this->toArray($routerCache);
                    $pppoeSecret = $cacheArr['pppoe_secret'] ?? ($input['pppoe_name'] ?? null);
                    if (!empty($pppoeSecret)) {
                        $enabled = enablePPPoEUser_by_pppoe_secret($routerClient, $pppoeSecret);
                    }
                }

                if (!$enabled) {
                    return $this->response->setStatusCode(500)->setJSON([
                        'status' => 'error',
                        'message' => 'Failed to activate PPPoE connection on router',
                    ]);
                }

                $data['conn_status'] = 'conn';
                $data['activity'] = 'active';
                $data['posPrinter'] = 'conn';
            } else {
                disablePPPoEUser($routerClient, $pppoeId);
                $data['conn_status'] = 'disconn';
                $data['activity'] = 'inactive';
            }
        }

        // Update PPPoE on router when PPPoE fields are supplied
        if ($hasPppoeInput) {
            if (!function_exists('routerClient') || !function_exists('getPPPoEUser') || !function_exists('updatePPPoEUser')) {
                return $this->response->setStatusCode(500)->setJSON([
                    'status' => 'error',
                    'message' => 'Router helper functions are not available',
                ]);
            }

            $routerId = (int) ($data['router_id'] ?? $customer['router_id'] ?? 0);
            $pppoeId = $data['pppoe_id'] ?? $customer['pppoe_id'] ?? null;

            if (empty($routerId) || empty($pppoeId)) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => 'error',
                    'message' => 'Missing router_id or pppoe_id for PPPoE update',
                ]);
            }

            $routerClient = routerClient($routerId);
            if (!($routerClient instanceof \RouterOS\Client)) {
                $error = is_array($routerClient) ? ($routerClient['error'] ?? 'Router connection failed') : 'Router connection failed';
                return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => $error]);
            }

            $userPpp = getPPPoEUser($routerClient, $pppoeId);
            $currentPpp = $userPpp[0] ?? [];

            $routerPayload = [
                'pppoe_name' => $input['pppoe_name'] ?? ($currentPpp['name'] ?? null),
                'pppoe_password' => $input['pppoe_password'] ?? ($currentPpp['password'] ?? null),
                'pppoe_service' => $input['pppoe_service'] ?? ($currentPpp['service'] ?? null),
                'pppoe_profile' => $input['pppoe_profile'] ?? ($currentPpp['profile'] ?? null),
                'pppoe_id' => $pppoeId,
            ];

            if (empty($routerPayload['pppoe_name']) || empty($routerPayload['pppoe_password']) || empty($routerPayload['pppoe_service']) || empty($routerPayload['pppoe_profile'])) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => 'error',
                    'message' => 'PPPoE update requires name, password, service and profile',
                ]);
            }

            $routerAction = updatePPPoEUser($routerClient, $routerPayload);
            if (!is_array($routerAction) || ($routerAction['status'] ?? 'error') !== 'success') {
                $error = is_array($routerAction) ? ($routerAction['error'] ?? 'Failed to update PPPoE user') : 'Failed to update PPPoE user';
                return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => $error]);
            }

            $data['pppoe_id'] = $routerAction['pppoe_id'] ?? $pppoeId;

            if (array_key_exists('pppoe_password', $input) && !empty($input['pppoe_password'])) {
                $data['code'] = $input['pppoe_password'];
                $data['password'] = password_hash($input['pppoe_password'], PASSWORD_DEFAULT);
            }

            $cacheData = [
                'user_id' => (int) $customerId,
                'router_id' => (int) $routerId,
                'router_password' => $routerPayload['pppoe_password'],
                'pppoe_secret' => $routerPayload['pppoe_name'],
                'last_updated' => date('Y-m-d H:i:s'),
            ];

            $routerCache = $this->userRouterDataModel->where('user_id', (int) $customerId)->first();
            if (!empty($routerCache)) {
                $cacheId = is_array($routerCache) ? ($routerCache['id'] ?? null) : ($routerCache->id ?? null);
                if (!empty($cacheId)) {
                    $this->userRouterDataModel->update((int) $cacheId, $cacheData);
                } else {
                    $this->userRouterDataModel->where('user_id', (int) $customerId)->set($cacheData)->update();
                }
            } else {
                $this->userRouterDataModel->insert($cacheData);
            }
        }

        try {
            if (!empty($data)) {
                $this->user_model
                    ->where('id', (int) $customerId)
                    ->where('admin_id', (int) $resellerId)
                    ->where('role', 'user')
                    ->set($data)
                    ->update();
            }

            if (!empty($connectionData)) {
                $this->saveConnectionDetails((int) $customerId, $connectionData);
            }
        } catch (\Throwable $e) {
            log_message('error', 'Failed to update customer via reseller API: ' . $e->getMessage());
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Update failed']);
        }

        $updated = $this->user_model
            ->where('id', (int) $customerId)
            ->where('admin_id', (int) $resellerId)
            ->where('role', 'user')
            ->first();

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Customer record updated successfully',
            'data' => $this->enrichCustomer($updated, true),
        ]);
    }

    /**
     * DELETE or POST /api/reseller/customers/(:resellerId)/(:customerId)
     *
     * Parity with web Customer::delete():
     *   - Removes PPPoE user from MikroTik when the router is active
     *   - Deletes user_router_data, connection_details, registrations, and users rows
     */
    public function delete($resellerId = null, $customerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        if (!empty($customerId)) {
            $ids = [(int) $customerId];
        } else {
            $input = $this->getInput();
            $ids = $this->normalizeIds($input['ids'] ?? null);

            if (empty($ids)) {
                return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
            }
        }

        $existing = $this->user_model
            ->select('id, router_id, pppoe_id')
            ->where('role', 'user')
            ->where('admin_id', (int) $resellerId)
            ->whereIn('id', $ids)
            ->findAll();

        $toDelete = [];
        foreach ($existing as $row) {
            $entry = $this->toArray($row);
            if (empty($entry['id'])) {
                continue;
            }
            $toDelete[] = (int) $entry['id'];

            $routerId = $entry['router_id'] ?? null;
            if (empty($routerId) || $routerId === '0') {
                continue;
            }

            if (!function_exists('routerClient') || !function_exists('removePPPoEUser')) {
                continue;
            }

            $routerModel = model('App\Models\Router');
            $router = $routerModel->find((int) $routerId);
            $routerArr = $this->toArray($router);
            if (($routerArr['status'] ?? '') !== 'active') {
                continue;
            }

            $routerClient = routerClient((int) $routerId);
            if (!($routerClient instanceof \RouterOS\Client)) {
                continue;
            }

            $pppoeId = $entry['pppoe_id'] ?? null;
            if (function_exists('getPPPoEUserUserId')) {
                $pppoe = getPPPoEUserUserId($routerClient, (int) $entry['id']);
                $resolvedId = $pppoe[0]['.id'] ?? $pppoeId;
                if (!empty($resolvedId)) {
                    $pppoeId = $resolvedId;
                }
            }

            if (!empty($pppoeId)) {
                removePPPoEUser($routerClient, $pppoeId);
            }
        }

        if (empty($toDelete)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'No matching customers found']);
        }

        $deleted = $this->user_model
            ->where('role', 'user')
            ->where('admin_id', (int) $resellerId)
            ->whereIn('id', $toDelete)
            ->delete();

        if (!$deleted) {
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Delete failed']);
        }

        $this->db->table('connection_details')->whereIn('user_id', $toDelete)->delete();
        $this->userRouterDataModel->whereIn('user_id', $toDelete)->delete();

        $registrationModel = model('App\Models\Registration');
        $registrationModel->whereIn('userid', $toDelete)->delete();

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Selected records deleted successfully',
            'deleted_count' => count($toDelete),
            'deleted' => $toDelete,
        ]);
    }

    /**
     * DELETE or POST /api/reseller/customers/{resellerId}/bulk-delete
     * Alias to existing delete(ids[]) behavior.
     */
    public function bulkDelete($resellerId = null)
    {
        return $this->delete($resellerId, null);
    }

    /**
     * POST /api/reseller/customers/{resellerId}/sync-pppoe
     */
    public function syncPppoeIds($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        if (!function_exists('routerClient') || !function_exists('getPPPoEUserByName') || !function_exists('getRouterPassById')) {
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Router helper functions are not available']);
        }

        $customers = $this->user_model
            ->select('id, router_id, pppoe_id')
            ->where('role', 'user')
            ->where('admin_id', (int) $resellerId)
            ->findAll();

        $updated = 0;
        $skipped = 0;
        $errors = [];

        foreach ($customers as $customer) {
            $row = $this->toArray($customer);
            $userId = (int) ($row['id'] ?? 0);
            $routerId = (int) ($row['router_id'] ?? 0);

            if ($userId <= 0 || $routerId <= 0) {
                $skipped++;
                continue;
            }

            $routerPass = getRouterPassById($userId);
            $secret = is_array($routerPass) ? trim((string) ($routerPass['pppoe_secret'] ?? '')) : '';
            if ($secret === '') {
                $cache = $this->userRouterDataModel->where('user_id', $userId)->first();
                $cacheRow = $this->toArray($cache);
                $secret = trim((string) ($cacheRow['pppoe_secret'] ?? ''));
            }

            if ($secret === '') {
                $skipped++;
                continue;
            }

            $client = routerClient($routerId);
            if (!($client instanceof \RouterOS\Client)) {
                $errors[] = ['user_id' => $userId, 'message' => 'Router connection failed'];
                continue;
            }

            $ppp = getPPPoEUserByName($client, $secret);
            $pppoeId = is_array($ppp) ? ($ppp[0]['id'] ?? '') : '';
            if ($pppoeId === '') {
                $errors[] = ['user_id' => $userId, 'message' => 'PPPoE user not found'];
                continue;
            }

            if ((string) ($row['pppoe_id'] ?? '') !== (string) $pppoeId) {
                $this->user_model->update($userId, ['pppoe_id' => $pppoeId]);
                $updated++;
            } else {
                $skipped++;
            }
        }

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'PPPoE sync completed',
            'data' => [
                'total' => count($customers),
                'updated' => $updated,
                'skipped' => $skipped,
                'errors' => $errors,
            ],
        ]);
    }

    /**
     * POST /api/reseller/customers/{resellerId}/transfer
     *
     * Parity with web Customer::transfer(): derives `created_by` from the
     * calling reseller's own role and created_by, matching the session-based
     * branching the web controller uses.
     */
    public function transfer($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->getInput();

        $ids = $this->normalizeIds($input['ids'] ?? null);
        $targetResellerId = (int) ($input['target_reseller_id'] ?? $input['reseller_id'] ?? 0);

        if (empty($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
        }
        if ($targetResellerId <= 0) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Target reseller id is required']);
        }

        $targetReseller = $this->user_model
            ->where('id', $targetResellerId)
            ->where('role', 'resellerAdmin')
            ->first();

        if (empty($targetReseller)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Target reseller not found']);
        }

        $callerObj = $this->user_model->find((int) $resellerId);
        $caller = $this->toArray($callerObj);
        $callerRole = $caller['role'] ?? 'resellerAdmin';
        $callerCreatedBy = $caller['created_by'] ?? '';

        if ($callerRole === 'resellerAdmin') {
            $createdBy = 'sAdmin';
        } elseif ($callerRole === 'employee') {
            $createdBy = ($callerCreatedBy === 'resellerAdmin') ? 'sAdmin' : 'resellerAdmin';
        } else {
            $createdBy = 'resellerAdmin';
        }

        $customers = $this->user_model
            ->select('id')
            ->where('role', 'user')
            ->where('admin_id', (int) $resellerId)
            ->whereIn('id', $ids)
            ->findAll();

        $transferIds = [];
        foreach ($customers as $row) {
            $arr = $this->toArray($row);
            if (!empty($arr['id'])) {
                $transferIds[] = (int) $arr['id'];
            }
        }

        if (empty($transferIds)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'No matching customers found']);
        }

        $this->user_model
            ->whereIn('id', $transferIds)
            ->set([
                'admin_id' => $targetResellerId,
                'created_by' => $createdBy,
            ])
            ->update();

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Customers transferred successfully',
            'data' => [
                'transferred_count' => count($transferIds),
                'ids' => $transferIds,
                'target_reseller_id' => $targetResellerId,
            ],
        ]);
    }

    /**
     * POST /api/reseller/customers/{resellerId}/bulk-recharge
     * Applies subscription date/status updates for one or multiple customers.
     */
    public function bulkRecharge($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->getInput();

        $ids = $this->normalizeIds($input['ids'] ?? null);
        $willExpire = trim((string) ($input['will_expire'] ?? ''));
        $packageId = isset($input['package_id']) && $input['package_id'] !== '' ? (int) $input['package_id'] : null;
        $pppoeProfile = trim((string) ($input['pppoe_profile'] ?? ''));

        if (empty($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
        }
        if ($willExpire === '') {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'will_expire is required']);
        }

        $ts = strtotime(str_replace('T', ' ', $willExpire));
        if ($ts === false) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Invalid will_expire datetime']);
        }
        $normalizedWillExpire = date('Y-m-d H:i:s', $ts);
        $isActive = $ts > time();

        $customers = $this->user_model
            ->where('role', 'user')
            ->where('admin_id', (int) $resellerId)
            ->whereIn('id', $ids)
            ->findAll();

        $success = [];
        $failed = [];

        foreach ($customers as $customer) {
            $row = $this->toArray($customer);
            $customerId = (int) ($row['id'] ?? 0);
            if ($customerId <= 0) {
                continue;
            }

            $updateData = [
                'will_expire' => $normalizedWillExpire,
                'last_renewed' => date('Y-m-d H:i:s'),
                'subscription_status' => $isActive ? 'active' : 'inactive',
                'conn_status' => $isActive ? 'conn' : 'disconn',
            ];

            if ($packageId !== null && $packageId > 0) {
                $updateData['package_id'] = $packageId;
            }

            try {
                $this->user_model->update($customerId, $updateData);

                if ($pppoeProfile !== '' && function_exists('routerClient') && function_exists('getPPPoEUser') && function_exists('updatePPPoEUser')) {
                    $routerId = (int) ($row['router_id'] ?? 0);
                    $pppoeId = (string) ($row['pppoe_id'] ?? '');
                    if ($routerId > 0 && $pppoeId !== '') {
                        $client = routerClient($routerId);
                        if ($client instanceof \RouterOS\Client) {
                            $ppp = getPPPoEUser($client, $pppoeId);
                            $pppRow = is_array($ppp) ? ($ppp[0] ?? []) : [];
                            if (!empty($pppRow)) {
                                updatePPPoEUser($client, [
                                    'pppoe_id' => $pppoeId,
                                    'pppoe_name' => $pppRow['name'] ?? '',
                                    'pppoe_password' => $pppRow['password'] ?? '',
                                    'pppoe_service' => $pppRow['service'] ?? 'pppoe',
                                    'pppoe_profile' => $pppoeProfile,
                                ]);
                            }
                        }
                    }
                }

                $success[] = $customerId;
            } catch (\Throwable $e) {
                $failed[] = ['id' => $customerId, 'message' => $e->getMessage()];
            }
        }

        $missing = array_values(array_diff($ids, $success));
        foreach ($missing as $id) {
            $existsInFailed = false;
            foreach ($failed as $entry) {
                if ((int) ($entry['id'] ?? 0) === (int) $id) {
                    $existsInFailed = true;
                    break;
                }
            }
            if (!$existsInFailed) {
                $failed[] = ['id' => (int) $id, 'message' => 'Customer not found or not owned by reseller'];
            }
        }

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Bulk recharge processing finished',
            'data' => [
                'success_count' => count($success),
                'failed_count' => count($failed),
                'success_ids' => $success,
                'failed' => $failed,
                'will_expire' => $normalizedWillExpire,
            ],
        ]);
    }

    /**
     * GET /api/reseller/customers/{resellerId}/export-excel
     */
    public function exportExcel($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $customers = $this->user_model
            ->where('role', 'user')
            ->where('admin_id', (int) $resellerId)
            ->orderBy('id', 'desc')
            ->findAll();

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = ['ID', 'Customer Name', 'Package', 'Mobile', 'Router', 'PPPoE Secret', 'PPPoE Password', 'Conn. Status', 'Acc. Status', 'PPPOE ID', 'Email'];
        $sheet->fromArray($headers, null, 'A1');

        $rowNum = 2;
        foreach ($customers as $customer) {
            $row = $this->toArray($customer);
            $userId = (int) ($row['id'] ?? 0);
            $package = function_exists('getUserPackage') ? getUserPackage($userId) : null;
            $packageArr = $this->toArray($package);
            $router = function_exists('getRouterById') ? getRouterById($row['router_id'] ?? null) : null;
            $routerArr = $this->toArray($router);
            $routerPass = function_exists('getRouterPassById') ? getRouterPassById($userId) : [];

            $sheet->fromArray([
                $row['c_id'] ?? $userId,
                $row['name'] ?? '--',
                $packageArr['package_name'] ?? '--',
                $row['mobile'] ?? '--',
                $routerArr['name'] ?? '--',
                is_array($routerPass) ? ($routerPass['pppoe_secret'] ?? '--') : '--',
                is_array($routerPass) ? ($routerPass['router_password'] ?? '--') : '--',
                (($row['conn_status'] ?? '') === 'conn') ? 'Connected' : 'Disconnected',
                (($row['status'] ?? '') === 'active') ? 'Active' : 'Inactive',
                $row['pppoe_id'] ?? '--',
                $row['email'] ?? '--',
            ], null, 'A' . $rowNum);

            $rowNum++;
        }

        $filename = 'customers_' . date('Ymd') . '.xlsx';

        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');

        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }

    /**
     * POST /api/reseller/customers/{resellerId}/import-excel
        * Imports customers from excel with per-row validation and partial success reporting.
     */
    public function importExcel($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $file = $this->request->getFile('excel_file');
        if (!$file || !$file->isValid() || $file->hasMoved()) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'Invalid excel file upload',
            ]);
        }

        try {
            $reader = IOFactory::createReaderForFile($file->getTempName());
            $reader->setReadDataOnly(true);
            $spreadsheet = $reader->load($file->getTempName());
            $sheetData = $spreadsheet->getActiveSheet()->toArray();

            if (empty($sheetData)) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => 'error',
                    'message' => 'Sheet data is empty',
                ]);
            }

            $expectedHeaders = [
                'ID',
                'Customer Name',
                'Mobile',
                'PackageName',
                'Router name',
                'Email',
                'PPPoE Secret',
                'PPPoE Password',
                'Subscription. Status',
                'Acc. Status',
                'Area',
                'Address',
                'Bandwidth',
                'WillExpire(m/d/y)'
            ];

            $headerRow = array_map(function ($value) {
                return trim((string) ($value ?? ''));
            }, $sheetData[0]);

            $expectedTrim = array_map('trim', $expectedHeaders);
            $headerRow = array_reverse($headerRow);
            while (!empty($headerRow) && ($headerRow[0] === '' || $headerRow[0] === null)) {
                array_shift($headerRow);
            }
            $headerRow = array_reverse($headerRow);

            if ($headerRow !== $expectedTrim) {
                return $this->response->setStatusCode(400)->setJSON([
                    'status' => 'error',
                    'message' => 'Invalid Excel format. Header row does not match expected format.',
                    'formatError' => true,
                ]);
            }

            $reseller = $this->user_model
                ->where('id', (int) $resellerId)
                ->where('role', 'resellerAdmin')
                ->first();

            if (empty($reseller)) {
                return $this->response->setStatusCode(404)->setJSON([
                    'status' => 'error',
                    'message' => 'Reseller not found',
                ]);
            }

            $resellerRow = $this->toArray($reseller);

            $packageModel = model('App\Models\ResellerPackages');
            $areaModel = model('App\Models\Area');
            $routerModel = model('App\Models\Router');

            $created = [];
            $errors = [];
            $warnings = [];

            for ($i = 1; $i < count($sheetData); $i++) {
                $row = $sheetData[$i] ?? [];
                if (empty(array_filter($row, function ($value) {
                    return trim((string) ($value ?? '')) !== '';
                }))) {
                    continue;
                }

                $name = trim((string) ($row[1] ?? ''));
                $mobileRaw = trim((string) ($row[2] ?? ''));
                $packageName = trim((string) ($row[3] ?? ''));
                $routerName = trim((string) ($row[4] ?? ''));
                $email = trim((string) ($row[5] ?? ''));
                $pppoeSecret = trim((string) ($row[6] ?? ''));
                $pppoePassword = trim((string) ($row[7] ?? ''));
                $subscriptionStatus = strtolower(trim((string) ($row[8] ?? 'active')));
                $accountStatus = strtolower(trim((string) ($row[9] ?? 'active')));
                $areaName = trim((string) ($row[10] ?? ''));
                $address = trim((string) ($row[11] ?? ''));
                $pppoeProfile = trim((string) ($row[12] ?? ''));
                $willExpireRaw = $row[13] ?? null;

                if ($name === '' || $packageName === '' || $routerName === '') {
                    $errors[] = ['row' => $i + 1, 'message' => 'Missing required fields: Customer Name, PackageName, or Router name'];
                    continue;
                }

                $mobileDigits = preg_replace('/\D+/', '', $mobileRaw ?? '');
                $mobile = $mobileDigits !== '' ? ('0' . ltrim($mobileDigits, '0')) : '';
                if ($mobile === '') {
                    $errors[] = ['row' => $i + 1, 'message' => 'Mobile is required'];
                    continue;
                }

                if ($pppoeSecret === '') {
                    $pppoeSecret = $mobile;
                }
                if ($pppoePassword === '') {
                    $pppoePassword = '1234';
                }

                if ($email === '') {
                    $email = $pppoeSecret . '@gmail.com';
                }

                $package = $packageModel
                    ->where('user_id', (int) $resellerId)
                    ->where('package_name', $packageName)
                    ->first();
                if (empty($package)) {
                    $errors[] = ['row' => $i + 1, 'message' => 'Package not found: ' . $packageName];
                    continue;
                }
                $packageRow = $this->toArray($package);
                $packageId = (int) ($packageRow['id'] ?? 0);

                $router = $routerModel
                    ->where('user_id', (int) $resellerId)
                    ->where('name', $routerName)
                    ->first();
                if (empty($router)) {
                    $errors[] = ['row' => $i + 1, 'message' => 'Router not found: ' . $routerName];
                    continue;
                }
                $routerRow = $this->toArray($router);
                $routerId = (int) ($routerRow['id'] ?? 0);

                $areaId = 0;
                if ($areaName !== '') {
                    $area = $areaModel
                        ->where('user_id', (int) $resellerId)
                        ->where('area_name', $areaName)
                        ->first();
                    if (!empty($area)) {
                        $areaRow = $this->toArray($area);
                        $areaId = (int) ($areaRow['id'] ?? 0);
                    } else {
                        $warnings[] = ['row' => $i + 1, 'message' => 'Area not found, using default: ' . $areaName];
                    }
                }

                $existsEmail = $this->user_model->where('email', $email)->first();
                if (!empty($existsEmail)) {
                    $errors[] = ['row' => $i + 1, 'message' => 'Email already exists: ' . $email];
                    continue;
                }

                $existsMobile = $this->user_model->where('mobile', $mobile)->first();
                if (!empty($existsMobile)) {
                    $errors[] = ['row' => $i + 1, 'message' => 'Mobile already exists: ' . $mobile];
                    continue;
                }

                $routerClient = function_exists('routerClient') ? routerClient($routerId) : null;
                if (!($routerClient instanceof \RouterOS\Client)) {
                    $errors[] = ['row' => $i + 1, 'message' => 'Router connection failed: ' . $routerName];
                    continue;
                }

                $pppoe = function_exists('getPPPoEUserByName') ? getPPPoEUserByName($routerClient, $pppoeSecret) : [];
                $pppoeId = is_array($pppoe) ? (($pppoe[0]['id'] ?? $pppoe[0]['.id'] ?? '') ?: '') : '';

                if ($pppoeId === '') {
                    $profileToUse = $pppoeProfile !== '' ? $pppoeProfile : trim((string) ($packageRow['bandwidth'] ?? ''));
                    if ($profileToUse === '') {
                        $profileToUse = 'default';
                    }

                    $routerAction = function_exists('createPPPoEUser')
                        ? createPPPoEUser($routerClient, [
                            'pppoe_name' => $pppoeSecret,
                            'pppoe_password' => $pppoePassword,
                            'pppoe_service' => 'pppoe',
                            'pppoe_profile' => $profileToUse,
                        ])
                        : ['status' => 'error', 'error' => 'createPPPoEUser helper unavailable'];

                    if (!is_array($routerAction) || (($routerAction['status'] ?? 'error') !== 'success')) {
                        $errorText = is_array($routerAction) ? ($routerAction['error'] ?? 'Failed to create PPPoE user') : 'Failed to create PPPoE user';
                        $errors[] = ['row' => $i + 1, 'message' => $errorText];
                        continue;
                    }

                    $pppoeId = (string) ($routerAction['pppoe_id'] ?? '');
                    if ($pppoeId === '') {
                        $pppoeAgain = function_exists('getPPPoEUserByName') ? getPPPoEUserByName($routerClient, $pppoeSecret) : [];
                        $pppoeId = is_array($pppoeAgain) ? (($pppoeAgain[0]['id'] ?? $pppoeAgain[0]['.id'] ?? '') ?: '') : '';
                    }
                }

                if ($pppoeId === '') {
                    $errors[] = ['row' => $i + 1, 'message' => 'Unable to resolve PPPoE ID after creation'];
                    continue;
                }

                $willExpire = date('Y-m-d H:i:s', strtotime('+1 day'));
                if (!empty($willExpireRaw)) {
                    if (is_numeric($willExpireRaw)) {
                        $excelTs = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToTimestamp((float) $willExpireRaw);
                        $willExpire = date('Y-m-d 12:00:00', $excelTs);
                    } else {
                        $parsed = strtotime((string) $willExpireRaw);
                        if ($parsed !== false) {
                            $willExpire = date('Y-m-d 12:00:00', $parsed);
                        }
                    }
                }

                $customerData = [
                    'package_id' => $packageId,
                    'area_id' => $areaId,
                    'router_id' => $routerId,
                    'name' => $name,
                    'mobile' => $mobile,
                    'email' => $email,
                    'code' => $pppoePassword,
                    'password' => password_hash($pppoePassword, PASSWORD_DEFAULT),
                    'address' => $address !== '' ? $address : '--',
                    'pppoe_id' => $pppoeId,
                    'last_renewed' => date('Y-m-d H:i:s'),
                    'will_expire' => $willExpire,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                    'auto_disconnect' => 'yes',
                    'role' => 'user',
                    'subscription_status' => in_array($subscriptionStatus, ['active', 'inactive'], true) ? $subscriptionStatus : 'active',
                    'status' => in_array($accountStatus, ['active', 'inactive'], true) ? $accountStatus : 'active',
                    'admin_id' => (int) $resellerId,
                    'created_by' => $resellerRow['role'] ?? 'resellerAdmin',
                ];

                try {
                    $this->user_model->insert($customerData, false);
                    $insertId = (int) $this->user_model->getInsertID();
                    if ($insertId <= 0) {
                        $errors[] = ['row' => $i + 1, 'message' => 'Failed to insert customer row'];
                        continue;
                    }

                    $cacheData = [
                        'user_id' => $insertId,
                        'router_id' => $routerId,
                        'router_password' => $pppoePassword,
                        'pppoe_secret' => $pppoeSecret,
                        'last_updated' => date('Y-m-d H:i:s'),
                    ];

                    $existingCache = $this->userRouterDataModel->where('user_id', $insertId)->first();
                    if (!empty($existingCache)) {
                        $cacheRow = $this->toArray($existingCache);
                        if (!empty($cacheRow['id'])) {
                            $this->userRouterDataModel->update((int) $cacheRow['id'], $cacheData);
                        } else {
                            $this->userRouterDataModel->where('user_id', $insertId)->set($cacheData)->update();
                        }
                    } else {
                        $this->userRouterDataModel->insert($cacheData);
                    }

                    $created[] = [
                        'row' => $i + 1,
                        'customer_id' => $insertId,
                        'name' => $name,
                    ];
                } catch (\Throwable $e) {
                    $errors[] = ['row' => $i + 1, 'message' => 'Insert failed: ' . $e->getMessage()];
                }
            }

            $message = 'Excel import finished';
            if (empty($created) && !empty($errors)) {
                $message = 'Excel import failed for all rows';
            } elseif (!empty($created) && !empty($errors)) {
                $message = 'Excel import completed with partial success';
            } elseif (!empty($created)) {
                $message = 'Excel data imported successfully';
            }

            return $this->response->setJSON([
                'status' => 'success',
                'message' => $message,
                'data' => [
                    'row_count' => max(0, count($sheetData) - 1),
                    'created_count' => count($created),
                    'error_count' => count($errors),
                    'warning_count' => count($warnings),
                    'created' => $created,
                    'errors' => $errors,
                    'warnings' => $warnings,
                ],
            ]);
        } catch (\Throwable $e) {
            return $this->response->setStatusCode(500)->setJSON([
                'status' => 'error',
                'message' => 'Failed to parse excel file: ' . $e->getMessage(),
            ]);
        }
    }


    /**
     * Normalizes bindMacForUser() return value (bool / int / string).
     */
    private function bindMacResultIsSuccess($result): bool
    {
        if (!is_array($result)) {
            return false;
        }
        $st = $result['status'] ?? false;
        if ($st === true || $st === 1) {
            return true;
        }
        if (is_string($st)) {
            $s = strtolower(trim($st));

            return in_array($s, ['1', 'true', 'yes', 'on'], true);
        }

        return false;
    }

    /**
     * Customer user row for this reseller, or null.
     */
    private function resellerCustomerRow($resellerId, $customerId)
    {
        $row = $this->user_model
            ->where('id', (int) $customerId)
            ->where('admin_id', (int) $resellerId)
            ->where('role', 'user')
            ->first();

        return empty($row) ? null : $row;
    }

    /**
     * GET /api/reseller/customers/(:resellerId)/(:customerId)/mac-status
     * Same idea as web customers/mac_ajax …/check — returns current router MAC binding.
     */
    public function macStatus($resellerId = null, $customerId = null)
    {
        if (empty($resellerId) || empty($customerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or customer id']);
        }

        if ($this->resellerCustomerRow($resellerId, $customerId) === null) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Customer not found']);
        }

        $binding = $this->getMacBinding((int) $customerId);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'OK',
            'data' => [
                'mac_binding' => $binding,
            ],
        ]);
    }

    /**
     * POST /api/reseller/customers/(:resellerId)/(:customerId)/mac-bind
     * Same router flow as web customers/mac_ajax …/bind (bindMacForUser).
     */
    public function macBind($resellerId = null, $customerId = null)
    {
        if (empty($resellerId) || empty($customerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or customer id']);
        }

        if ($this->resellerCustomerRow($resellerId, $customerId) === null) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Customer not found']);
        }

        if (!function_exists('bindMacForUser')) {
            helper('router');
        }

        $result = bindMacForUser((int) $customerId);
        $ok = $this->bindMacResultIsSuccess($result);
        if (!$ok) {
            $msg = is_array($result) ? ($result['message'] ?? 'MAC bind failed') : 'MAC bind failed';
            log_message('warning', 'mac-bind failed user=' . $customerId . ' msg=' . $msg);

            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => $msg,
                'error' => 'mac_bind_failed',
            ]);
        }

        $updated = $this->user_model
            ->where('id', (int) $customerId)
            ->where('admin_id', (int) $resellerId)
            ->where('role', 'user')
            ->first();

        $payload = $this->enrichCustomer($updated, true);
        $binding = $this->getMacBinding((int) $customerId);
        $payload['mac_binding'] = $binding;
        $payload['mac_bound'] = (bool) ($binding['is_bound'] ?? false);
        $payload['mac_address'] = $this->asString($binding['mac'] ?? '--');

        return $this->response->setJSON([
            'status' => 'success',
            'message' => is_array($result) ? ($result['message'] ?? 'MAC bound') : 'MAC bound',
            'data' => $payload,
        ]);
    }

    /**
     * POST /api/reseller/customers/(:resellerId)/(:customerId)/mac-unbind
     * Same router flow as web customers/mac_ajax …/unbind (removeMacBind).
     */
    public function macUnbind($resellerId = null, $customerId = null)
    {
        if (empty($resellerId) || empty($customerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or customer id']);
        }

        if ($this->resellerCustomerRow($resellerId, $customerId) === null) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Customer not found']);
        }

        if (!function_exists('removeMacBind')) {
            helper('router');
        }

        if (!removeMacBind((int) $customerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Failed to remove MAC binding']);
        }

        $updated = $this->user_model
            ->where('id', (int) $customerId)
            ->where('admin_id', (int) $resellerId)
            ->where('role', 'user')
            ->first();

        $payload = $this->enrichCustomer($updated, true);
        $binding = $this->getMacBinding((int) $customerId);
        $payload['mac_binding'] = $binding;
        $payload['mac_bound'] = (bool) ($binding['is_bound'] ?? false);
        $payload['mac_address'] = $this->asString($binding['mac'] ?? '--');

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'MAC unbound',
            'data' => $payload,
        ]);
    }

    /**
     * GET /api/reseller/customers/(:resellerId)/(:customerId)/audit-logs
     * Query: from, to, per_page, page, pppoe_name (optional filter on audit client field)
     */
    public function auditLogs($resellerId = null, $customerId = null)
    {
        if (empty($resellerId) || empty($customerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or customer id']);
        }

        $customer = $this->user_model
            ->where('id', (int) $customerId)
            ->where('admin_id', (int) $resellerId)
            ->where('role', 'user')
            ->first();

        if (empty($customer)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Customer not found']);
        }

        $from = $this->request->getGet('from');
        $to = $this->request->getGet('to');
        $perPage = (int) ($this->request->getGet('per_page') ?? 25);
        if ($perPage < 1) {
            $perPage = 25;
        }
        if ($perPage > 100) {
            $perPage = 100;
        }

        $pppoeFilter = $this->request->getGet('pppoe_name');
        if ($pppoeFilter !== null) {
            $pppoeFilter = trim((string) $pppoeFilter);
            if ($pppoeFilter === '') {
                $pppoeFilter = null;
            }
        }

        $auditModel = new AuditLogModel();
        $logs = $auditModel->getFiltered($from, $to, $perPage, (int) $customerId, $pppoeFilter);
        $pager = $auditModel->pager;

        $rows = [];
        foreach ($logs as $row) {
            $r = is_object($row) ? get_object_vars($row) : (array) $row;
            $rows[] = [
                'id' => isset($r['id']) ? (int) $r['id'] : null,
                'user_id' => isset($r['user_id']) ? (int) $r['user_id'] : null,
                'action' => $r['action'] ?? null,
                'entity' => $r['entity'] ?? null,
                'client' => $r['client'] ?? null,
                'router' => $r['router'] ?? null,
                'details' => $r['details'] ?? null,
                'actor' => $r['actor'] ?? null,
                'ip_address' => $r['ip_address'] ?? null,
                'user_agent' => $r['user_agent'] ?? null,
                'created_at' => $r['created_at'] ?? null,
            ];
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => [
                'logs' => $rows,
                'pager' => [
                    'current_page' => $pager->getCurrentPage(),
                    'per_page' => $perPage,
                    'total' => $pager->getTotal(),
                    'page_count' => $pager->getPageCount(),
                ],
                'filters' => [
                    'from' => $from,
                    'to' => $to,
                    'pppoe_name' => $pppoeFilter,
                ],
            ],
        ]);
    }
}
