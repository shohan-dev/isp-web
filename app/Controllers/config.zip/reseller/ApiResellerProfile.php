<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerProfile extends BaseController
{
    protected $user_model;
    protected $registration_model;

    public function __construct()
    {
        $this->user_model = model('App\Models\User');
        $this->registration_model = model('App\Models\Registration');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/profile/{resellerId}
     */
    public function fetch($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $user = $this->user_model->find($resellerId);
        if (empty($user)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'User not found']);
        }

        $registration = $this->registration_model->where('userid', $resellerId)->first();

        $userData = is_object($user) ? (array) $user : $user;
        unset($userData['password'], $userData['code']);

        return $this->response->setJSON([
            'status' => 'success',
            'data' => [
                'profile' => $userData,
                'organization' => $registration,
            ],
        ]);
    }

    /**
     * PUT /api/reseller/profile/{resellerId}
     */
    public function update($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $user = $this->user_model->find($resellerId);
        if (empty($user)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'User not found']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $allowed = ['name', 'mobile', 'address', 'email'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $input)) {
                $data[$f] = $input[$f];
            }
        }

        if (empty($data)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'No updatable fields provided']);
        }

        if (!empty($data['email'])) {
            $exists = $this->user_model->where('email', $data['email'])->where('id !=', $resellerId)->first();
            if ($exists) {
                return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Email already in use']);
            }
        }

        if (!empty($data['mobile'])) {
            $exists = $this->user_model->where('mobile', $data['mobile'])->where('id !=', $resellerId)->first();
            if ($exists) {
                return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Mobile already in use']);
            }
        }

        $result = $this->user_model->update($resellerId, $data);

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Profile updated successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Update failed']);
    }

    /**
     * PUT /api/reseller/profile/{resellerId}/organization
     */
    public function updateOrganization($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $allowed = ['admin_name', 'mobile', 'email', 'division', 'district', 'upazilla', 'address', 'nationalid', 'reference_name', 'reference_mobile'];
        $data = [];
        foreach ($allowed as $f) {
            if (array_key_exists($f, $input)) {
                $data[$f] = $input[$f];
            }
        }

        if (empty($data)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'No updatable fields provided']);
        }

        $registration = $this->registration_model->where('userid', $resellerId)->first();

        if ($registration) {
            $regId = is_object($registration) ? $registration->id : ($registration['id'] ?? null);
            $result = $this->registration_model->update($regId, $data);
        } else {
            $data['userid'] = $resellerId;
            $result = $this->registration_model->insert($data);
        }

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Organization data updated successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Update failed']);
    }

    /**
     * POST /api/reseller/profile/{resellerId}/change-password
     */
    public function changePassword($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'old_password' => 'required',
            'new_password' => 'required|min_length[4]',
            'confirm_password' => 'required|matches[new_password]',
        ];

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $user = $this->user_model->find($resellerId);
        if (empty($user)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'User not found']);
        }

        $userPassword = is_object($user) ? $user->password : ($user['password'] ?? '');

        if (!password_verify($input['old_password'], $userPassword)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => ['old_password' => 'Current password is incorrect']]);
        }

        $newPass = $input['new_password'];
        $result = $this->user_model->update($resellerId, [
            'code' => $newPass,
            'password' => password_hash($newPass, PASSWORD_DEFAULT),
        ]);

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Password changed successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Password change failed']);
    }
}
