<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerSupportTicket extends BaseController
{
    protected $ticket_model;
    protected $user_model;

    public function __construct()
    {
        $this->ticket_model = model('App\Models\Ticket');
        $this->user_model = model('App\Models\User');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/support-tickets/{resellerId}
     */
    public function fetch($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $tickets = $this->ticket_model
            ->where('user_id', $resellerId)
            ->orderBy('id', 'desc')
            ->findAll();

        return $this->response->setJSON(['status' => 'success', 'data' => $tickets]);
    }

    /**
     * GET /api/reseller/support-tickets/{resellerId}/{ticketId}
     */
    public function details($resellerId = null, $ticketId = null)
    {
        if (empty($resellerId) || empty($ticketId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or ticket id']);
        }

        $ticket = $this->ticket_model->where(['id' => $ticketId, 'user_id' => $resellerId])->first();

        if (empty($ticket)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Ticket not found']);
        }

        $ticketData = is_object($ticket) ? (array) $ticket : $ticket;
        $ticketData['messages'] = json_decode($ticketData['details'] ?? '[]', true);

        if (!empty($ticketData['messages'])) {
            foreach ($ticketData['messages'] as &$msg) {
                $sender = getUserById($msg['sender'] ?? 0);
                $msg['sender_name'] = $sender->name ?? '--';
            }
        }

        return $this->response->setJSON(['status' => 'success', 'data' => $ticketData]);
    }

    /**
     * POST /api/reseller/support-tickets/{resellerId}
     */
    public function create($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'subject' => 'required',
            'category' => 'required',
            'priority' => 'required',
            'message' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $reseller = $this->user_model->find($resellerId);
        $adminId = $reseller->admin_id ?? $resellerId;
        $assignTo = $input['assign_to'] ?? $adminId;

        $data = [
            'user_id' => $resellerId,
            'subject' => $input['subject'],
            'category' => $input['category'],
            'priority' => $input['priority'],
            'admin_ids' => json_encode($assignTo),
            'details' => json_encode([[
                'sender' => (string) $resellerId,
                'datetime' => date('d-m-y, h:i a'),
                'msg' => $input['message'],
            ]]),
            'datetime' => date('Y-m-d, H:i:s'),
        ];

        $result = $this->ticket_model->insert($data);

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'id' => $result, 'message' => 'Ticket created successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Insert failed']);
    }

    /**
     * POST /api/reseller/support-tickets/{resellerId}/{ticketId}/message
     */
    public function sendMessage($resellerId = null, $ticketId = null)
    {
        if (empty($resellerId) || empty($ticketId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or ticket id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        if (empty($input['message'])) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => ['message' => 'Message is required']]);
        }

        $ticket = $this->ticket_model->where(['id' => $ticketId, 'user_id' => $resellerId])->first();
        if (empty($ticket)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Ticket not found']);
        }

        $details = is_object($ticket) ? $ticket->details : ($ticket['details'] ?? '[]');
        $messages = json_decode($details, true) ?: [];

        $newMsg = [
            'sender' => (string) $resellerId,
            'msg' => trim($input['message']),
            'datetime' => date('d-m-y, h:i a'),
        ];

        $messages[] = $newMsg;

        $result = $this->ticket_model->update($ticketId, ['details' => json_encode($messages)]);

        if ($result) {
            $senderUser = getUserById($resellerId);
            $newMsg['sender_name'] = $senderUser->name ?? '--';
            return $this->response->setJSON(['status' => 'success', 'data' => $newMsg]);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Failed to send message']);
    }

    /**
     * PUT /api/reseller/support-tickets/{resellerId}/{ticketId}
     */
    public function update($resellerId = null, $ticketId = null)
    {
        if (empty($resellerId) || empty($ticketId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or ticket id']);
        }

        $ticket = $this->ticket_model->where(['id' => $ticketId, 'user_id' => $resellerId])->first();
        if (empty($ticket)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Ticket not found']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'subject' => 'required',
            'category' => 'required',
            'priority' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $data = [
            'subject' => $input['subject'],
            'category' => $input['category'],
            'priority' => $input['priority'],
        ];

        if (isset($input['status'])) {
            $data['status'] = $input['status'];
        }
        if (isset($input['remarks'])) {
            $data['remarks'] = $input['remarks'];
        }

        $result = $this->ticket_model->update($ticketId, $data);

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Ticket updated successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Update failed']);
    }

    /**
     * DELETE /api/reseller/support-tickets/{resellerId}
     */
    public function delete($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $ids = $input['ids'] ?? null;

        if (empty($ids) || !is_array($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
        }

        $result = $this->ticket_model->where('user_id', $resellerId)->whereIn('id', $ids)->delete();

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Deleted successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Delete failed']);
    }
}
