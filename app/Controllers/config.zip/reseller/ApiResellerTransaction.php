<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerTransaction extends BaseController
{
    protected $transaction_model;

    public function __construct()
    {
        $this->transaction_model = model('App\Models\ResellerTransactions');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/transactions/{resellerId}
     */
    public function fetch($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $fromDate = $this->request->getGet('fromDate');
        $toDate = $this->request->getGet('toDate');

        $builder = $this->transaction_model->where('admin_id', $resellerId);

        if (!empty($fromDate) && !empty($toDate)) {
            $builder->where('created_at >=', $fromDate)->where('created_at <=', $toDate);
        } elseif (!empty($fromDate)) {
            $builder->where('created_at >=', $fromDate);
        }

        $transactions = $builder->orderBy('id', 'desc')->findAll();

        $result = [];
        foreach ($transactions as $t) {
            $row = is_object($t) ? (array) $t : $t;
            $row['customer_name'] = getUserById($row['customer'])->name ?? '--';
            $result[] = $row;
        }

        return $this->response->setJSON(['status' => 'success', 'data' => $result]);
    }

    /**
     * DELETE /api/reseller/transactions/{resellerId}
     */
    public function delete($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $ids = $input['ids'] ?? null;

        if (empty($ids) || !is_array($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
        }

        $result = $this->transaction_model->where('admin_id', $resellerId)->whereIn('id', $ids)->delete();

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Deleted successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Delete failed']);
    }
}
