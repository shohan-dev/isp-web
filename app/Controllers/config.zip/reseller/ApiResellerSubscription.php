<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerSubscription extends BaseController
{
    protected $user_model;
    protected $payment_model;

    public function __construct()
    {
        $this->user_model = model('App\Models\User');
        $this->payment_model = model('App\Models\Payment');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/subscription/{resellerId}/{customerId}
     */
    public function info($resellerId = null, $customerId = null)
    {
        $resellerId = (int) $resellerId;
        $customerId = (int) $customerId;

        if (empty($resellerId) || empty($customerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or customer id']);
        }

        $customer = $this->user_model->where(['id' => $customerId, 'admin_id' => $resellerId, 'role' => 'user'])->first();
        if (empty($customer)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Customer not found']);
        }

        $reseller = $this->user_model->find($resellerId);
        $packageDetails = $this->getResellerPackageDetails($resellerId);
        $profiles = $this->getFilteredProfilesForCustomer($customer, $packageDetails);
        $pppoeProfile = $this->getCurrentPppoeProfile($customer);

        $currentMonth = date('F');
        $paymentDetails = $this->payment_model
            ->where(['user_id' => $customerId, 'month' => $currentMonth])
            ->first();

        $paymentMonths = $this->payment_model
            ->where(['user_id' => $customerId])
            ->findAll();

        $data = [
            'customer' => [
                'id' => (string) $customer->id,
                'name' => $customer->name ?? '',
                'created_at' => $customer->created_at ?? null,
                'package_id' => (string) ($customer->package_id ?? ''),
                'subscription_status' => $customer->subscription_status ?? 'inactive',
                'last_renewed' => $customer->last_renewed ?? null,
                'will_expire' => $customer->will_expire ?? null,
            ],
            'payment_details' => $paymentDetails,
            'payment_months' => $paymentMonths,
            'payment_months_status' => $this->buildPaymentMonthStatusMap($paymentMonths),
            'packages' => $packageDetails,
            'profiles' => $profiles,
            'pppoe_profile' => $pppoeProfile,
            'reseller_fund' => (float) ($reseller->fund ?? 0),
            'package_id' => (string) ($customer->package_id ?? ''),
            'subscription_status' => $customer->subscription_status ?? 'inactive',
            'last_renewed' => $customer->last_renewed ?? null,
            'will_expire' => $customer->will_expire ?? null,
        ];

        return $this->response->setJSON(['status' => 'success', 'data' => $data]);
    }

    /**
     * POST /api/reseller/subscription/{resellerId}/renew
     */
    public function renew($resellerId = null)
    {
        $resellerId = (int) $resellerId;
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'customer_id' => 'required|numeric',
            'will_expire' => 'required',
        ];

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $customerId = (int) $input['customer_id'];
        $willExpire = (string) $input['will_expire'];
        $selectedMonth = !empty($input['month']) ? (string) $input['month'] : date('F');
        $packageId = !empty($input['package_id']) ? (string) $input['package_id'] : '';
        $pppoeProfile = !empty($input['pppoe_profile']) ? (string) $input['pppoe_profile'] : '';
        $paidVia = !empty($input['paid_via']) ? (string) $input['paid_via'] : 'Cash';
        $methodTrx = !empty($input['method_trx']) ? (string) $input['method_trx'] : '';
        $status = !empty($input['status']) ? (string) $input['status'] : 'successful';

        $customer = $this->user_model->where(['id' => $customerId, 'admin_id' => $resellerId, 'role' => 'user'])->first();
        if (empty($customer)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Customer not found']);
        }

        if ($packageId === '') {
            $packageId = (string) ($customer->package_id ?? '');
        }

        if ($packageId === '') {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Please select a valid package.']);
        }

        // Same as Subscription::renew — block duplicate invoice for same month when package unchanged.
        $existingPayment = $this->payment_model
            ->where([
                'user_id' => $customerId,
                'paidby' => $resellerId,
                'month' => $selectedMonth,
            ])
            ->first();
        if ($existingPayment && (string) ($customer->package_id ?? '') === $packageId) {
            return $this->response->setStatusCode(400)->setJSON([
                'status' => 'error',
                'message' => 'A payment for the current month has already been generated.',
            ]);
        }

        $willExpire = $this->normalizeDateTime($willExpire);
        $dateValidation = $this->validateSubscriptionDates($willExpire, $selectedMonth);
        if (!$dateValidation['success']) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => $dateValidation['message']]);
        }

        $calc = $this->calculateSubscriptionData($customer, $willExpire, $packageId, $resellerId);
        if (!$calc['success']) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => $calc['message']]);
        }

        $db = \Config\Database::connect();
        $db->transStart();

        try {
            $now = date('Y-m-d H:i:s');
            $isActive = strtotime($willExpire) > time();

            $updated = $this->user_model->update($customerId, [
                'package_id' => $packageId,
                'last_renewed' => $now,
                'will_expire' => $willExpire,
                'subscription_status' => $isActive ? 'active' : 'inactive',
                'conn_status' => $isActive ? 'conn' : 'disconn',
            ]);

            if (!$updated) {
                throw new \RuntimeException('Failed to update customer subscription');
            }

            $routerResult = $this->handleRouterProfileAndStatus($customer, $pppoeProfile, $isActive);
            if (!$routerResult['success']) {
                throw new \RuntimeException($routerResult['message']);
            }

            $paymentResult = $this->processResellerPayment(
                $customerId,
                $customer,
                $resellerId,
                $selectedMonth,
                $paidVia,
                $methodTrx,
                $status,
                $calc
            );
            if (!$paymentResult['success']) {
                throw new \RuntimeException($paymentResult['message']);
            }

            $db->transComplete();
        } catch (\Throwable $e) {
            $db->transRollback();
            log_message('error', 'API reseller subscription renew failed: ' . $e->getMessage());
            return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => $e->getMessage()]);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Subscription renewed successfully',
            'charged' => round((float) $calc['price'], 2),
            'remaining_fund' => round((float) $calc['remaining_fund'], 2),
            'active_days' => (int) $calc['difference'],
            'new_expiry' => $willExpire,
            'payment_id' => $paymentResult['payment_id'] ?? null,
            'payment_url' => $paymentResult['payment_url'] ?? null,
        ]);
    }

    /**
     * POST /api/reseller/subscription/{resellerId}/bulk-renew
     * Process full subscription renewal (with payment/proration) for multiple customers.
     *
     * Body: { ids: [id,...], will_expire: "YYYY-MM-DD", package_id?, pppoe_profile?, paid_via?, status? }
     */
    public function bulkRenew($resellerId = null)
    {
        $resellerId = (int) $resellerId;
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        if (empty($input)) {
            $body = $this->request->getBody();
            if (!empty($body)) {
                $decoded = json_decode($body, true);
                if (is_array($decoded)) {
                    $input = $decoded;
                }
            }
        }

        $ids = $input['ids'] ?? [];
        if (!is_array($ids) || empty($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Select at least one customer']);
        }

        $willExpire = trim($input['will_expire'] ?? '');
        if (empty($willExpire)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Select expire date']);
        }

        $willExpire = $this->normalizeDateTime($willExpire);
        $packageId = !empty($input['package_id']) ? (string) $input['package_id'] : '';
        $pppoeProfile = !empty($input['pppoe_profile']) ? (string) $input['pppoe_profile'] : '';
        $paidVia = !empty($input['paid_via']) ? (string) $input['paid_via'] : 'Cash';
        $methodTrx = !empty($input['method_trx']) ? (string) $input['method_trx'] : '';
        $status = !empty($input['status']) ? (string) $input['status'] : 'successful';
        $selectedMonth = !empty($input['month']) ? (string) $input['month'] : date('F');

        $results = [];
        $successCount = 0;
        $failCount = 0;
        $totalCharged = 0.0;

        foreach ($ids as $cid) {
            $customerId = (int) $cid;
            if (empty($customerId)) {
                $results[] = ['id' => $cid, 'status' => 'error', 'message' => 'Invalid customer id'];
                $failCount++;
                continue;
            }

            $customer = $this->user_model->where(['id' => $customerId, 'admin_id' => $resellerId, 'role' => 'user'])->first();
            if (empty($customer)) {
                $results[] = ['id' => $cid, 'status' => 'error', 'message' => 'Customer not found'];
                $failCount++;
                continue;
            }

            $custPackageId = $packageId !== '' ? $packageId : (string) ($customer->package_id ?? '');
            if ($custPackageId === '') {
                $results[] = ['id' => $cid, 'name' => $customer->name ?? '', 'status' => 'error', 'message' => 'No package assigned'];
                $failCount++;
                continue;
            }

            $existingPayment = $this->payment_model->where([
                'user_id' => $customerId,
                'paidby' => $resellerId,
                'month' => $selectedMonth,
            ])->first();
            if ($existingPayment && (string) ($customer->package_id ?? '') === $custPackageId) {
                $results[] = ['id' => $cid, 'name' => $customer->name ?? '', 'status' => 'skipped', 'message' => 'Already renewed this month'];
                continue;
            }

            $dateValidation = $this->validateSubscriptionDates($willExpire, $selectedMonth);
            if (!$dateValidation['success']) {
                $results[] = ['id' => $cid, 'name' => $customer->name ?? '', 'status' => 'error', 'message' => $dateValidation['message']];
                $failCount++;
                continue;
            }

            $calc = $this->calculateSubscriptionData($customer, $willExpire, $custPackageId, $resellerId);
            if (!$calc['success']) {
                $results[] = ['id' => $cid, 'name' => $customer->name ?? '', 'status' => 'error', 'message' => $calc['message']];
                $failCount++;
                continue;
            }

            $db = \Config\Database::connect();
            $db->transStart();

            try {
                $now = date('Y-m-d H:i:s');
                $isActive = strtotime($willExpire) > time();

                $this->user_model->update($customerId, [
                    'package_id' => $custPackageId,
                    'last_renewed' => $now,
                    'will_expire' => $willExpire,
                    'subscription_status' => $isActive ? 'active' : 'inactive',
                    'conn_status' => $isActive ? 'conn' : 'disconn',
                ]);

                $this->handleRouterProfileAndStatus($customer, $pppoeProfile, $isActive);

                $paymentResult = $this->processResellerPayment(
                    $customerId, $customer, $resellerId,
                    $selectedMonth, $paidVia, $methodTrx, $status, $calc
                );

                if (!$paymentResult['success']) {
                    throw new \RuntimeException($paymentResult['message']);
                }

                $db->transComplete();

                $totalCharged += (float) $calc['price'];
                $successCount++;
                $results[] = [
                    'id' => $cid,
                    'name' => $customer->name ?? '',
                    'status' => 'success',
                    'charged' => round((float) $calc['price'], 2),
                ];
            } catch (\Throwable $e) {
                $db->transRollback();
                $failCount++;
                $results[] = ['id' => $cid, 'name' => $customer->name ?? '', 'status' => 'error', 'message' => $e->getMessage()];
            }
        }

        $reseller = $this->user_model->find($resellerId);
        $remainingFund = (float) ($reseller->fund ?? 0);

        $total = count($ids);
        $msg = $successCount === $total
            ? "All {$total} customer(s) renewed successfully"
            : "{$successCount}/{$total} customer(s) renewed. {$failCount} failed.";

        return $this->response->setJSON([
            'status' => $successCount > 0 ? 'success' : 'error',
            'message' => $msg,
            'total_charged' => round($totalCharged, 2),
            'remaining_fund' => round($remainingFund, 2),
            'results' => $results,
        ]);
    }

    protected function getResellerPackageDetails(int $resellerId): array
    {
        $packageModel = model('App\Models\allResellerPackage');
        $row = $packageModel->where('user_id', $resellerId)->first();
        if (empty($row)) {
            return [];
        }

        $packageJson = is_array($row)
            ? ($row['package_details'] ?? '[]')
            : ($row->package_details ?? '[]');
        $details = json_decode((string) $packageJson, true);
        return is_array($details) ? array_values($details) : [];
    }

    protected function getFilteredProfilesForCustomer($customer, array $packageDetails): array
    {
        $routerClient = routerClient($customer->router_id ?? null);
        if (!($routerClient instanceof \RouterOS\Client)) {
            return [];
        }

        $profiles = getPPPoEProfiles($routerClient);
        if (!is_array($profiles)) {
            return [];
        }

        $packageNames = array_values(array_filter(array_map(function ($pkg) {
            return trim((string) ($pkg['package_name'] ?? ''));
        }, $packageDetails)));

        if (empty($packageNames)) {
            return array_values(array_unique($profiles));
        }

        // Match profile number with package number exactly (same as web JS behavior).
        $allowedNumbers = [];
        foreach ($packageNames as $pkgName) {
            if (preg_match('/(\d+)/', $pkgName, $m)) {
                $allowedNumbers[] = (int) $m[1];
            }
        }

        if (empty($allowedNumbers)) {
            return array_values(array_unique($profiles));
        }

        $filtered = array_values(array_filter($profiles, function ($profile) use ($allowedNumbers) {
            if (!preg_match('/(\d+)/', (string) $profile, $m)) {
                return false;
            }
            return in_array((int) $m[1], $allowedNumbers, true);
        }));

        return array_values(array_unique($filtered));
    }

    protected function getCurrentPppoeProfile($customer): string
    {
        $routerClient = routerClient($customer->router_id ?? null);
        if (!($routerClient instanceof \RouterOS\Client)) {
            return '';
        }

        $pppoe = getPPPoEUserUserId($routerClient, $customer->id);
        $pppoeId = $pppoe[0]['.id'] ?? ($customer->pppoe_id ?? null);
        if (empty($pppoeId)) {
            return '';
        }

        $userPpp = getPPPoEUser($routerClient, $pppoeId);
        return (string) ($userPpp[0]['profile'] ?? '');
    }

    protected function buildPaymentMonthStatusMap(array $payments): array
    {
        $currentYear = date('Y');
        $monthStatus = [];

        foreach ($payments as $payment) {
            $createdAt = $payment->created_at ?? null;
            if (empty($createdAt)) {
                continue;
            }
            $year = date('Y', strtotime($createdAt));
            if ($year !== $currentYear) {
                continue;
            }

            $month = (string) ($payment->month ?? '');
            if ($month === '') {
                continue;
            }
            $status = (($payment->status ?? '') === 'successful') ? 'Paid' : 'Due';
            $monthStatus[$month] = $status;
        }

        return $monthStatus;
    }

    protected function normalizeDateTime(string $dateTime): string
    {
        $normalized = str_replace('T', ' ', trim($dateTime));
        if (strlen($normalized) === 16) {
            $normalized .= ':00';
        }
        return $normalized;
    }

    protected function validateSubscriptionDates(string $willExpire, string $selectedMonth): array
    {
        $now = date('Y-m-d H:i:s');
        $willExpireTs = strtotime($willExpire);
        $nowTs = strtotime($now);

        if ($willExpireTs === false) {
            return ['success' => false, 'message' => 'Invalid expiration date format'];
        }

        $monthNow = date('F', $nowTs);
        $monthWillExpire = date('F', $willExpireTs);
        $nextMonth = date('F', strtotime('+1 month', $nowTs));
        $allowedMonths = [$monthNow, $monthWillExpire, $nextMonth];

        if (!in_array($selectedMonth, $allowedMonths, true)) {
            return ['success' => false, 'message' => 'Selected month is not allowed based on current or expiration date.'];
        }

        return ['success' => true];
    }

    /**
     * Reseller selling price for a package id, matching Subscription::renew / ResellerPackagePrice()
     * when session user is the reseller (explicit id for API).
     */
    protected function resellerPackagePriceForApi(int $resellerId, string $packageId): float
    {
        if ($packageId === '') {
            return 0.0;
        }
        $p = ResellerPackagePrice($packageId, null, $resellerId, 'resellerAdmin');
        if ($p !== null && $p !== '--' && is_numeric($p)) {
            return (float) $p;
        }
        $info = $this->getResellerPackagePriceInfo($resellerId, $packageId);

        return (float) $info['selling_price'];
    }

    /**
     * Mirrors isp-core Subscription::renew() reseller pricing: fund check on current package,
     * full month when package unchanged, and |prorated old credit − new month| when package changes.
     */
    protected function calculateSubscriptionData($customer, string $willExpire, string $packageId, int $resellerId): array
    {
        $now = time();
        $willExpireTs = strtotime($willExpire);
        if ($willExpireTs === false) {
            return ['success' => false, 'message' => 'Invalid expiration date format'];
        }

        $prevExpireTs = !empty($customer->will_expire) ? strtotime($customer->will_expire) : $now;
        if ($prevExpireTs === false) {
            $prevExpireTs = $now;
        }
        $previousPackageId = (string) ($customer->package_id ?? '');

        // Subscription.php ~195–204: fund must cover current (old) package price before proceeding.
        $fundCheckPkg = $previousPackageId !== '' ? $previousPackageId : $packageId;
        $fundCheckPrice = $this->resellerPackagePriceForApi($resellerId, $fundCheckPkg);
        if ($fundCheckPrice <= 0) {
            return ['success' => false, 'message' => 'Please select a valid package.'];
        }

        $reseller = $this->user_model->find($resellerId);
        $fund = (float) ($reseller->fund ?? 0);
        if ($fund < $fundCheckPrice) {
            return ['success' => false, 'message' => "Your Reseller doesn't have enough fund. Please contact with him."];
        }

        $priceInfo = $this->getResellerPackagePriceInfo($resellerId, $packageId);
        $tprice = $this->resellerPackagePriceForApi($resellerId, $packageId);
        if ($tprice <= 0) {
            return ['success' => false, 'message' => 'Please select a valid package.'];
        }

        if ($previousPackageId !== '' && $previousPackageId !== $packageId) {
            // Subscription.php ~296–313: remaining days × (old price / 30) vs new full price → absolute difference.
            $remainingDays = 0;
            if ($prevExpireTs > $now) {
                $remainingDays = (int) floor(($prevExpireTs - $now) / (60 * 60 * 24));
            }
            $oldFull = $this->resellerPackagePriceForApi($resellerId, $previousPackageId);
            $newFull = $this->resellerPackagePriceForApi($resellerId, $packageId);
            if ($oldFull <= 0 || $newFull <= 0) {
                return ['success' => false, 'message' => 'Please select a valid package.'];
            }
            $newprice = ($oldFull / 30.0) * $remainingDays;
            $newpriceInt = is_numeric($newprice) ? (int) $newprice : 0;
            $xpriceInt = (int) $newFull;
            $price = (float) (max($newpriceInt, $xpriceInt) - min($newpriceInt, $xpriceInt));
            $difference = $remainingDays;
        } else {
            // Same package or first assignment: full monthly (reseller) price, like web renew.
            $price = $tprice;
            if (($customer->subscription_status ?? '') === 'active' && $prevExpireTs > $now) {
                $difference = $this->calendarDaysBetweenTimestamps($prevExpireTs, $willExpireTs);
            } else {
                $difference = $this->calendarDaysBetweenTimestamps($now, $willExpireTs);
            }
        }

        if ($difference < 0) {
            return ['success' => false, 'message' => 'Select the expiration date correctly.'];
        }

        if ($fund < $price) {
            return ['success' => false, 'message' => "Don't have enough fund. Please recharge."];
        }

        return [
            'success' => true,
            'difference' => (int) $difference,
            'price' => (float) $price,
            'tprice' => (float) $tprice,
            'originalPrice' => (float) $priceInfo['price'],
            'remaining_fund' => (float) ($fund - $price),
        ];
    }

    /**
     * Whole calendar days between two Unix timestamps (local date; matches Flutter billing days).
     */
    protected function calendarDaysBetweenTimestamps(int $fromTs, int $toTs): int
    {
        $from = new \DateTime('@' . $fromTs);
        $to = new \DateTime('@' . $toTs);
        $from->setTime(0, 0, 0);
        $to->setTime(0, 0, 0);
        if ($to < $from) {
            return -1;
        }

        return (int) $from->diff($to)->days;
    }

    protected function getResellerPackagePriceInfo(int $resellerId, string $packageId): array
    {
        $details = $this->getResellerPackageDetails($resellerId);
        foreach ($details as $pkg) {
            if ((string) ($pkg['id'] ?? '') !== (string) $packageId) {
                continue;
            }

            $basePrice = is_numeric($pkg['price'] ?? null) ? (float) $pkg['price'] : 0.0;
            $sellingPrice = is_numeric($pkg['selling_price'] ?? null) && (float) $pkg['selling_price'] > 0
                ? (float) $pkg['selling_price']
                : $basePrice;

            return [
                'price' => $basePrice,
                'selling_price' => $sellingPrice,
            ];
        }

        return ['price' => 0.0, 'selling_price' => 0.0];
    }

    protected function handleRouterProfileAndStatus($customer, string $pppoeProfile, bool $isActive): array
    {
        try {
            $routerClient = routerClient($customer->router_id ?? null);
            if (!($routerClient instanceof \RouterOS\Client)) {
                return ['success' => true];
            }

            $pppoe = getPPPoEUserUserId($routerClient, $customer->id);
            $pppoeId = $pppoe[0]['.id'] ?? ($customer->pppoe_id ?? null);
            if (empty($pppoeId)) {
                return ['success' => true];
            }

            $userPpp = getPPPoEUser($routerClient, $pppoeId);
            $pppoeName = $userPpp[0]['name'] ?? '--';
            $pppoePassword = $userPpp[0]['password'] ?? '--';
            $pppoeService = $userPpp[0]['service'] ?? '--';

            if ($pppoeProfile !== '') {
                updatePPPoEUser($routerClient, [
                    'pppoe_name' => $pppoeName,
                    'pppoe_password' => $pppoePassword,
                    'pppoe_service' => $pppoeService,
                    'pppoe_profile' => $pppoeProfile,
                    'pppoe_id' => $pppoeId,
                ]);
            }

            if ($isActive) {
                enablePPPoEUser($routerClient, $pppoeId);
            } else {
                disablePPPoEUser($routerClient, $pppoeId);
            }

            return ['success' => true];
        } catch (\Throwable $e) {
            log_message('error', 'Router operation failed: ' . $e->getMessage());
            return ['success' => false, 'message' => 'Router operation failed'];
        }
    }

    protected function processResellerPayment(
        int $customerId,
        $customer,
        int $resellerId,
        string $selectedMonth,
        string $paidVia,
        string $methodTrx,
        string $status,
        array $calc
    ): array {
        $paymentModel = model('App\Models\Payment');
        $existing = $paymentModel->where([
            'user_id' => $customerId,
            'paidby' => $resellerId,
            'month' => $selectedMonth,
        ])->first();

        $reseller = $this->user_model->find($resellerId);
        $currentFund = (float) ($reseller->fund ?? 0);
        $newFund = $currentFund - (float) $calc['price'];
        if (!$this->user_model->update($resellerId, ['fund' => $newFund])) {
            return ['success' => false, 'message' => 'Failed to update reseller fund'];
        }

        $transactionModel = model('App\Models\ResellerTransactions');
        $txnInserted = $transactionModel->insert([
            'customer' => $customerId,
            'admin_id' => $resellerId,
            'amount' => $calc['price'],
            'package_price' => $calc['tprice'],
            'active_for' => $calc['difference'],
            'comments' => 'Customer Subscription Updated',
        ]);
        if (!$txnInserted) {
            return ['success' => false, 'message' => 'Failed to create reseller transaction'];
        }

        $payData = [
            'user_id' => $customerId,
            'user_type' => 'user',
            'admin_id' => $customer->admin_id,
            'paidby' => $resellerId,
            'invoice' => 'INV-' . random_int(100000, 999999),
            'amount' => $calc['price'],
            'pay_amount' => $calc['tprice'],
            'month' => $selectedMonth,
            'paid_via' => $paidVia,
            'paid_to' => $resellerId,
            'method_trx' => $methodTrx,
            'status' => $status,
            'created_at' => date('Y-m-d H:i:s'),
        ];

        if ($status === 'successful') {
            $payData['paid_at'] = date('Y-m-d H:i:s');
        }

        $paymentId = null;
        if (!empty($existing)) {
            $payData['amount'] = (float) ($existing->amount ?? 0) + (float) $calc['price'];
            if (!$paymentModel->update($existing->id, $payData)) {
                return ['success' => false, 'message' => 'Failed to update payment'];
            }
            $paymentId = (int) $existing->id;
        } else {
            $inserted = $paymentModel->insert($payData);
            if (!$inserted) {
                return ['success' => false, 'message' => 'Failed to create payment'];
            }
            $paymentId = (int) $paymentModel->getInsertID();
        }

        $paymentUrl = !empty($paymentId) ? route_to('Reseller.payment.pay', $paymentId) : null;

        return [
            'success' => true,
            'payment_id' => $paymentId,
            'payment_url' => $paymentUrl,
        ];
    }
}
