<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerEmployee extends BaseController
{
    protected $user_model;

    public function __construct()
    {
        $this->user_model = model('App\Models\User');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/employees/{resellerId}
     */
    public function fetch($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $employees = $this->user_model
            ->where(['role' => 'employee', 'admin_id' => $resellerId])
            ->orderBy('id', 'desc')
            ->findAll();

        return $this->response->setJSON(['status' => 'success', 'data' => $employees]);
    }

    /**
     * GET /api/reseller/employees/{resellerId}/{employeeId}
     */
    public function details($resellerId = null, $employeeId = null)
    {
        if (empty($resellerId) || empty($employeeId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or employee id']);
        }

        $employee = $this->user_model->where(['id' => $employeeId, 'role' => 'employee', 'admin_id' => $resellerId])->first();

        if (empty($employee)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Employee not found']);
        }

        return $this->response->setJSON(['status' => 'success', 'data' => $employee]);
    }

    /**
     * POST /api/reseller/employees/{resellerId}
     */
    public function create($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'name' => 'required',
            'designation' => 'required',
            'mobile' => 'required|is_unique[users.mobile]',
            'address' => 'required',
            'email' => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[4]',
            'status' => 'required|in_list[active,inactive]',
        ];

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $areaId = $input['area_id'] ?? null;
        if (is_array($areaId)) {
            $areaId = implode(',', $areaId);
        }

        $data = [
            'name' => $input['name'],
            'designation' => $input['designation'],
            'area_id' => $areaId,
            'mobile' => $input['mobile'],
            'address' => $input['address'],
            'email' => $input['email'],
            'password' => password_hash($input['password'], PASSWORD_DEFAULT),
            'role' => 'employee',
            'status' => $input['status'],
            'admin_id' => $resellerId,
            'created_by' => 'resellerAdmin',
        ];

        $result = $this->user_model->insert($data, false);

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'id' => $result, 'message' => 'Employee created successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Insert failed']);
    }

    /**
     * PUT /api/reseller/employees/{resellerId}/{employeeId}
     */
    public function update($resellerId = null, $employeeId = null)
    {
        if (empty($resellerId) || empty($employeeId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or employee id']);
        }

        $employee = $this->user_model->where(['id' => $employeeId, 'role' => 'employee', 'admin_id' => $resellerId])->first();
        if (empty($employee)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Employee not found']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'name' => 'required',
            'designation' => 'required',
            'mobile' => 'required|is_unique[users.mobile, id, ' . $employeeId . ']',
            'address' => 'required',
            'email' => 'required|is_unique[users.email, id, ' . $employeeId . ']',
            'status' => 'required|in_list[active,inactive]',
        ];

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $areaId = $input['area_id'] ?? null;
        if (is_array($areaId)) {
            $areaId = implode(',', $areaId);
        }

        $data = [
            'name' => $input['name'],
            'designation' => $input['designation'],
            'area_id' => $areaId,
            'mobile' => $input['mobile'],
            'address' => $input['address'],
            'email' => $input['email'],
            'status' => $input['status'],
        ];

        if (!empty($input['password'])) {
            $data['password'] = password_hash($input['password'], PASSWORD_DEFAULT);
        }

        $result = $this->user_model->where(['id' => $employeeId, 'role' => 'employee'])->set($data)->update();

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Employee updated successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Update failed']);
    }

    /**
     * DELETE /api/reseller/employees/{resellerId}
     */
    public function delete($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $ids = $input['ids'] ?? null;

        if (empty($ids) || !is_array($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
        }

        $result = $this->user_model->where('admin_id', $resellerId)->where('role', 'employee')->whereIn('id', $ids)->delete();

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Deleted successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Delete failed']);
    }
}
