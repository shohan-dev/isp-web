<?php

namespace App\Controllers\api\reseller;

use App\Controllers\BaseController;

class ApiResellerEmployeePayment extends BaseController
{
    protected $payment_model;
    protected $user_model;

    public function __construct()
    {
        $this->payment_model = model('App\Models\Payment');
        $this->user_model = model('App\Models\User');
        helper(['url', 'user']);
    }

    /**
     * GET /api/reseller/employee-payments/{resellerId}
     */
    public function fetch($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $payments = $this->payment_model
            ->where(['user_type' => 'employee', 'admin_id' => $resellerId])
            ->orderBy('id', 'desc')
            ->findAll();

        $result = [];
        foreach ($payments as $p) {
            $row = is_object($p) ? (array) $p : $p;
            $row['employee_name'] = getUserById($row['user_id'])->name ?? '--';
            $result[] = $row;
        }

        return $this->response->setJSON(['status' => 'success', 'data' => $result]);
    }

    /**
     * POST /api/reseller/employee-payments/{resellerId}
     */
    public function create($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'employee' => 'required|numeric',
            'amount' => 'required|numeric',
            'month' => 'required',
            'status' => 'required|in_list[successful,pending,failed]',
        ];

        if (($input['status'] ?? '') === 'successful') {
            $rules['paid_via'] = 'required';
        }

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $employeeId = $input['employee'];
        $employee = $this->user_model->where(['id' => $employeeId, 'role' => 'employee', 'admin_id' => $resellerId])->first();
        if (empty($employee)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Employee not found for this reseller']);
        }

        $data = [
            'user_id' => $employeeId,
            'user_type' => 'employee',
            'admin_id' => $resellerId,
            'paidby' => $resellerId,
            'invoice' => 'INV-' . random_int(1000, 9999),
            'amount' => $input['amount'],
            'month' => $input['month'],
            'created_at' => date('Y-m-d H:i:s'),
            'paid_via' => $input['paid_via'] ?? null,
            'status' => $input['status'],
        ];

        if ($input['status'] === 'successful') {
            $data['paid_at'] = date('Y-m-d H:i:s');
        }

        $result = $this->payment_model->insert($data, false);

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Employee payment created successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Insert failed']);
    }

    /**
     * PUT /api/reseller/employee-payments/{resellerId}/{paymentId}
     */
    public function update($resellerId = null, $paymentId = null)
    {
        if (empty($resellerId) || empty($paymentId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id or payment id']);
        }

        $payment = $this->payment_model->where(['id' => $paymentId, 'user_type' => 'employee', 'admin_id' => $resellerId])->first();
        if (empty($payment)) {
            return $this->response->setStatusCode(404)->setJSON(['status' => 'error', 'message' => 'Payment not found']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();

        $rules = [
            'amount' => 'required|numeric',
            'month' => 'required',
            'status' => 'required|in_list[successful,pending,failed]',
        ];

        if (($input['status'] ?? '') === 'successful') {
            $rules['paid_via'] = 'required';
        }

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'validation-error', 'errors' => $this->validator->getErrors()]);
        }

        $data = [
            'amount' => $input['amount'],
            'month' => $input['month'],
            'paid_via' => $input['paid_via'] ?? null,
            'status' => $input['status'],
        ];

        if ($input['status'] === 'successful') {
            $data['paid_at'] = date('Y-m-d H:i:s');
        }

        $result = $this->payment_model->update($paymentId, $data);

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Payment updated successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Update failed']);
    }

    /**
     * DELETE /api/reseller/employee-payments/{resellerId}
     */
    public function delete($resellerId = null)
    {
        if (empty($resellerId)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Missing reseller id']);
        }

        $input = $this->request->getJSON(true) ?: $this->request->getPost();
        $ids = $input['ids'] ?? null;

        if (empty($ids) || !is_array($ids)) {
            return $this->response->setStatusCode(400)->setJSON(['status' => 'error', 'message' => 'Nothing selected']);
        }

        $result = $this->payment_model->where('user_type', 'employee')->where('admin_id', $resellerId)->whereIn('id', $ids)->delete();

        if ($result) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Deleted successfully']);
        }

        return $this->response->setStatusCode(500)->setJSON(['status' => 'error', 'message' => 'Delete failed']);
    }
}
