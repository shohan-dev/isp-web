<?php

namespace App\Controllers\api;

use App\Controllers\BaseController;
use App\Models\ResellerPackages;
use App\Models\AdminPackage;
use App\Models\Registration;
use App\Models\UserRouterDataModel;
use App\Models\ContactModel;
use App\Models\MovieServersModel;
use App\Models\News_notice;

use CodeIgniter\CLI\Console;
use Ngekoding\CodeIgniterDataTables\DataTablesCodeIgniter4;


class ApiController extends BaseController
{
    protected $payment_model, $News_notice, $user_model, $area_model, $ticket_model, $package_model, $router_model, $AdminPackage, $movieModel;

    public function __construct()
    {
        /**
         * Payment Model
         */

        $this->payment_model = model('App\Models\Payment');
        $this->AdminPackage = model('App\Models\AdminPackage');
        $this->movieModel = new MovieServersModel();
        $this->News_notice = new News_notice();
        /**
         * User Model
         */
        $this->user_model = model('App\Models\User');

        /**
         * Area Model
         */
        $this->area_model = model('App\Models\Area');

        /**
         * Ticket Model
         */
        $this->ticket_model = model('App\Models\Ticket');

        /**
         * Package Model
         */
        $this->package_model = model('App\Models\Package');

        /**
         * Router Model
         */
        $this->router_model = model('App\Models\Router');
    }

    /**
     * Package list for a user row — mirrors Admin::packages() without session.
     */
    protected function resolvePackagesForUser(object $userRow): array
    {
        $role = $userRow->role ?? '';
        $admin_id = $userRow->admin_id ?? null;
        $created_by = $userRow->created_by ?? '';

        if ($role === 'sAdmin') {
            $packageModel = new AdminPackage();

            return $packageModel->where(['Activity' => 'active'])->findAll();
        }

        if ($role === 'user') {
            if ($created_by === 'resellerAdmin' && !empty($admin_id)) {
                $packageModel = model('App\Models\allResellerPackage');
                $rawPackages = $packageModel->where('user_id', $admin_id)->findAll();
                $packages = [];
                foreach ($rawPackages as $package) {
                    $row = is_array($package) ? $package : (array) $package;
                    $raw = $row['package_details'] ?? null;
                    $decoded = is_string($raw) ? json_decode($raw, true) : $raw;
                    if (!is_array($decoded)) {
                        continue;
                    }
                    foreach ($decoded as $detail) {
                        $packages[] = is_array($detail) ? $detail : (array) $detail;
                    }
                }

                return $packages;
            }

            $package_model = model('App\Models\Package');

            return $package_model->where(['user_id' => $admin_id])->findAll();
        }

        $packageModel = new AdminPackage();

        return $packageModel->findAll();
    }

    protected function statistics($role = null, $user_id = null, $admin_id = null)
    {
        $months = [];
        $success_payment = [];
        $pending_payment = [];
        $failed_payment = [];


        for ($i = 1; $i <= date('m'); $i++) {

            $successful = $this->__transactionStatistics(

                'successful',
                date('F', mktime(0, 0, 0, $i, 1, 2022)),
                $role,
                $user_id,
                $admin_id,

            );

            $pending = $this->__transactionStatistics(

                'pending',
                date('F', mktime(0, 0, 0, $i, 1, 2022)),
                $role,
                $user_id,
                $admin_id,

            );

            $failed = $this->__transactionStatistics(

                'failed',
                date('F', mktime(0, 0, 0, $i, 1, 2022)),
                $role,
                $user_id,
                $admin_id,

            );

            //push month name in array
            array_push($months, date('M', mktime(0, 0, 0, $i, 1, 2022)));

            //push successful payment in array
            array_push($success_payment, $successful);

            //push pending payment in array
            array_push($pending_payment, $pending);

            //push failed payment in array
            array_push($failed_payment, $failed);
        }

        return [
            'months' => $months,
            'successful' => $success_payment,
            'pending' => $pending_payment,
            'failed' => $failed_payment
        ];
    }




    /**
     * Dashboard
     * @action: Transaction Statictics
     */
    protected function __transactionStatistics($status, $month, $role = null, $user_id = null, $admin_id = null)
    {

        $conditions = [
            'month' => $month,
            'status' => $status
        ];

        if (!empty($role)) {

            $conditions['user_type'] = $role;
        }

        if (!empty($user_id)) {

            $conditions['user_id'] = $user_id;
        }

        if (!empty($admin_id)) {
            $conditions['admin_id'] = $admin_id;
        }

        // log_message('debug', 'User conditions id Type: ' . print_r($conditions, true));


        $row = $this->payment_model->selectSum('amount')->where($conditions)->first();

        return (int) ($row->amount ?? 0);
    }

    /**
     * Sum payment amounts for a subscriber (user paying their own invoices).
     */
    protected function sumUserSelfPayments($userId, ?string $status = null): int
    {
        $builder = $this->payment_model->selectSum('amount')->where([
            'user_id' => $userId,
            'paidby' => $userId,
            'user_type' => 'user',
        ]);
        if ($status !== null && $status !== '') {
            $builder->where('status', $status);
        }
        $row = $builder->first();

        return (int) ($row->amount ?? 0);
    }

    public function index($id = null)
    {
        log_message('debug', 'API user id : ' . print_r($id, true));

        if ($id === null || $id === '' || ! is_numeric($id)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Valid user id is required',
            ])->setStatusCode(400);
        }

        $details = $this->user_model->where(['id' => $id, 'role' => 'user'])->first();
        if (empty($details)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'User not found',
            ])->setStatusCode(404);
        }

        $uid = (string) $details->id;
        $ppoe = '';
        $router_client = routerClient($details->router_id);

        if (! is_array($router_client)) {
            $pppoe = getPPPoEUserUserId($router_client, $details->id);
            $pppoe_id = $pppoe[0]['.id'] ?? $details->pppoe_id ?? null;

            log_message('info', "PPPoE ID for User ID {$details->id}: {$pppoe_id}");

            $user_ppp = getPPPoEUser($router_client, $pppoe_id);
            $interface = getGetInput('interface') ?? null;
            $ppoe = $user_ppp[0]['name'] ?? '--';
        }

        $paymentSuccessful = $this->sumUserSelfPayments($uid, 'successful');
        $paymentPending = $this->sumUserSelfPayments($uid, 'pending');
        $paymentFailed = $this->sumUserSelfPayments($uid, 'failed');
        $paymentTotal = $paymentSuccessful + $paymentPending + $paymentFailed;

        $data = [
            'status' => 'success',
            'pppoe' => $ppoe,
            'details' => $details,
            // Totals for this user (same scope: user_id + paidby + user_type user)
            'payment_received' => $paymentSuccessful,
            'payment_pending' => $paymentPending,
            'payment_failed' => $paymentFailed,
            'payment_total' => $paymentTotal,
            // Explicit alias for clients that expect "successful"
            'payment_successful' => $paymentSuccessful,
            'total_support_ticket' => (int) $this->ticket_model
                ->where(['user_id' => $uid])
                ->countAllResults(),
            'statistics' => $this->statistics('user', $uid, null),
        ];

        return $this->response->setJSON($data);
    }

    public function fetch()
    {
        $user_id = $this->request->getGet('user_id') ?? null;
        log_message('debug', 'API Payment user id : ' . print_r($user_id, true));

        $data = $this->payment_model
            ->select('*')
            ->groupStart()
            ->where('user_id', $user_id)
            ->Where('paidby', $user_id)
            ->groupEnd()
            ->orderBy('id', 'desc')
            ->findAll();

        // log_message('debug', 'API Payment user id Query : ' . print_r($data, true));

        // ✅ Fix: Reindex array to ensure proper JSON array structure
        // $data = array_values($data);

        return $this->response->setJSON($data);
    }

    public function packages()
    {
        $userId = $this->request->getGet('user_id');
        if (empty($userId)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'user_id query parameter is required',
            ])->setStatusCode(400);
        }

        log_message('debug', 'API packages user id : ' . print_r($userId, true));

        $details = $this->user_model->where(['id' => $userId])->first();
        if (empty($details)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'User not found',
            ])->setStatusCode(404);
        }

        $packages = $this->resolvePackagesForUser($details);

        return $this->response->setJSON([
            'status' => 'success',
            'package_id' => $details->package_id,
            'pre_package' => $details->pre_package,
            'subscription_status' => $details->subscription_status,
            'last_renewed' => $details->last_renewed,
            'will_expire' => $details->will_expire,
            'packages' => $packages,
        ]);
    }

    public function Subscription_index()
    {
        $userId = $this->request->getGet('user_id');
        if (empty($userId)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'user_id query parameter is required',
            ])->setStatusCode(400);
        }

        $userDetails = $this->user_model->where(['id' => $userId])->first();
        if (empty($userDetails)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'User not found',
            ])->setStatusCode(404);
        }

        $packages = $this->resolvePackagesForUser($userDetails);

        return $this->response->setJSON([
            'status' => 'success',
            'title' => 'My Subscription',
            'details' => $userDetails,
            'packages' => $packages,
            'package_id' => $userDetails->package_id,
            'pre_package' => $userDetails->pre_package,
            'subscription_status' => $userDetails->subscription_status,
        ]);
    }

    public function Subscription_renew()
    {
        try {
            // Get input parameters
            $packageId = $this->request->getGet('package_id');
            $userId = $this->request->getGet('customer') ?? $this->request->getPost('customer');
            $userRole = $this->request->getGet('role') ?? null;

            // Validate required parameters
            if (!$packageId) {
                return requestResponse('error', 'Package ID is required', 400);
            }

            if (!$userId) {
                return requestResponse('error', 'Customer ID is required', 400);
            }

            log_message('info', 'Package ID: ' . $packageId . ', User ID: ' . $userId);

            // Initialize models
            $userModel = model('App\Models\User');
            $paymentModel = $this->payment_model;

            // Get user details
            $userDetails = $userModel->where(['id' => $userId])->first();
            if (!$userDetails) {
                return requestResponse('error', 'User not found', 404);
            }

            // Extract user data (handling both object and array)
            if (is_object($userDetails)) {
                $currentPackageId = $userDetails->package_id;
                $adminId = $userDetails->admin_id;
                $role = $userRole ?? $userDetails->created_by;
                $willExpire = $userDetails->will_expire;
            } else {
                $currentPackageId = $userDetails['package_id'];
                $adminId = $userDetails['admin_id'];
                $role = $userRole ?? $userDetails['created_by'];
                $willExpire = $userDetails['will_expire'];
            }

            $currentMonth = date('F');

            // Existing row for this calendar month (invoice may still be unpaid)
            $existingPayment = $paymentModel->where([
                'user_id' => $userId,
                'paidby' => $userId,
                'month' => $currentMonth
            ])->first();

            // Only block when this month is already *paid* for the same package as the user's
            // current assignment. Pending/failed invoices must be allowed so the client can
            // regenerate or update the amount (same path as web renew).
            if ($existingPayment) {
                $payStatus = strtolower((string) (is_object($existingPayment)
                    ? ($existingPayment->status ?? '')
                    : ($existingPayment['status'] ?? '')));
                $samePackage = (string) $currentPackageId === (string) $packageId;
                if ($payStatus === 'successful' && $samePackage) {
                    return requestResponse(
                        'error',
                        'This billing period is already paid for your current package.',
                        400
                    );
                }
            }

            // Calculate price based on package change and user role
            $price = $this->calculateSubscriptionPrice($userId, $packageId, $currentPackageId, $role, $willExpire, $adminId);

            if ($price === false) {
                return requestResponse('error', "Unable to calculate subscription price", 500);
            }

            // Prepare payment data
            $paymentData = [
                'user_id' => $userId,
                'admin_id' => $adminId,
                'paidby' => $userId,
                'user_type' => 'user',
                'invoice' => 'INV-' . random_int(100000, 999999),
                'amount' => $price,
                'month' => $currentMonth,
                'created_at' => date('Y-m-d H:i:s'),
            ];

            // Save payment record
            if ($existingPayment) {
                $result = $paymentModel->update($existingPayment->id, $paymentData);
                $paymentId = $existingPayment->id;
            } else {
                $result = $paymentModel->insert($paymentData);
                $paymentId = $paymentModel->getInsertID();
            }

            if ($result) {
                $paymentUrl = route_to('route.payment.pay', $paymentId);

                $responseData = [
                    'msg' => 'Payment invoice is generated. You can make payment anytime from `My Payment` option. Or if you want to pay now then click on `Pay` button below',
                    'payment_url' => $paymentUrl,
                ];

                return $this->response->setJSON($responseData);
            }

            return requestResponse('error', "Failed to create payment record", 500);
        } catch (\Exception $e) {
            log_message('error', 'Subscription renewal error: ' . $e->getMessage());
            return requestResponse('error', "An unexpected error occurred", 500);
        }
    }

    /**
     * Calculate subscription price based on various factors
     */
    private function calculateSubscriptionPrice($userId, $newPackageId, $currentPackageId, $role, $willExpire, $adminId = null)
    {
        $price = 0;
        $difference = 0;

        // Check if package is being changed
        if ($currentPackageId != $newPackageId) {
            // Calculate remaining days from current subscription
            $now = time();
            $willExpireTime = strtotime($willExpire);

            if (is_numeric($willExpireTime) && $willExpireTime > $now) {
                $difference = floor(($willExpireTime - $now) / (60 * 60 * 24));
                log_message('info', 'Remaining days: ' . $difference);
            }

            // Update user's package
            $userModel = model('App\Models\User');
            $userModel->update($userId, [
                'package_id' => $newPackageId,
                'pre_package' => $currentPackageId,
            ]);
        }

        // Get price based on user role
        if ($role === 'resellerAdmin') {
            $price = $this->getResellerPrice($newPackageId, $adminId, $currentPackageId, $difference);
        } else {
            $price = $this->getRegularUserPrice($userId, $newPackageId, $currentPackageId, $difference);
        }

        return $price;
    }

    /**
     * Get price for reseller admin
     */
    private function getResellerPrice($packageId, $adminId, $currentPackageId, $difference)
    {
        $userModel = model('App\Models\User');
        $adminDetails = $userModel->where(['id' => $adminId])->first();

        if (!$adminDetails) {
            return false;
        }

        // Check admin fund
        $fund = is_object($adminDetails) ? $adminDetails->fund : $adminDetails['fund'];
        $price = ResellerPackagePrice($packageId);

        log_message('info', 'Reseller package price: ' . $price . ', Fund: ' . $fund);

        if ($fund < $price) {
            throw new \Exception("Your Reseller doesn't have enough fund. Please contact with him.");
        }

        // Calculate price difference if package changed
        if ($currentPackageId != $packageId && $difference > 0) {
            $oldPrice = ResellerPackagePrice($currentPackageId);
            $pricePerDay = $oldPrice / 30;
            $creditAmount = $pricePerDay * $difference;
            $price = max($price - $creditAmount, 0);
        }

        return $price;
    }

    /**
     * Get price for regular user
     */
    private function getRegularUserPrice($userId, $newPackageId, $currentPackageId, $difference)
    {
        $newPackage = getUserPackage($userId, $newPackageId);
        $price = is_object($newPackage) ? $newPackage->price : $newPackage['price'];

        // Calculate price difference if package changed
        if ($currentPackageId != $newPackageId && $difference > 0) {
            $currentPackage = getUserPackage($userId, $currentPackageId);
            $oldPrice = is_object($currentPackage) ? $currentPackage->price : $currentPackage['price'];

            $pricePerDay = $oldPrice / 30;
            $creditAmount = $pricePerDay * $difference;
            $price = max($price - $creditAmount, 0);
        }

        return $price;
    }

    public function Support_ticket_index()
    {
        $userId = $this->request->getGet('user_id') ?? null;
        $userRole = $this->request->getGet('role') ?? null;
        $details = $this->user_model->where(['id' => $userId])->first();

        if ($userRole === 'employee') {
            // $userModel = model('App\Models\User');
            // $details = $userModel->where(['id' => $userId])->first();
            $Pre_created_by = $details->created_by;
            if ($Pre_created_by === 'sAdmin') {
                $userId = $details->admin_id;
                $details = $this->user_model->where(['id' => $userId])->first();
            } else {
                $userId = $details->admin_id;
                $details = $this->user_model->where(['id' => $userId])->first();
                $userId = $details->admin_id;
            }
        }
        $resellers = $this->user_model
            ->select('*')
            ->where('role', 'employee')
            ->where('admin_id', $userId)
            ->findAll();


        $data = [
            'title' => 'Support Tickets',
            'resellers' => $resellers,
            'details' => $details
        ];

        return $this->response->setJSON($data);
    }


    public function Support_ticket_fetch()
    {
        try {
            $userRole = $this->request->getGet('user_role');
            $userId = $this->request->getGet('user_id');

            log_message('debug', 'Support Ticket Fetch API - User Role: ' . $userRole . ', User ID: ' . $userId);

            // Build query
            if ($userRole === 'employee') {
                $builder = $this->ticket_model->builder()
                    ->select('*')
                    ->where("JSON_CONTAINS(admin_ids, '\"{$userId}\"')", null, false)
                    ->orderBy('id', 'desc');
            } else {
                $tickets = $this->ticket_model
                    ->select('*')
                    ->where('user_id', $userId)
                    ->orderBy('id', 'desc')
                    ->findAll();
            }

            // Fetch results
            // $tickets = $builder->get()->getResult();
            $data = [
                'status' => 'success',
                'response' => 'Tickets fetched successfully',
                'data' => $tickets
            ];

            return $this->response->setJSON($data);
            // Return JSON response

        } catch (\Throwable $e) {
            return $this->response->setJSON([
                'status' => 'error',
                'response' => 'An error occurred: ' . $e->getMessage()
            ])->setStatusCode(500);
            // return $this->failServerError('An error occurred: ' . $e->getMessage());
        }
    }
    public function ticket_details()
    {
        $id = $this->request->getGet('ticket_id');
        $userRole = $this->request->getGet('user_role');

        log_message('debug', 'Fetching details for ticket ID: ' . $id);
        // log_message('debug', 'Condition applied: ' . print_r($this->condition($id), true));
        $details = $this->ticket_model->where('id', $id)->first();

        log_message('debug', 'Ticket details: ' . print_r($details, true));
        if (!empty($details)) {

            if ($userRole != 'user') {

                $this->ticket_model->update($id, ['viewed' => 'yes']);
            }

            $user = getUserById($details->user_id);

            $data = [
                'title'    => 'Ticket Details',
                'details'  => $details,
                'canReply' => !empty($user),
            ];

            return $this->response->setJSON($data);
            // return view('tickets/details', $data);
        }

        show_404();
    }

    public function profile_update()
    {
        // if (!userHasPermission('profile_update', 'update')) show_404();
        $userId = $this->request->getGet('user_id');
        $data = [
            'name'     => $this->request->getGet('name'),
            'mobile'   => $this->request->getGet('mobile'),
            'email'    => $this->request->getGet('email'),
            'address'  => $this->request->getGet('address'),
            // 'posPrinter' => getPostInput('posPrinter'),
        ];

        log_message('debug', 'API Profile update data : ' . print_r($data, true));
        log_message('debug', 'API Profile update userId : ' . print_r($userId, true));

        $result = $this->user_model->update($userId, $data);

        if ($result) {

            return $this->response->setJSON($result);
        }

        return requestResponse('error', "Something went wrong! Please try again", 500);
    }

    public function sendMessage()
    {
        $id = $this->request->getGet('ticket_id');
        $userId = $this->request->getGet('current_user_id');
        $message = $this->request->getGet('message');

        log_message('debug', 'API Ticket message : ' . print_r($message, true));

        $ticket = $this->ticket_model->where('id', $id)->first();

        $details = $ticket->details ? json_decode($ticket->details) : [];

        $new_data = [
            'sender' => $userId,
            'msg' => trim($message),
            'datetime' => date("d-m-y, h:i a"),
        ];

        array_push($details, $new_data);

        $data = [
            'details' => json_encode($details),
        ];

        log_message('debug', 'API Ticket update data : ' . print_r($data, true));

        $result = $this->ticket_model->update($id, $data);

        if ($result) {

            if ($ticket->user_id != $userId) {

                $user = getUserById($ticket->user_id);

                //send email notification
                sendMail(
                    $user->email,
                    getSetting('app_name') . ' | Support Ticket Update',
                    view('emails/support-ticket-answered', [
                        'user'    => $user->name,
                        'subject' => $ticket->subject,
                        'message' => 'Your support ticket from ' . getSetting("site_name") . ' has been answered'
                    ]),
                );
            }

            $data = [
                'ticket_id' => $id,
                'user_id'   => $userId,
                'message'   => trim(getPostInput('message')),
                'datetime'  => date("d-m-y, h:i a"),
            ];

            return $this->response->setJSON($data);
        }

        return requestResponse('error', "Something went wrong! Please try again", 500);
    }


    public function activatePackage()
    {
        $userId = $this->request->getPost('user_id') ?? $this->request->getGet('user_id');
        $packageId = $this->request->getPost('package_id') ?? $this->request->getGet('package_id');

        if (empty($userId) || empty($packageId)) {
            return $this->response->setJSON([
                'status' => 'error',
                'success' => false,
                'message' => 'user_id and package_id are required',
            ])->setStatusCode(400);
        }

        log_message('info', 'activatePackage user_id=' . $userId . ' package_id=' . $packageId);

        $userModel = model('App\Models\User');
        $details = $userModel->where(['id' => $userId])->first();

        if (empty($details)) {
            return $this->response->setJSON([
                'status' => 'error',
                'success' => false,
                'message' => 'User not found',
            ])->setStatusCode(404);
        }

        if ($details->subscription_status === 'inactive') {
            return $this->response->setJSON([
                'status' => 'error',
                'success' => false,
                'message' => 'Complete payment for your pending package before selecting another.',
            ])->setStatusCode(400);
        }

        $data = [
            'package_id' => $packageId,
            'pre_package' => $details->package_id,
            'will_expire' => date('Y-m-d H:i:s'),
            'subscription_status' => 'inactive',
            'conn_status' => 'disconn',
        ];

        if ($userModel->update($userId, $data)) {
            return $this->response->setJSON([
                'status' => 'success',
                'success' => true,
                'message' => 'New package is pending. Complete payment to activate your subscription.',
                'data' => [
                    'package_id' => (string) $packageId,
                    'pre_package' => (string) $details->package_id,
                    'subscription_status' => 'inactive',
                ],
            ]);
        }

        return $this->response->setJSON([
            'status' => 'error',
            'success' => false,
            'message' => 'Could not update package selection',
        ])->setStatusCode(500);
    }

    /**
     * Update subscription dates/package (Admin subscription form) — POST only, no session.
     */
    public function userSubscriptionUpdate()
    {
        $userId = $this->request->getPost('user_id');
        if (empty($userId)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'user_id is required',
            ])->setStatusCode(400);
        }

        if (!$this->user_model->where(['id' => $userId])->first()) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'User not found',
            ])->setStatusCode(404);
        }

        $this->validate([
            'package_id' => [
                'rules' => 'required',
                'errors' => ['required' => 'Select a package'],
            ],
            'last_renewed' => [
                'rules' => 'required',
                'errors' => ['required' => 'Select renewal date'],
            ],
            'will_expire' => [
                'rules' => 'required',
                'errors' => ['required' => 'Select expire date'],
            ],
        ]);

        if (!$this->validation->run()) {
            return $this->response->setJSON([
                'status' => 'validation-error',
                'response' => $this->validation->getErrors(),
            ])->setStatusCode(400);
        }

        $willExpireStr = (string) getPostInput('will_expire');
        $willTs = strtotime($willExpireStr);
        $isActive = $willTs !== false && $willTs > time();

        $data = [
            'package_id' => getPostInput('package_id'),
            'last_renewed' => getPostInput('last_renewed'),
            'will_expire' => $willExpireStr,
            'subscription_status' => $isActive ? 'active' : 'inactive',
            'conn_status' => $isActive ? 'conn' : 'disconn',
        ];

        if ($this->user_model->where(['id' => $userId])->set($data)->update()) {
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Subscription updated successfully',
            ]);
        }

        return $this->response->setJSON([
            'status' => 'error',
            'message' => 'Something went wrong. Please try again.',
        ])->setStatusCode(500);
    }

    public function check_permission()
    {

        $user_id = $this->request->getGet('user_id') ?? null;

        $details = $this->user_model->where(['id' => $user_id])->first();
        $role = $details->role ?? '--';
        $admin_id = $details->admin_id ?? '--';
        $created_by = $details->created_by ?? '--';

        if ($created_by === 'resellerAdmin') {
            $details = $this->user_model->where(['id' => $admin_id])->first();
            $admin_id = $details->admin_id ?? '--';
        }
        // if ($role === 'admin')
        //     return true;

        $model = model('App\Models\CustomAccess');

        $permission = $model->where(['user_id' => $user_id, 'status' => 'active'])->first();
        // dd($permission);
        // log_message('debug', 'User permission: ' . print_r($permission, true));
        /**
         * If no specific permission then get the default one
         */
        if (empty($permission)) {

            $model = model('App\Models\Permission');
            // dd($permission);

            if ($role == 'resellerAdmin' || $role == 'user' || $role == 'employee') {

                $permission = $model->where(['user_type' => $role, 'user_id' => $admin_id])->first();
                // dd($permission);
            } elseif ($role == 'sAdmin') {
                // fixed the admin id =2 for all admin and super admin
                $permission = $model->where(['user_type' => $role, 'user_id' => 2])->first();
                // dd($permission);
            }
        }

        if (!empty($permission->permissions)) {
            // dd($permission->permissions);

            $permission = json_decode($permission->permissions, true);
            // log_message('debug', 'Permission data: ' . print_r($data, true));
            // log_message('debug', 'Checking permission for menu: ' . $menu . ' and sub_menu: ' . $sub_menu);
            // if (empty($sub_menu)) {
            //     // log_message('debug', 'Checking permission for menu: ' . $menu);

            //     return array_key_exists($menu, $data);
            // }

            // log_message('debug', 'Checking permission for menu: ' . ((array_key_exists($menu, $data) && in_array($sub_menu, $data[$menu])) ? 'true' : 'false'));

            // return array_key_exists($menu, $data) ? in_array($sub_menu, $data[$menu]) : false;
        }

        return $this->response->setJSON(['permission' => $permission]);
    }

    public function create_ticket()
    {
        // $this->validate([
        //     'subject' => [
        //         'rules' => 'required',
        //         'errors' => [
        //             'required' => 'Enter subject',
        //         ]
        //     ],
        //     'category' => [
        //         'rules' => 'required',
        //         'errors' => [
        //             'required' => 'Select category',
        //         ]
        //     ],
        //     'priority' => [
        //         'rules' => 'required',
        //         'errors' => [
        //             'required' => 'Select priority',
        //         ]
        //     ],
        //     // 'customer' => [
        //     //     'rules' => 'required',
        //     //     'errors' => [
        //     //         'required' => 'Select employee',
        //     //     ]
        //     // ],
        //     'message' => [
        //         'rules' => 'required',
        //         'errors' => [
        //             'required' => 'Enter your message',
        //         ]
        //     ]
        // ]);

        $userId = $this->request->getGet('user_id') ?? null;
        // $adminid = $this->request->getGet('admin_id') ?? null;

        $subject = $this->request->getGet('subject') ?? null;
        $category = $this->request->getGet('category') ?? null;
        $priority = $this->request->getGet('priority') ?? null;
        $message = $this->request->getGet('message') ?? null;



        // $uid = $userId;
        $details = $this->user_model->where(['id' => $userId])->first();

        $admin_id = $details->admin_id;
        if (is_object($details)) {
            $admin_id = $details->admin_id;
        } elseif (is_array($details)) {
            // $will_expire = $customer_details['will_expire'] ?? null;
            $admin_id = $details['admin_id'];
        } else {
            $admin_id = null;
        }


        // $id = $admin_id;
        // $id = (!empty($id)) ? $id : $admin_id;

        $data = [
            'user_id'   => $userId,
            'subject'   => $subject,
            'category'  => $category,
            'priority'  => $priority,
            'admin_ids' => json_encode($admin_id),
            'details'   => json_encode([[
                'sender'   => $userId,
                'datetime' => date("d-m-y, h:i a"),
                'msg'      => $message,
            ]]),
            'datetime'  => date("Y-m-d, H:i:s"),
        ];
        log_message('debug', 'result data: ' . print_r($data, true));

        $result = $this->ticket_model->insert($data);
        log_message('debug', 'result data: ' . print_r($result, true));

        if ($result) {

            $ticket = $this->ticket_model->where('id', $result)->first();

            $user = getUserById($userId);

            $email_data = [
                'user' => $user->name,
                'subject' => $ticket->subject,
                'status_text' => 'has been opened'
            ];

            //send email notification
            sendMail(
                $user->email,
                getSetting('app_name') . ' | Support Ticket Update',
                view('emails/support-ticket-open-closed', $email_data),
            );

            return requestResponse('success', 'Ticket opened successfully', 200);
        }

        return requestResponse('success', 'Something went wrong! Please try again', 500);
    }

    public function makePayment($id)
    {
        log_message('info', 'Make Payment called with ID: ' . $id);
        $details = $this->payment_model->where(['id' => $id, 'status' => 'pending', 'user_type' => 'user'])->first();

        if (!empty($details)) {

            $amount = floatval($details->amount ?? 0);
            $data = [
                'title' => 'Payment Gateway',
                'details' => $details,
                'bkash_charge' => ($amount * (floatval(getSetting('bkashpg_charge') ?? 0) / 100)),
                'nagad_charge' => ($amount * (floatval(getSetting('nagadpg_charge') ?? 0) / 100)),
                'sslcommerz_charge' => ($amount * (floatval(getSetting('sslcommerz_charge') ?? 0) / 100)),
            ];

            // log_message('info', 'Successfully called the URL: ' . print_r($data,true));


            return view('payments/api_gateway', $data);
        }

        show_404();
    }
    public function makePaymentReselar($id)
    {
        log_message('info', 'Make Payment called with ID: ' . $id);
        $details = $this->payment_model->where(['id' => $id, 'status' => 'pending', 'user_type' => 'reseller'])->first();

        if (!empty($details)) {

            $amount = floatval($details->amount ?? 0);
            $data = [
                'title' => 'Payment Gateway',
                'details' => $details,
                'bkash_charge' => ($amount * (floatval(getSetting('bkashpg_charge') ?? 0) / 100)),
                'nagad_charge' => ($amount * (floatval(getSetting('nagadpg_charge') ?? 0) / 100)),
                'sslcommerz_charge' => ($amount * (floatval(getSetting('sslcommerz_charge') ?? 0) / 100)),
            ];

            // log_message('info', 'Successfully called the URL: ' . print_r($data,true));


            return view('payments/api_gateway', $data);
        }

        show_404();
    }

    /**
     * MikroTik PPPoE expiry checker.
     *
     * Query params:
     * - name: PPPoE secret name (preferred)
     * - token: shared token from env MIKROTIK_API_TOKEN (optional if env empty)
     *
     * Returns plain text for easy RouterOS parsing:
     * - ACTIVE
     * - EXPIRED|<payment_url>
     * - UNKNOWN|<login_url>
     * - DENY
     */
    public function pppoeExpiryCheck()
    {
        $pppoeName = trim((string) $this->request->getGet('name'));
        $token = trim((string) $this->request->getGet('token'));

        $expectedToken = trim((string) getenv('MIKROTIK_API_TOKEN'));
        if ($expectedToken !== '' && !hash_equals($expectedToken, $token)) {
            return $this->response
                ->setStatusCode(403)
                ->setContentType('text/plain')
                ->setBody('DENY');
        }

        if ($pppoeName === '') {
            return $this->response
                ->setStatusCode(400)
                ->setContentType('text/plain')
                ->setBody('ERROR|MISSING_NAME');
        }

        $routerDataModel = model('App\Models\UserRouterDataModel');
        $userModel = model('App\Models\User');
        $paymentModel = $this->payment_model;
        $packageModel = model('App\Models\Package');

        $user = $routerDataModel
            ->select('users.id as user_id, users.admin_id, users.package_id, users.created_by, users.status as account_status, users.subscription_status, users.conn_status, users.will_expire')
            ->join('users', 'users.id = user_router_data.user_id', 'inner')
            ->where('users.role', 'user')
            ->where('user_router_data.pppoe_secret', $pppoeName)
            ->first();

        // Fallback: allow PPPoE .id lookups if name lookup fails.
        if (empty($user)) {
            $user = $userModel
                ->select('id as user_id, admin_id, package_id, created_by, status as account_status, subscription_status, conn_status, will_expire')
                ->where('role', 'user')
                ->where('pppoe_id', $pppoeName)
                ->first();
        }

        if (empty($user)) {
            return $this->response
                ->setStatusCode(200)
                ->setContentType('text/plain')
                ->setBody('UNKNOWN|' . base_url(route_to('route.auth.login')));
        }

        $now = time();
        $willExpireTs = !empty($user->will_expire) ? strtotime((string) $user->will_expire) : null;
        $isExpiredByDate = is_int($willExpireTs) && $willExpireTs <= $now;
        $isExpiredByStatus = ($user->subscription_status === 'inactive');
        $isExpiredByAccount = ($user->account_status !== 'active');

        $isExpired = $isExpiredByDate || $isExpiredByStatus || $isExpiredByAccount;

        if (!$isExpired) {
            return $this->response
                ->setStatusCode(200)
                ->setContentType('text/plain')
                ->setBody('ACTIVE');
        }

        $pendingPayment = $paymentModel
            ->select('id')
            ->where([
                'user_id' => $user->user_id,
                'paidby' => $user->user_id,
                'user_type' => 'user',
                'status' => 'pending',
                'month' => date('F'),
            ])
            ->orderBy('id', 'DESC')
            ->first();

        if (empty($pendingPayment)) {
            $amount = 0;

            if ($user->created_by === 'resellerAdmin') {
                $amount = (float) (ResellerPackagePrice($user->package_id, null, $user->admin_id, 'resellerAdmin') ?? 0);
            } else {
                $package = $packageModel->select('price')->where('id', $user->package_id)->first();
                $amount = (float) (($package->price ?? 0));
            }

            $paymentData = [
                'user_id' => $user->user_id,
                'admin_id' => $user->admin_id,
                'paidby' => $user->user_id,
                'user_type' => 'user',
                'invoice' => 'INV-' . random_int(100000, 999999),
                'amount' => $amount,
                'month' => date('F'),
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s'),
            ];

            $paymentModel->insert($paymentData);
            $pendingPaymentId = (int) $paymentModel->getInsertID();
        } else {
            $pendingPaymentId = (int) $pendingPayment->id;
        }

        $paymentUrl = $pendingPaymentId > 0
            ? base_url('api/make-payment/' . $pendingPaymentId)
            : base_url(route_to('route.auth.login'));

        return $this->response
            ->setStatusCode(200)
            ->setContentType('text/plain')
            ->setBody('EXPIRED|' . $paymentUrl);
    }

    
    public function invoicePrint()
    {
        // Step 1: Get invoice ID from GET request
        $id = $this->request->getGet('invoice_id') ?? null;
        $userId = $this->request->getGet('user_id') ?? null;

        log_message('debug', "invoicePrint() called with invoice_id={$id}");

        // if (empty($id)) {
        //     log_message('error', "invoicePrint() called without invoice_id.");
        //     return $this->response->setJSON([
        //         'status' => 'error',
        //         'message' => 'Missing invoice_id parameter.'
        //     ]);
        // }

        if (!empty($userId)) {
            $orderDetails = $this->payment_model
                ->where(['id' => $id, 'status' => 'successful'])
                ->first();

            if (!empty($orderDetails)) {
                // Fetch user details
                $user = $this->user_model->find($orderDetails->user_id);
                $adminid = $this->request->getGet('admin_id') ?? ($orderDetails->admin_id ?? null);
                if (empty($adminid)) {
                    return $this->response->setJSON([
                        'status' => 'error',
                        'message' => 'admin_id is required (or invoice must include admin_id).',
                    ])->setStatusCode(400);
                }
                $admindata = $this->user_model->find($adminid);
                // $admindata = getUserById($details->user_id);
                $reseller_model = model('App\Models\Registration');
                $rdetails = $reseller_model->where(['userid' => $adminid])->first();



                // Prepare data for the view
                $data = [
                    'details' => $orderDetails,
                    'rdetails' => $rdetails,
                    'user' => $user,
                    'admin' => $admindata,
                ];
                log_message('debug', json_encode($data));
                // Generate PDF
                // $mpdf = new \Mpdf\Mpdf([
                //     'mode' => 'utf-8',
                //     'format' => [58, 150], // 58mm x 100mm
                //     'orientation' => 'P',
                //     'default_font' => 'hindsiliguri',
                // ]);

                // $mpdf = new \Mpdf\Mpdf([
                //     'format' => [58, 150],
                //     'margin_left' => 0,
                //     'margin_right' => 0,
                //     'margin_top' => 0,
                //     'margin_bottom' => 0,
                // ]);

                $html = view('payments/pos', $data);

                log_message('debug', 'Generated HTML for mPDF: ' . print_r($html, true) . '...');

                // Step 7: Render the invoice view
                log_message('debug', 'Rendering invoice view for mPDF...');


                // Set header for PDF output
                // $this->response->setHeader('Content-Type', 'application/pdf');

                // // Output the PDF
                // return $mpdf->Output("payment-invoice-" . strtolower($orderDetails->month) . "-" . date("d-m-Y", strtotime($orderDetails->paid_at)) . "-" . date("h-i-s") . ".pdf", "I");


                return $this->response
                    ->setHeader('Content-Type', 'text/html')
                    ->setBody($html);
            }
        } else {

            // Step 2: Fetch invoice details
            $details = $this->payment_model
                ->where(['id' => $id, 'status' => 'successful'])
                ->first();

            log_message('debug', 'Fetched payment details: ' . json_encode($details));

            if (empty($details)) {
                log_message('error', "No successful payment record found for ID {$id}");
                show_404();
                return;
            }

            // Step 3: Fetch user data
            $user = getUserById($details->user_id);
            log_message('debug', "Fetched user info for user_id={$details->user_id}: " . json_encode($user));

            // Step 4: Prepare view data
            $data = [
                'details' => $details,
                'user' => $user
            ];

            // Step 5: Initialize mPDF safely
            try {
                log_message('debug', 'Initializing mPDF...');
                $mpdf = new \Mpdf\Mpdf([
                    'mode' => 'utf-8',
                    'orientation' => 'P',
                    'default_font' => 'hindsiliguri',
                ]);

                // Step 6: Watermark setup
                $appLogo = getSetting('app_logo', null, $details->user_id);
                $logoPath = base_url('assets/img/logo/' . $appLogo);
                // $logoPath = base_url('http://localhost:8080/assets/img/logo/' . $appLogo);

                log_message('debug', "Setting watermark image: {$logoPath}");

                $mpdf->SetWatermarkImage($logoPath);
                $mpdf->showWatermarkImage = true;
                $mpdf->watermarkImageAlpha = 0.25;
                $mpdf->watermark_size = 60;
                $mpdf->watermarkAngle = 33;

                // Step 7: Render the invoice view
                log_message('debug', 'Rendering invoice view for mPDF...');
                $html = view('payments/invoice', $data);
                // log_message('debug', 'Invoice HTML length: ' . print_r($html,true));

                return $this->response
                    ->setHeader('Content-Type', 'text/html')
                    ->setBody($html);

                // $mpdf->WriteHTML($html);

                // $filename = "payment-invoice-" . strtolower($details->month) . "-" .
                //     date("d-m-Y", strtotime($details->paid_at)) . "-" .
                //     date("h-i-s") . ".pdf";

                // log_message('debug', "Outputting PDF as: {$filename}");

                // try {
                //     // Clean output buffer — prevent header issues
                //     if (ob_get_length()) {
                //         ob_end_clean();
                //     }

                //     // Generate PDF content as string
                //     $pdfContent = $mpdf->Output($filename, "S"); // return PDF as string

                //     return $this->response
                //         ->setHeader('Content-Type', 'application/pdf')
                //         ->setHeader('Content-Disposition', 'inline; filename="' . $filename . '"')
                //         ->setBody($pdfContent);
                // } catch (\Throwable $e) {
                //     log_message('error', 'Error outputting PDF: ' . $e->getMessage());
                //     return $this->response->setJSON([
                //         'status' => 'error',
                //         'message' => 'Failed to output PDF',
                //     ]);
                // }
            } catch (\Throwable $e) {
                log_message('error', 'Error generating PDF: ' . $e->getMessage());
                log_message('error', $e->getTraceAsString());

                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Failed to generate invoice PDF'
                ]);
            }
        }
    }



    public function pingUserApi()
    {
        $startTime = microtime(true);
        log_message('info', 'pingUserApi called at: ' . date('Y-m-d H:i:s'));

        $router_id = $this->request->getGet('router_id');
        $name = $this->request->getGet('name');

        log_message('info', 'Fetched router_id data: ' . json_encode($router_id));
        $result = pingUser($router_id, $name, 1);

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime; // in seconds

        log_message('info', 'pingUser execution time: ' . $executionTime . ' seconds');
        // log_message('info', 'Ping result: ' . json_encode($result));

        return $this->response->setJSON($result);
    }

    function get_user_data_usage()
    {
        $user_id = $this->request->getGet('user_id');
        $user_model = model('App\Models\User');

        // Step 1: Get user
        $user = $user_model->find($user_id);
        if (!$user || empty($user->router_id) || empty($user->pppoe_id)) {
            log_message('warning', "get_user_data_usage: Invalid user_id $user_id");
            return null;
        }

        $router_id = $user->router_id;


        try {
            $router_client = routerClient($router_id);

            $pppoe = getPPPoEUserUserId($router_client, $user->id);
            $pppoe_id = $pppoe[0]['.id'] ?? $user->pppoe_id ?? null;

            log_message('info', "PPPoE ID for User ID {$user->id}: {$pppoe_id}");


            $pppoe_id  = $pppoe_id ?? $user->pppoe_id;

            log_message('info', "get_user_data_usage: Connected to router_id $router_id for user_id $user_id");

            // Step 2: If routerClient fails, fallback to FSOCK
            if (!is_object($router_client)) {
                log_message('warning', "routerClient failed for router_id $router_id, trying FSOCK...");

                $fp = connect_using_Fsocket($router_id);
                if (!$fp) {
                    log_message('error', "FSOCK connection not established for router_id $router_id");
                    return null;
                }

                // FSOCK fallback to get RX/TX
                try {
                    $ppp_data = getPPPoEIdFsock($fp, $pppoe_id);
                    if (!$ppp_data) {
                        log_message('warning', "FSOCK: No PPPoE data found for user_id $user_id");
                        return null;
                    }

                    $rxBytes = $ppp_data['rx'] ?? 0;
                    $txBytes = $ppp_data['tx'] ?? 0;

                    $rxMB = round($rxBytes / 1024 / 1024, 2);
                    $txMB = round($txBytes / 1024 / 1024, 2);

                    return $this->response->setJSON([
                        'user_id' => $user_id,
                        'pppoe_id' => $pppoe_id,
                        'rx_mb' => $rxMB,
                        'tx_mb' => $txMB,
                        'method' => 'FSOCK routerClient'
                    ]);
                } catch (\Exception $e) {
                    log_message('error', "FSOCK: Error fetching data for user_id $user_id - " . $e->getMessage());
                    return $this->response->setJSON([
                        'user_id' => $user_id,
                        'pppoe_id' => $pppoe_id,
                        'rx_mb' => 0,
                        'tx_mb' => 0,
                        'method' => 'error',
                        'error_message' => $e->getMessage()
                    ]);
                }
            }

            log_message('info', "routerClient: Successfully connected for router_id $router_id");
            // Step 3: Normal routerClient path

            $pppoeData = getPPPoEUser($router_client, $pppoe_id);
            if (empty($pppoeData)) {
                log_message('warning', "routerClient: No PPPoE data found for user_id $user_id");
                return null;
            }

            $pppoeName = $pppoeData[0]['name'] ?? $pppoe_id;
            $interface = "pppoe-$pppoeName";
            $interfaceQuery = "<$interface>";

            log_message('info', "routerClient: Fetching data for interface $interface for user_id $user_id");
            $query = new \RouterOS\Query('/interface/print');
            $allInterfaces = $router_client->query($query)->read();

            $found = null;
            foreach ($allInterfaces as $intf) {
                if (isset($intf['name']) && $intf['name'] === $interfaceQuery) {
                    $found = $intf;
                    break;
                }
            }

            if (!$found) {
                log_message('warning', "routerClient: Interface <$interface> not found for user_id $user_id");
                return null;
            }

            $rxMB = round($found['rx-byte'] / 1024 / 1024, 2);
            $txMB = round($found['tx-byte'] / 1024 / 1024, 2);
            log_message('info', "routerClient: Data usage for user_id $user_id - RX: $rxMB MB, TX: $txMB MB");

            return $this->response->setJSON([
                'user_id' => $user_id,
                'pppoe_id' => $pppoe_id,
                'rx_mb' => $rxMB,
                'tx_mb' => $txMB,
                'method' => 'routerClient'
            ]);
        } catch (\Exception $e) {
            log_message('error', "routerClient: Error fetching data for user_id $user_id - " . $e->getMessage());
            return $this->response->setJSON([
                'user_id' => $user_id,
                'pppoe_id' => $pppoe_id,
                'rx_mb' => 0,
                'tx_mb' => 0,
                'method' => 'error',
                'error_message' => $e->getMessage()
            ]);
        }
    }




















    public function movie_index()
    {
        $user_id = $this->request->getGet('user_id');
        if (empty($user_id)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'user_id query parameter is required',
            ]);
        }
        $details = $this->user_model->where(['id' => $user_id])->first();
        if (!$details) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'User not found',
            ]);
        }
        $admin_id = $details->admin_id ?? null;
        if ($details->created_by === 'resellerAdmin') {
            $details = $this->user_model->where(['id' => $admin_id])->first();
            $admin_id = $details->admin_id ?? null;
        }

        if ($details->role === 'sAdmin') {
            $admin_id = $user_id;
        }

        if (!$admin_id) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'admin_id is required'
            ]);
        }

        $servers = $this->movieModel->getAllServers($admin_id);
        if (empty($servers) && $admin_id != 2) {
            $servers = $this->movieModel->getAllServers(2);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $servers
        ]);
    }


    /**
     * ➕ Add new movie server
     */
    public function add()
    {
        helper(['form']);

        $imageFile = $this->request->getFile('image');
        $imageName = null;

        if ($imageFile && $imageFile->isValid()) {

            // Generate random name
            $imageName = $imageFile->getRandomName();

            // Make sure folder exists
            $uploadPath = FCPATH . 'assets/movies/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            // Move the uploaded file
            $imageFile->move($uploadPath, $imageName);
        }

        $adminId = $this->request->getPost('admin_id');
        if (empty($adminId)) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'admin_id is required']);
        }

        $data = [
            'name'      => $this->request->getPost('name'),
            'url'       => $this->request->getPost('url'),
            'details'   => $this->request->getPost('details'),
            'rating'    => $this->request->getPost('rating'),
            'admin_id'  => $adminId,
            'image'     => $imageName,
        ];

        log_message('debug', 'Add Movie Server Data: ' . print_r($data, true));

        if ($this->movieModel->addServer($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Movie server added']);
        }

        return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to add server']);
    }

    /**
     * 🔁 Update movie server by ID
     */
    public function update($id)
    {
        helper(['form']);

        $server = $this->movieModel->getServerById($id);
        if (!$server) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Server not found']);
        }

        $imageFile = $this->request->getFile('image');
        // $imageName = $server->image; // keep old image
        $imageName = $server['image'];

        if ($imageFile && $imageFile->isValid()) {
            // Delete old image
            if (!empty($imageName) && file_exists(FCPATH . 'assets/movies/' . $imageName)) {
                unlink(FCPATH . 'assets/movies/' . $imageName);
            }

            // Upload new image
            $imageName = $imageFile->getRandomName();
            $uploadPath = FCPATH . 'assets/movies/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            // Move the uploaded file
            $imageFile->move($uploadPath, $imageName);
        }

        $data = [
            'name'      => $this->request->getPost('name'),
            'url'       => $this->request->getPost('url'),
            'details'   => $this->request->getPost('details'),
            'rating'    => $this->request->getPost('rating'),
            // 'admin_id'  => $this->request->getPost('admin_id'),
            'image'     => $imageName,
        ];

        if ($this->movieModel->updateServer($id, $data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => "Server ID {$id} updated"]);
        }

        return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update server']);
    }


    public function view($id = null)
    {
        if (!$id) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'ID is required'
            ], 400);
        }

        $movie = $this->movieModel->getServerById($id);

        if (!$movie) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Movie not found'
            ], 404);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $movie
        ], 200);
    }


    /**
     * ❌ Delete movie server by ID
     */
    public function delete($id)
    {
        $server = $this->movieModel->getServerById($id);
        if (!$server) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Server not found']);
        }

        // Delete image file
        if (!empty($server->image) && file_exists(WRITEPATH . 'assets/movies//' . $server->image)) {
            unlink(WRITEPATH . 'assets/movies//' . $server->image);
        }

        if ($this->movieModel->deleteServer($id)) {
            return $this->response->setJSON(['status' => 'success', 'message' => "Server ID {$id} deleted"]);
        }

        return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete server']);
    }




    public function news_index()
    {
        $user_id = $this->request->getGet('user_id');
        if (empty($user_id)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'user_id query parameter is required',
            ]);
        }
        $details = $this->user_model->where(['id' => $user_id])->first();
        if (!$details) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'User not found',
            ]);
        }
        $admin_id = $details->admin_id ?? null;
        if ($details->created_by === 'resellerAdmin') {
            $details = $this->user_model->where(['id' => $admin_id])->first();
            $admin_id = $details->admin_id ?? null;
        }
        if ($details->role === 'sAdmin') {
            $admin_id = $user_id;
        }


        if (!$admin_id) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'admin_id is required'
            ]);
        }

        $servers = $this->News_notice->getAllServers($admin_id);
        if (empty($servers) && $admin_id != 2) {
            $servers = $this->News_notice->getAllServers(2);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $servers
        ]);
    }
    public function news_add()
    {
        helper(['form']);

        $imageFile = $this->request->getFile('image');
        $imageName = null;

        if ($imageFile && $imageFile->isValid()) {

            // Generate random name
            $imageName = $imageFile->getRandomName();

            // Make sure folder exists
            $uploadPath = FCPATH . 'assets/news/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            // Move the uploaded file
            $imageFile->move($uploadPath, $imageName);
        }

        $newsAdminId = $this->request->getPost('admin_id');
        if (empty($newsAdminId)) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'admin_id is required']);
        }

        $data = [
            'name'      => $this->request->getPost('name'),
            'url'       => $this->request->getPost('url'),
            'details'   => $this->request->getPost('details'),
            // 'rating'    => $this->request->getPost('rating'),
            'opened'    => 'false',
            'admin_id'  => $newsAdminId,
            'image'     => $imageName,
        ];

        log_message('debug', 'Add news Server Data: ' . print_r($data, true));

        if ($this->News_notice->addServer($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'news server added']);
        }

        return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to add news']);
    }

    public function news_view_update($id)
    {
        helper(['form']);

        $data = [
            'opened'      => '',
        ];

        if ($this->News_notice->updateServer($id, $data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => "news ID {$id} viewed"]);
        }

        return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update news viewed status']);
    }

    public function news_update($id)
    {
        helper(['form']);

        $server = $this->News_notice->getServerById($id);
        if (!$server) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'news not found']);
        }

        $imageFile = $this->request->getFile('image');
        // $imageName = $server->image; // keep old image
        $imageName = $server['image'];

        if ($imageFile && $imageFile->isValid()) {
            // Delete old image
            if (!empty($imageName) && file_exists(FCPATH . 'assets/news/' . $imageName)) {
                unlink(FCPATH . 'assets/news/' . $imageName);
            }

            // Upload new image
            $imageName = $imageFile->getRandomName();
            $uploadPath = FCPATH . 'assets/news/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            // Move the uploaded file
            $imageFile->move($uploadPath, $imageName);
        }

        $data = [
            'name'      => $this->request->getPost('name'),
            'url'       => $this->request->getPost('url'),
            'details'   => $this->request->getPost('details'),
            // 'rating'    => $this->request->getPost('rating'),
            // 'admin_id'  => $this->request->getPost('admin_id'),
            'image'     => $imageName,
        ];

        if ($this->News_notice->updateServer($id, $data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => "news ID {$id} updated"]);
        }

        return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update news']);
    }

    public function news_view($id = null)
    {
        if (!$id) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'ID is required'
            ], 400);
        }

        $movie = $this->News_notice->getServerById($id);

        if (!$movie) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Movie not found'
            ], 404);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $movie
        ], 200);
    }

    public function news_delete($id)
    {
        $server = $this->News_notice->getServerById($id);
        if (!$server) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'news not found']);
        }

        // Delete image file
        if (!empty($server->image) && file_exists(WRITEPATH . 'assets/news/' . $server->image)) {
            unlink(WRITEPATH . 'assets/news/' . $server->image);
        }

        if ($this->News_notice->deleteServer($id)) {
            return $this->response->setJSON(['status' => 'success', 'message' => "news ID {$id} deleted"]);
        }

        return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete news']);
    }


    

    
    


}
